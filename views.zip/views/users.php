<?php
// === Configuration et sécurité ===
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../config/db.php';
session_start();

// Vérification du rôle administrateur
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// === Ajout d’un administrateur ===
if (isset($_POST['add'])) {
    $nom_complet = trim($_POST['nom_complet'] ?? '');
    $telephone = trim($_POST['telephone'] ?? '');
    $mot_de_passe = trim($_POST['mot_de_passe'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $poste = trim($_POST['poste'] ?? '');
    $statut = trim($_POST['statut'] ?? '');
    $date_creation = date("Y-m-d H:i:s");

    if ($nom_complet && $telephone && $mot_de_passe && $email) {
        try {
            $stmt = $db->prepare("INSERT INTO administrateurs 
                (nom_complet, telephone, mot_de_passe, email, poste, statut, date_creation)
                VALUES (:nom_complet, :telephone, :mot_de_passe, :email, :poste, :statut, :date_creation)");
            $stmt->execute([
                ':nom_complet' => $nom_complet,
                ':telephone' => $telephone,
                ':mot_de_passe' => password_hash($mot_de_passe, PASSWORD_DEFAULT),
                ':email' => $email,
                ':poste' => $poste,
                ':statut' => $statut,
                ':date_creation' => $date_creation
            ]);
            $message = "<p class='success'>✅ Administrateur ajouté avec succès !</p>";
        } catch (PDOException $e) {
            $message = "<p class='error'>Erreur : " . $e->getMessage() . "</p>";
        }
    } else {
        $message = "<p class='error'>⚠️ Tous les champs doivent être remplis.</p>";
    }
}

// === Recherche ===
$search_query = '';
if (isset($_POST['search'])) {
    $search_term = '%' . $_POST['search_term'] . '%';
    $search_query = "WHERE nom_complet LIKE :search_term OR email LIKE :search_term";
}

$stmt = $db->prepare("SELECT * FROM administrateurs $search_query ORDER BY id_admin DESC");
if ($search_query) {
    $stmt->bindParam(':search_term', $search_term);
}
$stmt->execute();
$administrateurs = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestion des Administrateurs</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp"> <!-- Ajout de l'icône dans l'onglet -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
    body {
        font-family: 'Segoe UI', sans-serif;
        background: #f4f7fb;
        margin: 0;
        color: #333;
    }
    header {
        background: linear-gradient(90deg, #0b3b6a, #c58a00);
        padding: 1rem 5%;
        color: #fff;
        text-align: center;
    }
    h1 {
        margin: 0;
        font-size: 1.8rem;
        letter-spacing: 1px;
    }
    .container {
        width: 90%;
        max-width: 1100px;
        margin: 30px auto;
        background: #fff;
        border-radius: 10px;
        padding: 25px;
        box-shadow: 0 3px 10px rgba(0,0,0,0.1);
    }
    .buttons {
        text-align: center;
        margin-bottom: 20px;
    }
    button, .btn {
        background-color: #28a745;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 1rem;
        margin: 5px;
        text-decoration: none;
        display: inline-block;
    }
    button:hover, .btn:hover {
        background-color: #218838;
    }
    .search-form {
        text-align: center;
        margin: 20px 0;
    }
    .search-form input {
        padding: 10px;
        width: 60%;
        max-width: 400px;
        border: 1px solid #ccc;
        border-radius: 6px;
    }
    .search-form button {
        background-color: #007bff;
    }
    .search-form button:hover {
        background-color: #0056b3;
    }
    form#addForm {
        display: none;
        margin-top: 30px;
        background: #fefefe;
        padding: 20px;
        border: 1px solid #ddd;
        border-radius: 8px;
        box-shadow: 0 3px 6px rgba(0,0,0,0.05);
    }
    form#addForm label {
        font-weight: bold;
        display: block;
        margin-top: 15px;
    }
    form#addForm input, form#addForm select {
        width: 100%;
        padding: 10px;
        border-radius: 6px;
        border: 1px solid #ccc;
        margin-top: 5px;
        font-size: 1rem;
    }
    form#addForm button {
        background-color: #28a745;
        width: 100%;
        margin-top: 20px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 25px;
    }
    th {
        background-color: #0b3b6a;
        color: white;
        padding: 12px;
        text-align: left;
    }
    td {
        padding: 10px;
        border-bottom: 1px solid #ddd;
    }
    tr:hover {
        background-color: #f1f7ff;
    }
    .action-links a {
        background-color: #007bff;
        color: white;
        padding: 6px 12px;
        border-radius: 5px;
        text-decoration: none;
        margin-right: 5px;
        font-size: 0.9rem;
    }
    .action-links a:hover {
        background-color: #0056b3;
    }
    .success, .error {
        text-align: center;
        margin: 15px 0;
        font-weight: bold;
    }
    .success { color: green; }
    .error { color: red; }

    @media (max-width: 768px) {
        th, td { font-size: 0.9rem; }
        .search-form input { width: 90%; }
        .container { width: 95%; padding: 15px; }
    }
</style>
</head>
<body>

<header>
    <h1><i class="fa-solid fa-user-shield"></i> Gestion des Administrateurs</h1>
</header>

<div class="container">
    <?= $message ?? '' ?>

    <div class="buttons">
        <a href="admin_dashboard.php" class="btn"><i class="fa-solid fa-arrow-left"></i> Retour à l'Accueil</a>
        <button onclick="toggleForm()"><i class="fa-solid fa-user-plus"></i> Ajouter un Administrateur</button>
    </div>

    <!-- Formulaire de recherche -->
    <form class="search-form" method="POST">
        <input type="text" name="search_term" placeholder="Rechercher par nom ou email" required>
        <button type="submit" name="search"><i class="fa-solid fa-search"></i> Rechercher</button>
    </form>

    <!-- Formulaire d’ajout -->
    <form id="addForm" method="POST" action="users.php">
        <label>Nom Complet :</label>
        <input type="text" name="nom_complet" required>

        <label>Téléphone :</label>
        <input type="text" name="telephone" required>

        <label>Mot de Passe :</label>
        <input type="password" name="mot_de_passe" required placeholder="Créer un mot de passe">

        <label>Email :</label>
        <input type="email" name="email" required>

        <label>Poste :</label>
        <input type="text" name="poste" required>

        <label>Statut :</label>
        <select name="statut" required>
            <option value="actif">Actif</option>
            <option value="inactif">Inactif</option>
        </select>

        <button type="submit" name="add"><i class="fa-solid fa-floppy-disk"></i> Enregistrer</button>
    </form>

    <h2 style="text-align:center; margin-top:40px; color:#0b3b6a;">Liste des Administrateurs</h2>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nom Complet</th>
                <th>Téléphone</th>
                <th>Email</th>
                <th>Poste</th>
                <th>Mot de Passe (haché)</th>
                <th>Statut</th>
                <th>Date Création</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($administrateurs): ?>
                <?php foreach ($administrateurs as $admin): ?>
                    <tr>
                        <td><?= htmlspecialchars($admin['id_admin']); ?></td>
                        <td><?= htmlspecialchars($admin['nom_complet']); ?></td>
                        <td><?= htmlspecialchars($admin['telephone']); ?></td>
                        <td><?= htmlspecialchars($admin['email']); ?></td>
                        <td><?= htmlspecialchars($admin['poste']); ?></td>
                        <td style="font-size:0.85rem; color:#555;"><?= htmlspecialchars($admin['mot_de_passe']); ?></td>
                        <td><?= htmlspecialchars($admin['statut']); ?></td>
                        <td><?= htmlspecialchars($admin['date_creation']); ?></td>
                        <td class="action-links">
                            <a href="edit_admin.php?id=<?= $admin['id_admin']; ?>"><i class="fa-solid fa-pen-to-square"></i></a>
                            <a href="delete_admin.php?id=<?= $admin['id_admin']; ?>" onclick="return confirm('Supprimer cet administrateur ?')"><i class="fa-solid fa-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="9" style="text-align:center;">Aucun administrateur trouvé</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script>
function toggleForm() {
    const form = document.getElementById('addForm');
    form.style.display = (form.style.display === 'none' || form.style.display === '') ? 'block' : 'none';
}
</script>

</body>
</html>
