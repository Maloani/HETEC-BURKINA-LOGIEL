<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

require_once '../models/config.php';

// 🔐 Vérification de la session
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'enseignant') {
    header("Location: ../login.php");
    exit();
}

$id_enseignant = $_SESSION['user_id'];
$nom_enseignant = $_SESSION['nom'];

// 🔢 Pagination
$limit = 10;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// 📊 Total des cours attribués
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM cours WHERE id_enseignant = :id");
$countStmt->bindValue(':id', $id_enseignant, PDO::PARAM_INT);
$countStmt->execute();
$totalCours = $countStmt->fetchColumn();
$totalPages = max(1, ceil($totalCours / $limit));

// 📘 Récupération des cours + UEs
$sql = "
SELECT 
    u.id_ue, u.code_ue, u.intitule_ue,
    c.designation_cours,
    c.code_cours,
    c.credits,
    c.CM,
    c.P,
    c.TPE,
    c.annee_academique,
    o.designation_option,
    f.designation_filiere
FROM cours c
LEFT JOIN ues u ON c.id_ue = u.id_ue
LEFT JOIN options o ON c.id_option = o.id_option
LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
WHERE c.id_enseignant = :id_enseignant
ORDER BY u.code_ue, c.designation_cours
LIMIT :limit OFFSET :offset
";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':id_enseignant', $id_enseignant, PDO::PARAM_INT);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$cours = $stmt->fetchAll(PDO::FETCH_ASSOC);

// === STATISTIQUES ===
$stats = [
    'ues' => 0,
    'filières' => 0,
    'annee_recente' => '',
];
if ($totalCours > 0) {
    $data = $pdo->prepare("
        SELECT 
            COUNT(DISTINCT u.id_ue) AS nb_ues,
            COUNT(DISTINCT f.id_filiere) AS nb_filieres,
            MAX(c.annee_academique) AS annee_max
        FROM cours c
        LEFT JOIN ues u ON c.id_ue = u.id_ue
        LEFT JOIN options o ON c.id_option = o.id_option
        LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
        WHERE c.id_enseignant = :id
    ");
    $data->execute([':id' => $id_enseignant]);
    $stats = $data->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mes Cours – HETEC Burkina Faso</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
:root {
  --primary: #0B3B6A;
  --secondary: #C58A00;
  --bg: #f4f7fb;
  --text: #222;
}
body {
  margin: 0;
  font-family: "Segoe UI", sans-serif;
  background: var(--bg);
  color: var(--text);
  display: flex;
}

/* === Sidebar === */
.sidebar {
  width: 230px;
  background: linear-gradient(180deg, var(--primary), #082f55);
  color: white;
  height: 100vh;
  position: fixed;
  left: 0;
  top: 0;
  padding-top: 20px;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 6px rgba(0,0,0,0.2);
}
.sidebar .logo {
  text-align: center;
  margin-bottom: 25px;
}
.sidebar .logo img {
  width: 60px;
  border-radius: 50%;
}
.sidebar .logo h2 {
  margin: 10px 0 0;
  font-size: 1.1rem;
  color: var(--secondary);
}
.sidebar .menu a {
  display: flex;
  align-items: center;
  color: white;
  text-decoration: none;
  padding: 12px 20px;
  gap: 12px;
  transition: 0.3s;
  border-left: 4px solid transparent;
}
.sidebar .menu a:hover, .sidebar .menu a.active {
  background: var(--secondary);
  border-left: 4px solid #fff;
}

/* === Main === */
.main {
  margin-left: 230px;
  flex: 1;
  padding: 25px;
}

header {
  background: linear-gradient(90deg, var(--primary), var(--secondary));
  color: #fff;
  padding: 15px;
  border-radius: 8px;
  text-align: center;
  margin-bottom: 20px;
}

/* === Statistiques === */
.stats {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
  gap: 15px;
  margin-bottom: 25px;
}
.stat-box {
  background: #fff;
  border-left: 6px solid var(--secondary);
  border-radius: 8px;
  padding: 15px;
  text-align: center;
  box-shadow: 0 3px 8px rgba(0,0,0,0.1);
}
.stat-box h3 {
  margin: 0;
  color: var(--primary);
}
.stat-box p {
  margin: 5px 0 0;
  color: #444;
  font-weight: bold;
}

.welcome {
  background: #fff;
  border-radius: 10px;
  padding: 1rem;
  margin-bottom: 1.5rem;
  text-align: center;
  box-shadow: 0 3px 8px rgba(0,0,0,0.1);
}
.welcome h2 {
  color: var(--primary);
  margin-bottom: 0.3rem;
}

table {
  width: 100%;
  border-collapse: collapse;
  background: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 3px 8px rgba(0,0,0,0.1);
}
th, td {
  padding: 10px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}
th {
  background: var(--primary);
  color: white;
  font-size: 0.9rem;
}
tr:hover {
  background: #f9f9f9;
}

.pagination {
  text-align: center;
  margin-top: 20px;
}
.pagination a {
  display: inline-block;
  margin: 0 5px;
  padding: 8px 14px;
  border-radius: 5px;
  background: var(--secondary);
  color: white;
  text-decoration: none;
  transition: 0.3s;
}
.pagination a:hover {
  background: #b47800;
}
.pagination span {
  font-weight: 600;
}

@media (max-width: 768px) {
  .sidebar { width: 60px; }
  .sidebar .logo h2, .sidebar .logo img, .sidebar .menu a span { display: none; }
  .main { margin-left: 60px; }
}
</style>
</head>

<body>

<!-- ======== SIDEBAR ======== -->
<aside class="sidebar">
  <div class="logo">
    <img src="../img/hetec.jpg-2.webp" alt="HETEC">
    <h2>HETEC</h2>
  </div>
  <nav class="menu">
    <a href="enseignant_dashboard.html"><i class="fa-solid fa-house"></i><span>Accueil</span></a>
    <a href="mes_cours.php" class="active"><i class="fa-solid fa-book"></i><span>Mes Cours</span></a>
    <a href="cotations.php"><i class="fa-solid fa-graduation-cap"></i><span>Attribuer les notes</span></a>
    <a href="communiques_ens.php"><i class="fa-solid fa-bullhorn"></i><span>Communiqués</span></a>
    <a href="profil_ens.php"><i class="fa-solid fa-user"></i><span>Profil</span></a>
   
  </nav>
</aside>

<!-- ======== MAIN CONTENT ======== -->
<div class="main">
  <header>
    <h1><i class="fa-solid fa-book"></i> Mes Unités et Cours (UE / ECUE)</h1>
  </header>

  <div class="welcome">
    <h2>Bienvenue, <?= htmlspecialchars($nom_enseignant) ?></h2>
    <p>Rôle : <strong>Enseignant</strong></p>
  </div>

  <!-- === STATISTIQUES === -->
  <div class="stats">
    <div class="stat-box">
      <h3><i class="fa-solid fa-layer-group"></i> Total des UEs</h3>
      <p><?= htmlspecialchars($stats['nb_ues'] ?? 0) ?></p>
    </div>
    <div class="stat-box">
      <h3><i class="fa-solid fa-book-open"></i> Total des ECUE</h3>
      <p><?= htmlspecialchars($totalCours) ?></p>
    </div>
    <div class="stat-box">
      <h3><i class="fa-solid fa-building-columns"></i> Filières couvertes</h3>
      <p><?= htmlspecialchars($stats['nb_filieres'] ?? 0) ?></p>
    </div>
    <div class="stat-box">
      <h3><i class="fa-solid fa-calendar"></i> Année récente</h3>
      <p><?= htmlspecialchars($stats['annee_max'] ?? '—') ?></p>
    </div>
  </div>

  <!-- === TABLEAU DES COURS === -->
  <?php if (count($cours) > 0): ?>
    <table>
      <thead>
        <tr>
          <th>UE (Code & Intitulé)</th>
          <th>Cours (ECUE)</th>
          <th>Code ECUE</th>
          <th>Crédits</th>
          <th>CM</th>
          <th>P</th>
          <th>TPE</th>
          <th>Option</th>
          <th>Filière</th>
          <th>Année</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($cours as $c): ?>
        <tr>
          <td><?= htmlspecialchars(($c['code_ue'] ?? '—') . ' — ' . ($c['intitule_ue'] ?? '')) ?></td>
          <td><?= htmlspecialchars($c['designation_cours']) ?></td>
          <td><?= htmlspecialchars($c['code_cours']) ?></td>
          <td><?= htmlspecialchars($c['credits']) ?></td>
          <td><?= htmlspecialchars($c['CM']) ?></td>
          <td><?= htmlspecialchars($c['P']) ?></td>
          <td><?= htmlspecialchars($c['TPE']) ?></td>
          <td><?= htmlspecialchars($c['designation_option']) ?></td>
          <td><?= htmlspecialchars($c['designation_filiere']) ?></td>
          <td><?= htmlspecialchars($c['annee_academique']) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <div class="pagination">
      <?php if ($page > 1): ?>
        <a href="?page=<?= $page - 1 ?>"><i class="fa fa-arrow-left"></i> Précédent</a>
      <?php endif; ?>
      <span>Page <?= $page ?> / <?= $totalPages ?></span>
      <?php if ($page < $totalPages): ?>
        <a href="?page=<?= $page + 1 ?>">Suivant <i class="fa fa-arrow-right"></i></a>
      <?php endif; ?>
    </div>

  <?php else: ?>
    <p style="text-align:center; color:#888;">Aucun cours attribué à votre compte pour le moment.</p>
  <?php endif; ?>
</div>

</body>
</html>
