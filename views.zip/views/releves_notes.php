<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../models/config.php';

// === Barre de recherche ===
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// === Pagination ===
$limit = 10;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// === Construction de la clause WHERE ===
$where = "i.statut_inscription = 'confirmée'";
$params = [];

if (!empty($search)) {
    $where .= " AND (i.nom_etudiant LIKE :search OR i.prenom_etudiant LIKE :search OR i.matricule_etudiant LIKE :search)";
    $params[':search'] = "%$search%";
}

// === Total des étudiants (confirmés + ayant des cotes) ===
$totalStmt = $pdo->prepare("
    SELECT COUNT(DISTINCT i.id_inscription)
    FROM inscriptions i
    JOIN cotes c ON i.matricule_etudiant = c.matricule_etudiant
    WHERE $where
");
$totalStmt->execute($params);
$total = $totalStmt->fetchColumn();
$totalPages = ceil($total / $limit);

// === Liste paginée ===
$query = "
  SELECT DISTINCT i.id_inscription, i.matricule_etudiant, i.nom_etudiant, i.prenom_etudiant,
         i.grade, i.domaine, i.niveau, i.annee_academique, i.sexe,
         f.designation_filiere, o.designation_option
  FROM inscriptions i
  JOIN cotes c ON i.matricule_etudiant = c.matricule_etudiant
  LEFT JOIN options o ON i.id_option = o.id_option
  LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
  WHERE $where
  ORDER BY i.nom_etudiant ASC
  LIMIT :limit OFFSET :offset
";

$stmt = $pdo->prepare($query);
foreach ($params as $key => $val) {
    $stmt->bindValue($key, $val, PDO::PARAM_STR);
}
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$etudiants = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Relevés de Notes - HETEC Burkina Faso</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body {
  font-family: Arial, sans-serif;
  background: #f7f7f9;
  margin: 0;
  padding: 0;
}
.container {
  max-width: 1200px;
  margin: 30px auto;
  background: #fff;
  border-radius: 10px;
  padding: 20px 30px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.08);
}
h1 {
  text-align: center;
  color: #0b3b6a;
  margin-bottom: 20px;
}
.top-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}
.top-bar a {
  background: #884ea0;
  color: #fff;
  text-decoration: none;
  padding: 8px 16px;
  border-radius: 6px;
  font-weight: bold;
  font-size: 14px;
}
.top-bar a:hover {
  background: #6d397e;
}
.search-box {
  text-align: center;
  margin-bottom: 20px;
}
.search-box form {
  display: inline-flex;
  gap: 8px;
}
.search-box input {
  padding: 8px 10px;
  width: 260px;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 14px;
}
.search-box button {
  background: #0b3b6a;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 8px 14px;
  cursor: pointer;
  font-size: 14px;
}
.search-box button:hover {
  background: #06294a;
}
table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 15px;
}
th, td {
  border: 1px solid #ddd;
  padding: 10px 8px;
  text-align: center;
  font-size: 14px;
}
th {
  background: #0b3b6a;
  color: #fff;
}
tr:nth-child(even) {
  background: #f5f5f5;
}
.actions a {
  padding: 5px 10px;
  margin: 2px;
  border-radius: 6px;
  text-decoration: none;
  color: #fff;
  font-size: 13px;
  display: inline-block;
}
.btn-print { background: #007bff; }
.btn-print:hover { background: #0056b3; }

.pagination {
  text-align: center;
  margin: 20px 0;
}
.pagination a {
  text-decoration: none;
  padding: 8px 14px;
  margin: 3px;
  border-radius: 5px;
  background: #0b3b6a;
  color: #fff;
  font-size: 14px;
}
.pagination a.disabled {
  background: #ccc;
  cursor: not-allowed;
}
.footer {
  text-align: center;
  color: #777;
  font-size: 13px;
  padding-top: 10px;
  border-top: 1px solid #ddd;
  margin-top: 20px;
}
</style>
</head>
<body>
<div class="container">
  <div class="top-bar">
    <a href="admin_dashboard.php"><i class="fa-solid fa-arrow-left"></i> Retour au tableau de bord</a>
    <h1><i class="fa-solid fa-graduation-cap"></i> Relevés de Notes</h1>
  </div>

  <div class="search-box">
    <form method="GET">
      <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Rechercher par nom ou matricule...">
      <button type="submit"><i class="fa-solid fa-search"></i> Rechercher</button>
    </form>
  </div>

  <?php if (count($etudiants) === 0): ?>
    <p style="text-align:center; color:#999;">Aucun relevé de notes trouvé pour votre recherche.</p>
  <?php else: ?>
  <table>
    <thead>
      <tr>
        <th>N°</th>
        <th>Matricule</th>
        <th>Nom et Prénoms</th>
        <th>Sexe</th>
        <th>Filière</th>
        <th>Option</th>
        <th>Grade</th>
        <th>Niveau</th>
        <th>Année</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $n = $offset + 1;
      foreach ($etudiants as $et) {
          echo "<tr>
              <td>{$n}</td>
              <td>{$et['matricule_etudiant']}</td>
              <td>".strtoupper($et['nom_etudiant'])." ".ucfirst($et['prenom_etudiant'])."</td>
              <td>{$et['sexe']}</td>
              <td>{$et['designation_filiere']}</td>
              <td>{$et['designation_option']}</td>
              <td>{$et['grade']}</td>
              <td>{$et['niveau']}</td>
              <td>{$et['annee_academique']}</td>
              <td class='actions'>
                <a href='releves_notes_pdf.php?id={$et['id_inscription']}' target='_blank' class='btn-print'>
                  <i class='fa-solid fa-print'></i> Imprimer
                </a>
              </td>
          </tr>";
          $n++;
      }
      ?>
    </tbody>
  </table>

  <!-- Pagination -->
  <div class="pagination">
    <?php if ($page > 1): ?>
      <a href="?page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>"><i class="fa-solid fa-angle-left"></i> Précédent</a>
    <?php else: ?>
      <a class="disabled"><i class="fa-solid fa-angle-left"></i> Précédent</a>
    <?php endif; ?>

    <?php if ($page < $totalPages): ?>
      <a href="?page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>">Suivant <i class="fa-solid fa-angle-right"></i></a>
    <?php else: ?>
      <a class="disabled">Suivant <i class="fa-solid fa-angle-right"></i></a>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <div class="footer">
    © <?= date('Y') ?> HETEC Burkina Faso – Plateforme Académique Numérique | Développé par <strong>MS Solutions Lab</strong>
  </div>
</div>
</body>
</html>
