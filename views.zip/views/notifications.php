<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

require_once '../config/db.php';

// === AJOUTER UNE NOTIFICATION ===
if (isset($_POST['add'])) {
    $titre = trim($_POST['titre']);
    $message = trim($_POST['message']);
    $type_evenement = trim($_POST['type_evenement']);
    $destinataire = trim($_POST['destinataire']);

    if (!empty($titre) && !empty($message)) {
        try {
            $stmt = $db->prepare("INSERT INTO notifications (titre, message, type_evenement, destinataire, statut)
                                  VALUES (:titre, :message, :type_evenement, :destinataire, 'Envoyée')");
            $stmt->execute([
                ':titre' => $titre,
                ':message' => $message,
                ':type_evenement' => $type_evenement,
                ':destinataire' => $destinataire
            ]);
            $message_alert = "<p class='success' id='msg'>✅ Notification envoyée avec succès !</p>";
        } catch (PDOException $e) {
            $message_alert = "<p class='error'>Erreur : " . $e->getMessage() . "</p>";
        }
    } else {
        $message_alert = "<p class='error'>⚠️ Tous les champs sont obligatoires.</p>";
    }
}

// === SUPPRESSION ===
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $stmt = $db->prepare("DELETE FROM notifications WHERE id_notification = :id");
        $stmt->execute([':id' => $id]);
        $message_alert = "<p class='success' id='msg'>🗑️ Notification supprimée avec succès.</p>";
    } catch (PDOException $e) {
        $message_alert = "<p class='error'>Erreur : " . $e->getMessage() . "</p>";
    }
}

// === PAGINATION ===
$limit = 5; // nombre d’éléments par page
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// === TOTAL NOTIFICATIONS ===
$total_notif = $db->query("SELECT COUNT(*) FROM notifications")->fetchColumn();
$totalPages = ceil($total_notif / $limit);

// === RÉCUPÉRATION DES NOTIFICATIONS PAGINÉES ===
$stmt = $db->prepare("SELECT * FROM notifications ORDER BY date_envoi DESC LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

// === STATISTIQUES ===
$total_reunion = $db->query("SELECT COUNT(*) FROM notifications WHERE type_evenement='Réunion'")->fetchColumn();
$total_soutenance = $db->query("SELECT COUNT(*) FROM notifications WHERE type_evenement='Soutenance'")->fetchColumn();
$total_defense = $db->query("SELECT COUNT(*) FROM notifications WHERE type_evenement='Défense'")->fetchColumn();
$total_inscription = $db->query("SELECT COUNT(*) FROM notifications WHERE type_evenement='Inscription'")->fetchColumn();

$start = $total_notif > 0 ? $offset + 1 : 0;
$end = min($offset + $limit, $total_notif);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Notifications des Institutions</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp"> <!-- Ajout de l'icône dans l'onglet -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
body {font-family: 'Segoe UI', sans-serif; background: #f4f7fb; margin: 0; padding: 0;}
header {background: linear-gradient(90deg, #0b3b6a, #c58a00); color: #fff; text-align: center; padding: 1rem;}
.container {width: 90%; max-width: 1000px; margin: 30px auto; background: #fff; padding: 25px; border-radius: 10px; box-shadow: 0 3px 10px rgba(0,0,0,0.1);}
h1 {margin: 0;}
form {display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 20px;}
form input, form select, form textarea {flex: 1; padding: 10px; border-radius: 6px; border: 1px solid #ccc; font-size: 1rem;}
form textarea {min-height: 100px;}
form button {background-color: #007bff; border: none; color: #fff; padding: 10px 15px; border-radius: 6px; cursor: pointer;}
form button:hover {background-color: #0056b3;}
.error, .success {text-align: center; font-weight: bold; margin: 10px 0;}
.success {color: green;}
.error {color: red;}
table {width: 100%; border-collapse: collapse; margin-top: 15px;}
th {background-color: #0b3b6a; color: white; padding: 12px; text-align: left;}
td {padding: 10px; border-bottom: 1px solid #ddd;}
tr:hover {background-color: #f8f9fa;}
.delete-btn {background-color: #dc3545; color: white; border: none; padding: 6px 12px; border-radius: 5px; cursor: pointer;}
.delete-btn:hover {background-color: #b52a36;}
.btn {background-color: #28a745; color: #fff; border: none; padding: 10px 18px; border-radius: 6px; cursor: pointer; text-decoration: none;}
.btn:hover {background-color: #218838;}
.stats-box {background:#e9f4ff;border-left:5px solid #0b3b6a;padding:15px;margin-bottom:20px;border-radius:8px;}
.stats-box strong {color:#0b3b6a;}
.pagination{text-align:center;margin-top:25px;}
.pagination a{color:#007bff;text-decoration:none;padding:8px 14px;border:1px solid #ccc;border-radius:5px;margin:0 3px;}
.pagination a.active{background:#007bff;color:white;}
.pagination a:hover{background:#e2e6ea;}
</style>
</head>
<body>

<header>
  <h1><i class="fa-solid fa-bell"></i> Gestion des Notifications</h1>
</header>

<div class="container">
<?= $message_alert ?? '' ?>

<!-- ✅ Statistiques globales -->
<div class="stats-box">
  <p><strong>Total global :</strong> <?= $total_notif ?> notification(s)</p>
  <p>📌 Inscription : <strong><?= $total_inscription ?></strong> | 🧾 Réunion : <strong><?= $total_reunion ?></strong> | 🎓 Soutenance : <strong><?= $total_soutenance ?></strong> | 🧑‍🏫 Défense : <strong><?= $total_defense ?></strong></p>
</div>

<a href="admin_dashboard.php" class="btn"><i class="fa-solid fa-home"></i> Accueil</a></br>  </br>

<!-- ✅ Formulaire d’envoi -->
<form method="POST" action="notifications.php">
  <input type="text" name="titre" placeholder="Titre de la notification" required>
  <select name="type_evenement" required>
    <option value="">-- Type d’événement --</option>
    <option value="Inscription">Inscription</option>
    <option value="Réunion">Réunion</option>
    <option value="Soutenance">Soutenance</option>
    <option value="Défense">Défense</option>
    <option value="Résultats">Résultats</option>
    <option value="Autre">Autre</option>
  </select>
  <select name="destinataire" required>
    <option value="Institutions">Institutions</option>
    <option value="Étudiants">Étudiants</option>
    <option value="Enseignants">Enseignants</option>
    <option value="Toutes">Toutes les catégories</option>
  </select>
  <textarea name="message" placeholder="Contenu du message..." required></textarea>
  <button type="submit" name="add"><i class="fa-solid fa-paper-plane"></i> Envoyer</button>
</form>

<!-- ✅ Liste des notifications -->
<p style="font-style:italic;color:#555;text-align:right;">Affichage de <?= $start ?> à <?= $end ?> sur <?= $total_notif ?> notifications</p>

<table>
  <thead>
    <tr>
      <th>Titre</th>
      <th>Type</th>
      <th>Destinataire</th>
      <th>Date d’envoi</th>
      <th>Message</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($notifications as $notif): ?>
      <tr>
        <td><strong><?= htmlspecialchars($notif['titre']); ?></strong></td>
        <td><?= htmlspecialchars($notif['type_evenement']); ?></td>
        <td><?= htmlspecialchars($notif['destinataire']); ?></td>
        <td><?= htmlspecialchars($notif['date_envoi']); ?></td>
        <td><?= htmlspecialchars($notif['message']); ?></td>
        <td>
          <a href="notifications.php?delete=<?= $notif['id_notification']; ?>" onclick="return confirm('Supprimer cette notification ?')">
            <button class="delete-btn"><i class="fa-solid fa-trash"></i></button>
          </a>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<!-- ✅ Pagination -->
<div class="pagination">
  <?php if ($page > 1): ?>
    <a href="?page=<?= $page - 1; ?>">« Précédent</a>
  <?php endif; ?>
  <?php for ($i = 1; $i <= $totalPages; $i++): ?>
    <a href="?page=<?= $i; ?>" class="<?= $i == $page ? 'active' : ''; ?>"><?= $i; ?></a>
  <?php endfor; ?>
  <?php if ($page < $totalPages): ?>
    <a href="?page=<?= $page + 1; ?>">Suivant »</a>
  <?php endif; ?>
</div>
</div>

<script>
setTimeout(() => {
  const msg = document.getElementById('msg');
  if (msg) msg.style.display = 'none';
}, 5000);
</script>

</body>
</html>
