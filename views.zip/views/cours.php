<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

require_once '../config/db.php';

// === Liste des options ===
$optionsStmt = $db->query("
    SELECT o.id_option, o.designation_option, f.designation_filiere
    FROM options o
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    ORDER BY f.designation_filiere ASC, o.designation_option ASC
");
$optionsList = $optionsStmt->fetchAll(PDO::FETCH_ASSOC);

// === Liste des enseignants ===
$enseignantStmt = $db->query("SELECT id_enseignant, nom_complet, niveau_etude FROM enseignants ORDER BY nom_complet ASC");
$enseignantList = $enseignantStmt->fetchAll(PDO::FETCH_ASSOC);

// === Liste des UEs ===
$ueStmt = $db->query("SELECT id_ue, code_ue, intitule_ue FROM ues ORDER BY code_ue ASC");
$ueList = $ueStmt->fetchAll(PDO::FETCH_ASSOC);

// === Ajout d’un cours ===
if (isset($_POST['add'])) {
    $designation_cours = trim($_POST['designation_cours']);
    $credits = (int)$_POST['credits'];
    $code_cours = trim($_POST['code_cours']);
    $id_option = (int)$_POST['id_option'];
    $id_enseignant = (int)$_POST['id_enseignant'];
    $id_ue = (int)$_POST['id_ue'];
    $CM = (int)$_POST['CM'];
    $P = (int)$_POST['P'];
    $TPE = (int)$_POST['TPE'];
    $annee_academique = trim($_POST['annee_academique']);

    if (!empty($designation_cours) && !empty($code_cours) && $credits > 0) {
        try {
            // Vérification : un ECUE ne peut avoir qu’un enseignant dans une même option et année
            $check = $db->prepare("
                SELECT COUNT(*) FROM cours
                WHERE designation_cours = :designation_cours
                AND id_option = :id_option
                AND annee_academique = :annee_academique
            ");
            $check->execute([
                ':designation_cours' => $designation_cours,
                ':id_option' => $id_option,
                ':annee_academique' => $annee_academique
            ]);

            if ($check->fetchColumn() > 0) {
                $message = "<p class='error beep'>⚠️ Ce cours est déjà attribué dans la même option et année.</p>";
            } else {
                $stmt = $db->prepare("
                    INSERT INTO cours (designation_cours, credits, code_cours, id_option, id_ue, CM, P, TPE, id_enseignant, annee_academique)
                    VALUES (:designation_cours, :credits, :code_cours, :id_option, :id_ue, :CM, :P, :TPE, :id_enseignant, :annee_academique)
                ");
                $stmt->execute([
                    ':designation_cours' => $designation_cours,
                    ':credits' => $credits,
                    ':code_cours' => $code_cours,
                    ':id_option' => $id_option,
                    ':id_ue' => $id_ue,
                    ':CM' => $CM,
                    ':P' => $P,
                    ':TPE' => $TPE,
                    ':id_enseignant' => $id_enseignant,
                    ':annee_academique' => $annee_academique
                ]);
                $message = "<p class='success' id='msg'>✅ ECUE ajouté avec succès !</p>";
            }
        } catch (PDOException $e) {
            $message = "<p class='error'>Erreur : " . $e->getMessage() . "</p>";
        }
    } else {
        $message = "<p class='error beep'>⚠️ Tous les champs sont obligatoires.</p>";
    }
}

// === Mise à jour d’un cours ===
if (isset($_POST['update'])) {
    $id_cours = (int)$_POST['id_cours'];
    $designation_cours = trim($_POST['designation_cours']);
    $credits = (int)$_POST['credits'];
    $code_cours = trim($_POST['code_cours']);
    $id_option = (int)$_POST['id_option'];
    $id_ue = (int)$_POST['id_ue'];
    $CM = (int)$_POST['CM'];
    $P = (int)$_POST['P'];
    $TPE = (int)$_POST['TPE'];
    $id_enseignant = (int)$_POST['id_enseignant'];
    $annee_academique = trim($_POST['annee_academique']);

    try {
        $stmt = $db->prepare("
            UPDATE cours 
            SET designation_cours = :designation_cours, credits = :credits, code_cours = :code_cours, 
                id_option = :id_option, id_ue = :id_ue, CM = :CM, P = :P, TPE = :TPE,
                id_enseignant = :id_enseignant, annee_academique = :annee_academique
            WHERE id_cours = :id_cours
        ");
        $stmt->execute([
            ':designation_cours' => $designation_cours,
            ':credits' => $credits,
            ':code_cours' => $code_cours,
            ':id_option' => $id_option,
            ':id_ue' => $id_ue,
            ':CM' => $CM,
            ':P' => $P,
            ':TPE' => $TPE,
            ':id_enseignant' => $id_enseignant,
            ':annee_academique' => $annee_academique,
            ':id_cours' => $id_cours
        ]);
        $message = "<p class='success' id='msg'>✅ ECUE mis à jour avec succès !</p>";
    } catch (PDOException $e) {
        $message = "<p class='error'>Erreur : " . $e->getMessage() . "</p>";
    }
}

// === Suppression ===
if (isset($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM cours WHERE id_cours = :id");
    $stmt->execute([':id' => $_GET['delete']]);
    $message = "<p class='success' id='msg'>🗑️ ECUE supprimé avec succès.</p>";
}

// === PAGINATION ===
$limit = 5;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

$totalRows = $db->query("SELECT COUNT(*) FROM cours")->fetchColumn();
$totalPages = ceil($totalRows / $limit);

$stmt = $db->prepare("
    SELECT c.*, o.designation_option, f.designation_filiere, e.nom_complet, e.niveau_etude, u.intitule_ue
    FROM cours c
    JOIN options o ON c.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    LEFT JOIN enseignants e ON c.id_enseignant = e.id_enseignant
    LEFT JOIN ues u ON c.id_ue = u.id_ue
    ORDER BY f.designation_filiere, o.designation_option, c.designation_cours
    LIMIT :limit OFFSET :offset
");
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Gestion des ECUE</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
body{font-family:'Segoe UI';background:#f4f7fb;margin:0;padding:0;}
header{background:linear-gradient(90deg,#0b3b6a,#c58a00);color:#fff;text-align:center;padding:1rem;}
.container{width:95%;max-width:1200px;margin:30px auto;background:#fff;padding:25px;border-radius:10px;box-shadow:0 3px 10px rgba(0,0,0,0.1);}
.btn{background:#28a745;color:#fff;border:none;padding:10px 18px;border-radius:6px;cursor:pointer;text-decoration:none;}
.btn:hover{background:#218838;}
form{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;}
form input,form select{flex:1;padding:10px;border-radius:6px;border:1px solid #ccc;font-size:1rem;}
form button{background:#007bff;color:#fff;border:none;padding:10px 15px;border-radius:6px;cursor:pointer;}
form button:hover{background:#0056b3;}
table{width:100%;border-collapse:collapse;margin-top:15px;}
th{background:#0b3b6a;color:#fff;padding:12px;text-align:left;}
td{padding:10px;border-bottom:1px solid #ddd;}
tr:hover{background:#f8f9fa;}
.delete-btn{background:#dc3545;color:#fff;border:none;padding:6px 12px;border-radius:5px;cursor:pointer;}
.delete-btn:hover{background:#b52a36;}
.edit-btn{background:#ffc107;color:#000;border:none;padding:6px 12px;border-radius:5px;cursor:pointer;}
.edit-btn:hover{background:#e0a800;}
.pagination{text-align:center;margin-top:20px;}
.pagination a{display:inline-block;margin:0 5px;padding:8px 14px;border-radius:5px;border:1px solid #ccc;text-decoration:none;color:#007bff;}
.pagination a.active{background:#007bff;color:#fff;font-weight:bold;}
.pagination a:hover{background:#0056b3;color:#fff;}
.modal{display:none;position:fixed;z-index:999;left:0;top:0;width:100%;height:100%;background:rgba(0,0,0,0.5);}
.modal-content{background:#fff;margin:10% auto;padding:20px;border-radius:10px;width:80%;max-width:700px;}
.close{float:right;font-size:1.5rem;cursor:pointer;color:#dc3545;}
.close:hover{color:#b52a36;}
</style>
</head>
<body>

<header><h1><i class="fa fa-book-open"></i> Gestion des ECUE</h1></header>
<div class="container">
<?= $message ?? '' ?>
<a href="admin_dashboard.php" class="btn"><i class="fa fa-home"></i> Accueil</a><br><br>

<form method="POST">
<input type="text" name="designation_cours" placeholder="Intitulé de l’ECUE" required>
<input type="text" name="code_cours" placeholder="Code ECUE" required>
<input type="number" name="credits" placeholder="Cd ECUE" required>
<select name="id_ue" required>
<option value="">-- Unité d’Enseignement (UE) --</option>
<?php foreach($ueList as $u): ?>
<option value="<?= $u['id_ue'] ?>"><?= htmlspecialchars($u['code_ue'].' - '.$u['intitule_ue']) ?></option>
<?php endforeach; ?>
</select>
<input type="number" name="CM" placeholder="Heures CM" required>
<input type="number" name="P" placeholder="Heures P" required>
<input type="number" name="TPE" placeholder="Heures TPE" required>
<select name="id_option" required>
<option value="">-- Option --</option>
<?php foreach($optionsList as $o): ?>
<option value="<?= $o['id_option'] ?>"><?= htmlspecialchars($o['designation_option']) ?> (<?= htmlspecialchars($o['designation_filiere'] ?? '—') ?>)</option>
<?php endforeach; ?>
</select>
<select name="id_enseignant" required>
<option value="">-- Enseignant --</option>
<?php foreach($enseignantList as $e): ?>
<option value="<?= $e['id_enseignant'] ?>"><?= htmlspecialchars($e['niveau_etude'].' - '.$e['nom_complet']) ?></option>
<?php endforeach; ?>
</select>
<select name="annee_academique" required>
<option value="">-- Année --</option>
<?php $y=2024;for($i=0;$i<15;$i++){echo"<option>$y-".($y+1)."</option>";$y++;} ?>
</select>
<button type="submit" name="add"><i class="fa fa-plus"></i> Ajouter</button>
</form>

<table>
<tr><th>UE</th><th>ECUE</th><th>Code ECUE</th><th>Cd ECUE</th><th>CM</th><th>P</th><th>TPE</th><th>Option</th><th>Enseignant</th><th>Année</th><th>Actions</th></tr>
<?php foreach($courses as $c): ?>
<tr>
<td><?= htmlspecialchars($c['intitule_ue'] ?? '—') ?></td>
<td><?= htmlspecialchars($c['designation_cours']) ?></td>
<td><?= htmlspecialchars($c['code_cours']) ?></td>
<td><?= $c['credits'] ?></td>
<td><?= $c['CM'] ?></td>
<td><?= $c['P'] ?></td>
<td><?= $c['TPE'] ?></td>
<td><?= htmlspecialchars($c['designation_option']) ?></td>
<td><?= htmlspecialchars($c['niveau_etude'].' - '.$c['nom_complet']) ?></td>
<td><?= htmlspecialchars($c['annee_academique']) ?></td>
<td>
<button type="button" class="edit-btn" onclick='openModal(<?= json_encode($c, JSON_HEX_APOS|JSON_HEX_QUOT) ?>)'><i class="fa fa-pen"></i> Modifier</button>
<a href="?delete=<?= $c['id_cours'] ?>" onclick="return confirm('Supprimer cet ECUE ?')">
<button type="button" class="delete-btn"><i class="fa fa-trash"></i> Supprimer</button></a>
</td>
</tr>
<?php endforeach; ?>
</table>

<div class="pagination">
<?php if ($page > 1): ?><a href="?page=<?= $page-1 ?>"><i class="fa fa-arrow-left"></i> Précédent</a><?php endif; ?>
<span>Page <?= $page ?> / <?= $totalPages ?></span>
<?php if ($page < $totalPages): ?><a href="?page=<?= $page+1 ?>">Suivant <i class="fa fa-arrow-right"></i></a><?php endif; ?>
</div>
</div>

<!-- MODALE -->
<div id="editModal" class="modal">
<div class="modal-content">
<span class="close" onclick="closeModal()">&times;</span>
<h3>✏️ Modifier l’ECUE</h3>
<form method="POST">
<input type="hidden" id="id_cours" name="id_cours">
<input type="text" id="designation_cours" name="designation_cours" required>
<input type="text" id="code_cours" name="code_cours" required>
<input type="number" id="credits" name="credits" required>
<select id="id_ue" name="id_ue" required>
<?php foreach($ueList as $u): ?>
<option value="<?= $u['id_ue'] ?>"><?= htmlspecialchars($u['code_ue'].' - '.$u['intitule_ue']) ?></option>
<?php endforeach; ?>
</select>
<input type="number" id="CM" name="CM" placeholder="Heures CM" required>
<input type="number" id="P" name="P" placeholder="Heures P" required>
<input type="number" id="TPE" name="TPE" placeholder="Heures TPE" required>
<select id="id_option" name="id_option" required>
<?php foreach($optionsList as $o): ?>
<option value="<?= $o['id_option'] ?>"><?= htmlspecialchars($o['designation_option']) ?></option>
<?php endforeach; ?>
</select>
<select id="id_enseignant" name="id_enseignant" required>
<?php foreach($enseignantList as $e): ?>
<option value="<?= $e['id_enseignant'] ?>"><?= htmlspecialchars($e['nom_complet']) ?></option>
<?php endforeach; ?>
</select>
<select id="annee_academique" name="annee_academique" required>
<?php $y=2024;for($i=0;$i<15;$i++){echo"<option>$y-".($y+1)."</option>";$y++;} ?>
</select>
<button type="submit" name="update"><i class="fa fa-save"></i> Enregistrer</button>
</form>
</div>
</div>

<script>
function openModal(data){
  const modal=document.getElementById('editModal');
  modal.style.display='block';
  document.getElementById('id_cours').value=data.id_cours;
  document.getElementById('designation_cours').value=data.designation_cours;
  document.getElementById('code_cours').value=data.code_cours;
  document.getElementById('credits').value=data.credits;
  document.getElementById('id_ue').value=data.id_ue;
  document.getElementById('CM').value=data.CM;
  document.getElementById('P').value=data.P;
  document.getElementById('TPE').value=data.TPE;
  document.getElementById('id_option').value=data.id_option;
  document.getElementById('id_enseignant').value=data.id_enseignant;
  document.getElementById('annee_academique').value=data.annee_academique;
}
function closeModal(){document.getElementById('editModal').style.display='none';}
</script>
</body>
</html>
