<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

// Vérification de la session
if (!isset($_SESSION['role'])) {
    header("Location: ../login.php");
    exit();
}

require_once '../config/db.php';

// === Filtre : Type de document ===
$filtre_type = $_GET['type_doc'] ?? '';

// === Condition principale : concerne = 'Enseignant' ===
$where = "WHERE concerne = 'Enseignant'";
$params = [];

if ($filtre_type !== '') {
    $where .= " AND type_doc = :type_doc";
    $params[':type_doc'] = $filtre_type;
}

// === Pagination ===
$limit = 7;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// --- Compter le total filtré ---
$countSql = "SELECT COUNT(*) FROM correspondances $where";
$countStmt = $db->prepare($countSql);
if ($filtre_type !== '') {
    $countStmt->bindValue(':type_doc', $filtre_type, PDO::PARAM_STR);
}
$countStmt->execute();
$totalRows = (int)$countStmt->fetchColumn();
$totalPages = max(1, ceil($totalRows / $limit));

// --- Requête principale ---
$query = "SELECT * FROM correspondances $where ORDER BY date_envoi DESC LIMIT $limit OFFSET $offset";
$stmt = $db->prepare($query);
if ($filtre_type !== '') {
    $stmt->bindValue(':type_doc', $filtre_type, PDO::PARAM_STR);
}
$stmt->execute();
$docs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Communiqués – Enseignants | HETEC</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
body {
  font-family: "Segoe UI", sans-serif;
  background: #f4f7fb;
  margin: 0;
  display: flex;
}

/* ===== SIDEBAR ===== */
.sidebar {
  width: 230px;
  background: linear-gradient(180deg, #0b3b6a, #082f55);
  color: white;
  height: 100vh;
  position: fixed;
  left: 0;
  top: 0;
  padding-top: 20px;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 6px rgba(0,0,0,0.2);
}
.sidebar .logo {
  text-align: center;
  margin-bottom: 25px;
}
.sidebar .logo img {
  width: 60px;
  border-radius: 50%;
}
.sidebar .logo h2 {
  margin: 10px 0 0;
  font-size: 1.1rem;
  letter-spacing: 1px;
}
.sidebar .menu {
  display: flex;
  flex-direction: column;
}
.sidebar .menu a {
  display: flex;
  align-items: center;
  color: white;
  text-decoration: none;
  padding: 12px 20px;
  gap: 12px;
  transition: 0.3s;
  border-left: 4px solid transparent;
}
.sidebar .menu a i {
  width: 20px;
  text-align: center;
}
.sidebar .menu a:hover, .sidebar .menu a.active {
  background: #c58a00;
  border-left: 4px solid #fff;
}

/* ===== MAIN CONTENT ===== */
.main {
  margin-left: 230px;
  flex: 1;
  padding: 25px;
}
header {
  background: linear-gradient(90deg, #0b3b6a, #c58a00);
  color: #fff;
  padding: 15px;
  border-radius: 8px;
  text-align: center;
}
.container {
  margin-top: 20px;
  background: #fff;
  border-radius: 10px;
  padding: 20px;
  box-shadow: 0 3px 10px rgba(0,0,0,0.1);
}
.filter-bar {
  background: #f1f1f1;
  padding: 10px;
  border-radius: 6px;
  margin-bottom: 15px;
  display: flex;
  gap: 10px;
}
.filter-bar select, .filter-bar button {
  padding: 10px;
  border-radius: 6px;
  border: 1px solid #ccc;
  font-size: 1rem;
}
.filter-bar button {
  background: #007bff;
  color: #fff;
  cursor: pointer;
  border: none;
}
.filter-bar button:hover {
  background: #0056b3;
}
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 15px;
}
th {
  background: #0b3b6a;
  color: #fff;
  padding: 12px;
  text-align: left;
}
td {
  padding: 10px;
  border-bottom: 1px solid #ddd;
}
tr:hover {
  background: #f8f9fa;
}
.counter {
  font-weight: bold;
  color: #0b3b6a;
  margin-bottom: 10px;
}
a.view-file {
  color: #007bff;
  text-decoration: none;
}
a.view-file:hover {
  text-decoration: underline;
}
.pagination {
  text-align: center;
  margin-top: 20px;
}
.pagination a {
  display: inline-block;
  margin: 0 5px;
  padding: 8px 14px;
  border-radius: 5px;
  border: 1px solid #ccc;
  text-decoration: none;
  color: #007bff;
}
.pagination a.active {
  background: #007bff;
  color: #fff;
}
.pagination a:hover {
  background: #0056b3;
  color: #fff;
}
</style>
<script>
function logout(){
  if(confirm("Voulez-vous vraiment vous déconnecter ?")){
    window.location.href = "../logout.php";
  }
}
</script>
</head>
<body>

<!-- ======== SIDEBAR ======== -->
<aside class="sidebar">
  <div class="logo">
    <img src="../img/hetec.jpg-2.webp" alt="HETEC">
    <h2>HETEC</h2>
  </div>
  <nav class="menu">
    <a href="enseignant_dashboard.html"><i class="fa-solid fa-house"></i><span>Accueil</span></a>
    <a href="mes_cours.php"><i class="fa-solid fa-book"></i><span>Mes Cours</span></a>
    <a href="cotations.php"><i class="fa-solid fa-graduation-cap"></i><span>Attribuer les notes</span></a>
    <a href="communiques_ens.php" class="active"><i class="fa-solid fa-bullhorn"></i><span>Les communiqués</span></a>
    <a href="profil_ens.php"><i class="fa-solid fa-user"></i><span>Profil</span></a>
    
  </nav>
</aside>

<!-- ======== MAIN CONTENT ======== -->
<div class="main">
  <header>
    <h1><i class="fa fa-bullhorn"></i> Communiqués destinés aux Enseignants</h1>
  </header>

  <div class="container">
    <form method="GET" class="filter-bar">
      <select name="type_doc">
          <option value="">Tous types</option>
          <option value="Lettre" <?= $filtre_type=='Lettre'?'selected':'' ?>>Lettre</option>
          <option value="Communiqué officiel" <?= $filtre_type=='Communiqué officiel'?'selected':'' ?>>Communiqué officiel</option>
          <option value="Avis" <?= $filtre_type=='Avis'?'selected':'' ?>>Avis</option>
          <option value="Note de service" <?= $filtre_type=='Note de service'?'selected':'' ?>>Note de service</option>
      </select>
      <button type="submit"><i class="fa fa-search"></i> Rechercher</button>
    </form>

    <p class="counter">
      <?= $totalRows ?> communiqué<?= $totalRows > 1 ? 's' : '' ?> trouvé<?= $filtre_type ? " (type : <b>" . htmlspecialchars($filtre_type) . "</b>)" : '' ?>.
    </p>

    <table>
      <tr>
        <th>Type</th>
        <th>Objet</th>
        <th>Date</th>
        <th>Statut</th>
        <th>Fichier</th>
      </tr>
      <?php if ($docs): foreach($docs as $d): ?>
      <tr>
        <td><?= htmlspecialchars($d['type_doc']) ?></td>
        <td><?= htmlspecialchars($d['objet']) ?></td>
        <td><?= htmlspecialchars($d['date_envoi']) ?></td>
        <td><?= htmlspecialchars($d['statut']) ?></td>
        <td>
          <?php if ($d['fichier']): ?>
          <a class="view-file" href="../uploads/correspondances/<?= htmlspecialchars($d['fichier']) ?>" target="_blank">
            <i class="fa fa-download"></i> Voir
          </a>
          <?php else: ?>—<?php endif; ?>
        </td>
      </tr>
      <?php endforeach; else: ?>
      <tr><td colspan="5" style="text-align:center;color:#888;">Aucun communiqué trouvé.</td></tr>
      <?php endif; ?>
    </table>

    <div class="pagination">
      <?php if ($page > 1): ?>
        <a href="?page=<?= $page - 1 ?>"><i class="fa fa-arrow-left"></i> Précédent</a>
      <?php endif; ?>
      <span>Page <?= $page ?> / <?= $totalPages ?></span>
      <?php if ($page < $totalPages): ?>
        <a href="?page=<?= $page + 1 ?>">Suivant <i class="fa fa-arrow-right"></i></a>
      <?php endif; ?>
    </div>
  </div>
</div>

</body>
</html>
