<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  header("Location: ../login.php");
  exit();
}

require_once '../config/db.php';

// === SUPPRESSION ===
if (isset($_GET['delete'])) {
  $id = (int)$_GET['delete'];
  try {
    $stmt = $db->prepare("DELETE FROM parametres_systeme WHERE id_param = :id");
    $stmt->execute([':id' => $id]);
    $message = "<p class='success' id='msg'>🗑️ Paramètre supprimé avec succès.</p>";
  } catch (PDOException $e) {
    $message = "<p class='error'>Erreur SQL : " . $e->getMessage() . "</p>";
  }
}

// === RÉCUPÉRER TOUS LES PARAMÈTRES ===
$stmt = $db->query("SELECT * FROM parametres_systeme ORDER BY id_param DESC");
$params = $stmt->fetchAll(PDO::FETCH_ASSOC);

// === AJOUT OU MISE À JOUR ===
if (isset($_POST['update_param'])) {
  $id_param = isset($_POST['id_param']) ? (int)$_POST['id_param'] : 0;
  $nom_institution = trim($_POST['nom_institution']);
  $email_contact = trim($_POST['email_contact']);
  $telephone_contact = trim($_POST['telephone_contact']);
  $adresse = trim($_POST['adresse']);
  $site_web = trim($_POST['site_web']);

  try {
    if ($id_param > 0) {
      // Mise à jour
      $stmt = $db->prepare("UPDATE parametres_systeme 
        SET nom_institution=:nom, email_contact=:email, telephone_contact=:tel, 
            adresse=:adr, site_web=:site, date_modification=NOW() 
        WHERE id_param=:id");
      $stmt->execute([
        ':nom' => $nom_institution,
        ':email' => $email_contact,
        ':tel' => $telephone_contact,
        ':adr' => $adresse,
        ':site' => $site_web,
        ':id' => $id_param
      ]);
      $message = "<p class='success' id='msg'>✅ Paramètre modifié avec succès !</p>";
    } else {
      // Ajout
      $stmt = $db->prepare("INSERT INTO parametres_systeme 
        (nom_institution, email_contact, telephone_contact, adresse, site_web, date_modification)
        VALUES (:nom, :email, :tel, :adr, :site, NOW())");
      $stmt->execute([
        ':nom' => $nom_institution,
        ':email' => $email_contact,
        ':tel' => $telephone_contact,
        ':adr' => $adresse,
        ':site' => $site_web
      ]);
      $message = "<p class='success' id='msg'>✅ Nouveau paramètre ajouté avec succès !</p>";
    }
  } catch (PDOException $e) {
    $message = "<p class='error'>Erreur SQL : " . $e->getMessage() . "</p>";
  }

  // Rechargement
  $stmt = $db->query("SELECT * FROM parametres_systeme ORDER BY id_param DESC");
  $params = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sécurité & Paramètres</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp"> <!-- Ajout de l'icône dans l'onglet -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
:root {
  --primary: #0b3b6a;
  --secondary: #c58a00;
  --bg: #f4f7fb;
  --text: #222;
  --card: #fff;
}
body.dark {
  --bg: #1e1e2f;
  --text: #f5f5f5;
  --card: #2a2a3d;
  --primary: #c58a00;
  --secondary: #0b3b6a;
}
body {
  font-family: "Segoe UI", sans-serif;
  background: var(--bg);
  color: var(--text);
  margin: 0;
  padding: 0;
  transition: background 0.3s, color 0.3s;
}
header {
  background: linear-gradient(90deg, var(--primary), var(--secondary));
  color: #fff;
  text-align: center;
  padding: 1rem;
  position: relative;
}
.toggle-container {
  position: absolute;
  top: 15px;
  right: 20px;
  display: flex;
  align-items: center;
  gap: 8px;
}
.switch {
  position: relative;
  display: inline-block;
  width: 50px;
  height: 26px;
}
.switch input {opacity: 0;width: 0;height: 0;}
.slider {
  position: absolute;
  cursor: pointer;
  top: 0; left: 0; right: 0; bottom: 0;
  background-color: #ccc;
  transition: .4s;
  border-radius: 34px;
}
.slider:before {
  position: absolute;
  content: "";
  height: 18px;
  width: 18px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  transition: .4s;
  border-radius: 50%;
}
input:checked + .slider {background-color: var(--secondary);}
input:checked + .slider:before {transform: translateX(24px);}
.container {
  width: 90%;
  max-width: 1100px;
  margin: 30px auto;
  background: var(--card);
  padding: 25px;
  border-radius: 10px;
  box-shadow: 0 3px 10px rgba(0,0,0,0.1);
  transition: background 0.3s;
}
h1 {margin: 0;}
h2 {
  color: var(--primary);
  border-bottom: 2px solid var(--secondary);
  padding-bottom: 5px;
  margin-top: 25px;
}
.section {margin-bottom: 30px;}
label {
  display: block;
  margin-top: 10px;
  font-weight: bold;
}
input, textarea {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 6px;
  margin-top: 5px;
  font-size: 1rem;
  background: var(--bg);
  color: var(--text);
  transition: background 0.3s, color 0.3s;
}
button {
  background: var(--primary);
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 6px;
  margin-top: 10px;
  cursor: pointer;
  font-weight: bold;
  transition: background 0.3s;
}
button:hover {background: var(--secondary);}
.btn {
  background-color: #28a745;
  color: #fff;
  padding: 10px 15px;
  border-radius: 6px;
  text-decoration: none;
  margin-bottom: 15px;
  display: inline-block;
}
.btn:hover {background-color: #218838;}
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 25px;
}
th {
  background: var(--primary);
  color: white;
  padding: 10px;
  text-align: left;
}
td {
  padding: 10px;
  border-bottom: 1px solid #ddd;
}
tr:hover {background: #f8f9fa;}
.action-btn {
  border: none;
  border-radius: 5px;
  padding: 6px 10px;
  cursor: pointer;
  color: white;
}
.edit-btn {background: #007bff;}
.edit-btn:hover {background: #0056b3;}
.delete-btn {background: #dc3545;}
.delete-btn:hover {background: #b52a36;}
.message {
  text-align: center;
  font-weight: bold;
  padding: 10px;
  border-radius: 6px;
  margin-top: 10px;
}
.success {color: green; background: #e9f9e9;}
.error {color: red; background: #f9e9e9;}
</style>
</head>
<body>

<header>
  <h1><i class="fa-solid fa-lock"></i> Sécurité & Paramètres</h1>
  <div class="toggle-container">
    <span>🌞</span>
    <label class="switch">
      <input type="checkbox" id="modeSwitch">
      <span class="slider"></span>
    </label>
    <span>🌙</span>
  </div>
</header>

<div class="container">
  <?= $message ?? '' ?>

  <a href="admin_dashboard.php" class="btn"><i class="fa-solid fa-home"></i> Accueil</a>

  <!-- FORMULAIRE -->
  <div class="section">
    <h2><i class="fa-solid fa-gear"></i> Ajouter / Modifier un Paramètre</h2>
    <form method="POST" action="parametres.php">
      <input type="hidden" name="id_param" id="id_param">
      <label>Nom de l’institution :</label>
      <input type="text" name="nom_institution" id="nom_institution" required>

      <label>Email de contact :</label>
      <input type="email" name="email_contact" id="email_contact">

      <label>Téléphone :</label>
      <input type="text" name="telephone_contact" id="telephone_contact">

      <label>Adresse :</label>
      <textarea name="adresse" id="adresse"></textarea>

      <label>Site web :</label>
      <input type="text" name="site_web" id="site_web">

      <button type="submit" name="update_param"><i class="fa-solid fa-save"></i> Enregistrer</button>
    </form>
  </div>

  <!-- TABLEAU -->
  <h2><i class="fa-solid fa-database"></i> Liste des Paramètres</h2>
  <table>
    <thead>
      <tr>
        <th>Institution</th>
        <th>Email</th>
        <th>Téléphone</th>
        <th>Adresse</th>
        <th>Site web</th>
        <th>Date maj</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($params as $p): ?>
      <tr>
        <td><?= htmlspecialchars($p['nom_institution']) ?></td>
        <td><?= htmlspecialchars($p['email_contact']) ?></td>
        <td><?= htmlspecialchars($p['telephone_contact']) ?></td>
        <td><?= htmlspecialchars($p['adresse']) ?></td>
        <td><?= htmlspecialchars($p['site_web']) ?></td>
        <td><?= htmlspecialchars($p['date_modification']) ?></td>
        <td>
          <button class="action-btn edit-btn" 
            onclick="editParam(<?= $p['id_param'] ?>, '<?= htmlspecialchars(addslashes($p['nom_institution'])) ?>', 
            '<?= htmlspecialchars(addslashes($p['email_contact'])) ?>', 
            '<?= htmlspecialchars(addslashes($p['telephone_contact'])) ?>', 
            '<?= htmlspecialchars(addslashes($p['adresse'])) ?>', 
            '<?= htmlspecialchars(addslashes($p['site_web'])) ?>')">
            <i class="fa-solid fa-pen-to-square"></i>
          </button>
          <a href="parametres.php?delete=<?= $p['id_param'] ?>" onclick="return confirm('Supprimer ce paramètre ?')">
            <button class="action-btn delete-btn"><i class="fa-solid fa-trash"></i></button>
          </a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<script>
function editParam(id, nom, email, tel, adr, site) {
  document.getElementById("id_param").value = id;
  document.getElementById("nom_institution").value = nom;
  document.getElementById("email_contact").value = email;
  document.getElementById("telephone_contact").value = tel;
  document.getElementById("adresse").value = adr;
  document.getElementById("site_web").value = site;
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// 🌙 Dark mode persisté
const toggleSwitch = document.getElementById('modeSwitch');
const body = document.body;
if (localStorage.getItem("theme") === "dark") {
  body.classList.add("dark");
  toggleSwitch.checked = true;
}
toggleSwitch.addEventListener("change", () => {
  if (toggleSwitch.checked) {
    body.classList.add("dark");
    localStorage.setItem("theme", "dark");
  } else {
    body.classList.remove("dark");
    localStorage.setItem("theme", "light");
  }
});
</script>

</body>
</html>
