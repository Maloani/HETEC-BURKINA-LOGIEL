<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

require_once '../config/db.php';

// === AJOUT D’UNE UE ===
if (isset($_POST['add'])) {
    $qualite = $_POST['qualite'];
    $code_ue = trim($_POST['code_ue']);
    $intitule_ue = trim($_POST['intitule_ue']);
    $nc_ue = (int)$_POST['nc_ue'];

    if (!empty($code_ue) && !empty($intitule_ue)) {
        $check = $db->prepare("SELECT COUNT(*) FROM ues WHERE code_ue = :code");
        $check->execute([':code' => $code_ue]);

        if ($check->fetchColumn() > 0) {
            $message = "<p class='error beep'>⚠️ Ce code UE existe déjà.</p>";
        } else {
            $stmt = $db->prepare("
                INSERT INTO ues (qualite, code_ue, intitule_ue, nc_ue)
                VALUES (:qualite, :code, :intitule, :nc)
            ");
            $stmt->execute([
                ':qualite' => $qualite,
                ':code' => $code_ue,
                ':intitule' => $intitule_ue,
                ':nc' => $nc_ue
            ]);
            $message = "<p class='success' id='msg'>✅ UE ajoutée avec succès !</p>";
        }
    } else {
        $message = "<p class='error beep'>⚠️ Tous les champs sont obligatoires.</p>";
    }
}

// === MISE À JOUR ===
if (isset($_POST['update'])) {
    $id_ue = (int)$_POST['id_ue'];
    $qualite = $_POST['qualite'];
    $code_ue = trim($_POST['code_ue']);
    $intitule_ue = trim($_POST['intitule_ue']);
    $nc_ue = (int)$_POST['nc_ue'];

    $check = $db->prepare("SELECT COUNT(*) FROM ues WHERE code_ue = :code AND id_ue != :id");
    $check->execute([':code' => $code_ue, ':id' => $id_ue]);

    if ($check->fetchColumn() > 0) {
        $message = "<p class='error beep'>⚠️ Ce code UE existe déjà pour une autre unité.</p>";
    } else {
        $stmt = $db->prepare("
            UPDATE ues 
            SET qualite = :qualite, code_ue = :code, intitule_ue = :intitule, nc_ue = :nc
            WHERE id_ue = :id
        ");
        $stmt->execute([
            ':qualite' => $qualite,
            ':code' => $code_ue,
            ':intitule' => $intitule_ue,
            ':nc' => $nc_ue,
            ':id' => $id_ue
        ]);
        $message = "<p class='success' id='msg'>✅ UE mise à jour avec succès !</p>";
    }
}

// === SUPPRESSION ===
if (isset($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM ues WHERE id_ue = :id");
    $stmt->execute([':id' => $_GET['delete']]);
    $message = "<p class='success' id='msg'>🗑️ UE supprimée avec succès.</p>";
}

// === PAGINATION ===
$limit = 5;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

$totalRows = $db->query("SELECT COUNT(*) FROM ues")->fetchColumn();
$totalPages = ceil($totalRows / $limit);

$stmt = $db->prepare("SELECT * FROM ues ORDER BY qualite, code_ue LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$ues = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Gestion des Unités d’Enseignement (UE)</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
body{font-family:'Segoe UI';background:#f4f7fb;margin:0;padding:0;}
header{background:linear-gradient(90deg,#0b3b6a,#c58a00);color:#fff;text-align:center;padding:1rem;}
.container{width:90%;max-width:1000px;margin:30px auto;background:#fff;padding:25px;border-radius:10px;box-shadow:0 3px 10px rgba(0,0,0,0.1);}
.btn{background:#28a745;color:#fff;border:none;padding:10px 18px;border-radius:6px;cursor:pointer;text-decoration:none;}
.btn:hover{background:#218838;}
form{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;}
form input,form select{flex:1;padding:10px;border-radius:6px;border:1px solid #ccc;font-size:1rem;}
form button{background:#007bff;color:#fff;border:none;padding:10px 15px;border-radius:6px;cursor:pointer;}
form button:hover{background:#0056b3;}
table{width:100%;border-collapse:collapse;margin-top:15px;}
th{background:#0b3b6a;color:#fff;padding:12px;text-align:left;}
td{padding:10px;border-bottom:1px solid #ddd;}
tr:hover{background:#f8f9fa;}
.delete-btn{background:#dc3545;color:#fff;border:none;padding:6px 12px;border-radius:5px;cursor:pointer;}
.delete-btn:hover{background:#b52a36;}
.edit-btn{background:#ffc107;color:#000;border:none;padding:6px 12px;border-radius:5px;cursor:pointer;}
.edit-btn:hover{background:#e0a800;}
.pagination{text-align:center;margin-top:20px;}
.pagination a{display:inline-block;margin:0 5px;padding:8px 14px;border-radius:5px;border:1px solid #ccc;text-decoration:none;color:#007bff;}
.pagination a.active{background:#007bff;color:#fff;font-weight:bold;}
.pagination a:hover{background:#0056b3;color:#fff;}
.modal{display:none;position:fixed;z-index:999;left:0;top:0;width:100%;height:100%;background:rgba(0,0,0,0.5);}
.modal-content{background:#fff;margin:10% auto;padding:20px;border-radius:10px;width:80%;max-width:600px;}
.close{float:right;font-size:1.5rem;cursor:pointer;color:#dc3545;}
.close:hover{color:#b52a36;}
</style>
</head>
<body>

<header><h1><i class="fa fa-layer-group"></i> Gestion des Unités d’Enseignement</h1></header>
<div class="container">
<?= $message ?? '' ?>

<a href="admin_dashboard.php" class="btn"><i class="fa fa-home"></i> Accueil</a><br><br>

<form method="POST">
<select name="qualite" required>
    <option value="">-- Qualité de l’UE --</option>
    <option value="UEF">UEF (Fondamentale)</option>
    <option value="UET">UET (Transversale)</option>
</select>
<input type="text" name="code_ue" placeholder="Code UE (ex: ADE1500)" required>
<input type="text" name="intitule_ue" placeholder="Intitulé de l’UE" required>
<input type="number" name="nc_ue" placeholder="NC/UE (crédits)" required>
<button type="submit" name="add"><i class="fa fa-plus"></i> Ajouter</button>
</form>

<table>
<tr>
<th>Qualité</th>
<th>Code</th>
<th>Intitulé</th>
<th>Crédits</th>
<th>Actions</th>
</tr>

<?php foreach($ues as $ue): ?>
<tr>
<td><?= htmlspecialchars($ue['qualite']) ?></td>
<td><?= htmlspecialchars($ue['code_ue']) ?></td>
<td><?= htmlspecialchars($ue['intitule_ue']) ?></td>
<td><?= htmlspecialchars($ue['nc_ue']) ?></td>
<td>
<button type="button" class="edit-btn" onclick='openModal(<?= json_encode($ue, JSON_HEX_APOS|JSON_HEX_QUOT) ?>)'><i class="fa fa-pen"></i> Modifier</button>
<a href="?delete=<?= $ue['id_ue'] ?>" onclick="return confirm('Supprimer cette UE ?')">
<button type="button" class="delete-btn"><i class="fa fa-trash"></i> Supprimer</button></a>
</td>
</tr>
<?php endforeach; ?>
</table>

<div class="pagination">
<?php if ($page > 1): ?><a href="?page=<?= $page-1 ?>"><i class="fa fa-arrow-left"></i> Précédent</a><?php endif; ?>
<span>Page <?= $page ?> / <?= $totalPages ?></span>
<?php if ($page < $totalPages): ?><a href="?page=<?= $page+1 ?>">Suivant <i class="fa fa-arrow-right"></i></a><?php endif; ?>
</div>
</div>

<!-- MODALE -->
<div id="editModal" class="modal">
<div class="modal-content">
<span class="close" onclick="closeModal()">&times;</span>
<h3>✏️ Modifier l’UE</h3>
<form method="POST">
<input type="hidden" id="id_ue" name="id_ue">
<select id="qualite" name="qualite" required>
<option value="UEF">UEF (Fondamentale)</option>
<option value="UET">UET (Transversale)</option>
</select>
<input type="text" id="code_ue" name="code_ue" placeholder="Code UE" required>
<input type="text" id="intitule_ue" name="intitule_ue" placeholder="Intitulé de l’UE" required>
<input type="number" id="nc_ue" name="nc_ue" placeholder="Crédits" required>
<button type="submit" name="update"><i class="fa fa-save"></i> Enregistrer</button>
</form>
</div>
</div>

<script>
function openModal(data){
  const modal=document.getElementById('editModal');
  modal.style.display='block';
  document.getElementById('id_ue').value=data.id_ue;
  document.getElementById('qualite').value=data.qualite;
  document.getElementById('code_ue').value=data.code_ue;
  document.getElementById('intitule_ue').value=data.intitule_ue;
  document.getElementById('nc_ue').value=data.nc_ue;
}
function closeModal(){document.getElementById('editModal').style.display='none';}
window.onclick=function(e){if(e.target==document.getElementById('editModal'))closeModal();}
</script>
</body>
</html>
