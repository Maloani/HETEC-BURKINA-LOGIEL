<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.html");
    exit();
}

require_once '../config/db.php';

// Vérifier si un ID est fourni
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("<p style='color:red;text-align:center;'>⚠️ Aucun étudiant sélectionné pour modification.</p>");
}

$id = (int)$_GET['id'];

// === Charger les informations de l’étudiant ===
$stmt = $db->prepare("SELECT * FROM inscriptions WHERE id_inscription = :id");
$stmt->execute([':id' => $id]);
$etudiant = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$etudiant) {
    die("<p style='color:red;text-align:center;'>❌ Étudiant introuvable.</p>");
}

// === Récupération des options ===
$stmtOption = $db->query("
    SELECT o.id_option, o.designation_option, f.designation_filiere
    FROM options o
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    ORDER BY f.designation_filiere ASC, o.designation_option ASC
");
$options = $stmtOption->fetchAll(PDO::FETCH_ASSOC);

// === Mise à jour ===
if (isset($_POST['update'])) {
    $nom = trim($_POST['nom_etudiant']);
    $prenom = trim($_POST['prenom_etudiant']);
    $sexe = $_POST['sexe'];
    $date_naissance = $_POST['date_naissance'];
    $lieu_naissance = trim($_POST['lieu_naissance']);
    $telephone = trim($_POST['telephone']);
    $mot_de_passe = trim($_POST['mot_de_passe']);
    $id_option = (int)$_POST['id_option'];
    $annee_academique = trim($_POST['annee_academique']);
    $grade = trim($_POST['grade']);
    $domaine = trim($_POST['domaine']);
    $mention = trim($_POST['mention']);
    $niveau = trim($_POST['niveau']);
    $semestre = trim($_POST['semestre']);
    $photo_name = $etudiant['photo_etudiant']; // par défaut

    // Upload photo si nouvelle
    if (isset($_FILES['photo_etudiant']) && $_FILES['photo_etudiant']['error'] === 0) {
        $photo_tmp_name = $_FILES['photo_etudiant']['tmp_name'];
        $photo_name = 'photos/' . basename($_FILES['photo_etudiant']['name']);
        move_uploaded_file($photo_tmp_name, '../uploads/' . $photo_name);
    }

    // Mise à jour en base
    $stmt = $db->prepare("
        UPDATE inscriptions
        SET nom_etudiant=:nom, prenom_etudiant=:prenom, sexe=:sexe, date_naissance=:date_naissance,
            lieu_naissance=:lieu, telephone=:tel, mot_de_passe=:pass, id_option=:opt, 
            grade=:grade, domaine=:domaine, mention=:mention, niveau=:niveau, semestre=:semestre,
            photo_etudiant=:photo, annee_academique=:annee
        WHERE id_inscription=:id
    ");
    $stmt->execute([
        ':nom' => $nom,
        ':prenom' => $prenom,
        ':sexe' => $sexe,
        ':date_naissance' => $date_naissance,
        ':lieu' => $lieu_naissance,
        ':tel' => $telephone,
        ':pass' => $mot_de_passe,
        ':opt' => $id_option,
        ':grade' => $grade,
        ':domaine' => $domaine,
        ':mention' => $mention,
        ':niveau' => $niveau,
        ':semestre' => $semestre,
        ':photo' => $photo_name,
        ':annee' => $annee_academique,
        ':id' => $id
    ]);

    $message = "<p class='success'>✅ Informations mises à jour avec succès.</p>";

    // Recharger les nouvelles infos
    $stmt = $db->prepare("SELECT * FROM inscriptions WHERE id_inscription = :id");
    $stmt->execute([':id' => $id]);
    $etudiant = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Modifier un Étudiant</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
body{font-family:'Segoe UI';background:#f4f7fb;margin:0;padding:0;}
header{background:linear-gradient(90deg,#0b3b6a,#c58a00);color:#fff;text-align:center;padding:1rem;}
.container{width:90%;max-width:900px;margin:30px auto;background:#fff;padding:25px;border-radius:10px;box-shadow:0 3px 10px rgba(0,0,0,0.1);}
form{display:flex;flex-wrap:wrap;gap:12px;}
form input,form select{flex:1;padding:10px;border:1px solid #ccc;border-radius:6px;font-size:1rem;}
form button{background:#007bff;color:#fff;border:none;padding:10px 18px;border-radius:6px;cursor:pointer;}
form button:hover{background:#0056b3;}
.success{color:green;text-align:center;font-weight:bold;}
.error{color:red;text-align:center;font-weight:bold;}
.back-btn{display:inline-block;margin-bottom:15px;padding:8px 15px;background:#28a745;color:#fff;text-decoration:none;border-radius:5px;}
.back-btn:hover{background:#218838;}
img.preview{width:100px;height:100px;border-radius:50%;object-fit:cover;border:2px solid #ccc;margin-top:5px;}
</style>
</head>
<body>

<header><h1><i class="fa fa-user-pen"></i> Modifier les Informations de l'Étudiant</h1></header>
<div class="container">
<?= $message ?? '' ?>

<a href="inscriptions.php" class="back-btn"><i class="fa fa-arrow-left"></i> Retour à la liste</a>

<form method="POST" enctype="multipart/form-data">
    <input type="text" name="nom_etudiant" value="<?= htmlspecialchars($etudiant['nom_etudiant'] ?? '') ?>" placeholder="Nom..." required>
    <input type="text" name="prenom_etudiant" value="<?= htmlspecialchars($etudiant['prenom_etudiant'] ?? '') ?>" placeholder="Prénom..." required>

    <select name="sexe" required>
        <option value="Homme" <?= ($etudiant['sexe'] === 'Homme') ? 'selected' : '' ?>>Homme</option>
        <option value="Femme" <?= ($etudiant['sexe'] === 'Femme') ? 'selected' : '' ?>>Femme</option>
    </select>

    <input type="date" name="date_naissance" value="<?= htmlspecialchars($etudiant['date_naissance'] ?? '') ?>" required>
    <input type="text" name="lieu_naissance" value="<?= htmlspecialchars($etudiant['lieu_naissance'] ?? '') ?>" placeholder="Lieu de naissance..." required>
    <input type="text" name="telephone" value="<?= htmlspecialchars($etudiant['telephone'] ?? '') ?>" placeholder="Téléphone..." required>
    <input type="text" name="mot_de_passe" value="<?= htmlspecialchars($etudiant['mot_de_passe'] ?? '') ?>" placeholder="Mot de passe..." required>

    <!-- 🧩 Nouveaux champs académiques -->
    <select name="grade" required>
        <option value="">-- Grade --</option>
        <option value="LICENCE PROFESSIONNELLE" <?= ($etudiant['grade'] === 'LICENCE PROFESSIONNELLE') ? 'selected' : '' ?>>LICENCE PROFESSIONNELLE</option>
        <option value="MASTER PROFESSIONNELLE" <?= ($etudiant['grade'] === 'MASTER PROFESSIONNELLE') ? 'selected' : '' ?>>MASTER PROFESSIONNELLE</option>
    </select>

    <input type="text" name="domaine" value="<?= htmlspecialchars($etudiant['domaine'] ?? '') ?>" placeholder="Domaine..." required>
    <input type="text" name="mention" value="<?= htmlspecialchars($etudiant['mention'] ?? '') ?>" placeholder="Mention..." required>

    <select name="niveau" required>
        <option value="">-- Niveau --</option>
        <option value="LICENCE I" <?= ($etudiant['niveau'] === 'LICENCE I') ? 'selected' : '' ?>>LICENCE I</option>
        <option value="LICENCE II" <?= ($etudiant['niveau'] === 'LICENCE II') ? 'selected' : '' ?>>LICENCE II</option>
        <option value="LICENCE III" <?= ($etudiant['niveau'] === 'LICENCE III') ? 'selected' : '' ?>>LICENCE III</option>
        <option value="MASTER I" <?= ($etudiant['niveau'] === 'MASTER I') ? 'selected' : '' ?>>MASTER I</option>
        <option value="MASTER II" <?= ($etudiant['niveau'] === 'MASTER II') ? 'selected' : '' ?>>MASTER II</option>
    </select>

    <select name="semestre" required>
        <option value="">-- Semestre --</option>
        <?php for ($s=1; $s<=6; $s++): ?>
            <option value="Semestre <?= $s ?>" <?= ($etudiant['semestre'] === "Semestre $s") ? 'selected' : '' ?>>Semestre <?= $s ?></option>
        <?php endfor; ?>
    </select>

    <select id="id_option" name="id_option" required>
        <option value="">-- Choisir une option --</option>
        <?php foreach ($options as $opt): ?>
            <option value="<?= $opt['id_option'] ?>" <?= ($etudiant['id_option'] == $opt['id_option']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($opt['designation_option']) ?> (<?= htmlspecialchars($opt['designation_filiere']) ?>)
            </option>
        <?php endforeach; ?>
    </select>

    <select name="annee_academique" required>
        <option value="">-- Année académique --</option>
        <?php 
        $y = 2024;
        for ($i = 0; $i < 15; $i++) {
            $annee = "$y-" . ($y + 1);
            $selected = ($etudiant['annee_academique'] == $annee) ? 'selected' : '';
            echo "<option value='$annee' $selected>$annee</option>";
            $y++;
        }
        ?>
    </select>

    <div style="flex-basis:100%;">
        <label><strong>Photo actuelle :</strong></label><br>  
        <?php if (!empty($etudiant['photo_etudiant'])): ?>
            <img src="../uploads/<?= htmlspecialchars($etudiant['photo_etudiant']) ?>" alt="Photo" class="preview">
        <?php else: ?>
            <span>Aucune photo</span>
        <?php endif; ?>
        <br><input type="file" name="photo_etudiant">
    </div>

    <button type="submit" name="update"><i class="fa fa-save"></i> Enregistrer les modifications</button>
</form>
</div>

</body>
</html>
