<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

require_once '../config/db.php';

// === Ajout d'une filière ===
if (isset($_POST['add'])) {
    $designation_filiere = trim($_POST['designation_filiere']);
    if (!empty($designation_filiere)) {
        try {
            $stmt = $db->prepare("INSERT INTO filieres (designation_filiere) VALUES (:designation_filiere)");
            $stmt->execute([':designation_filiere' => $designation_filiere]);
            $message = "<p class='success' id='msg'>✅ Filière ajoutée avec succès !</p>";
        } catch (PDOException $e) {
            $message = "<p class='error'>Erreur : " . $e->getMessage() . "</p>";
        }
    } else {
        $message = "<p class='error'>⚠️ Le nom de la filière ne peut pas être vide.</p>";
    }
}

// === Modification ===
if (isset($_POST['update'])) {
    $id_filiere = (int)$_POST['id_filiere'];
    $designation_filiere = trim($_POST['designation_filiere']);
    if (!empty($designation_filiere)) {
        try {
            $stmt = $db->prepare("UPDATE filieres SET designation_filiere = :designation_filiere WHERE id_filiere = :id_filiere");
            $stmt->execute([':designation_filiere' => $designation_filiere, ':id_filiere' => $id_filiere]);
            $message = "<p class='success' id='msg'>✅ Filière mise à jour avec succès !</p>";
        } catch (PDOException $e) {
            $message = "<p class='error'>Erreur : " . $e->getMessage() . "</p>";
        }
    }
}

// === Suppression ===
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $stmt = $db->prepare("DELETE FROM filieres WHERE id_filiere = :id");
        $stmt->execute([':id' => $id]);
        $message = "<p class='success' id='msg'>🗑️ Filière supprimée avec succès.</p>";
    } catch (PDOException $e) {
        $message = "<p class='error'>Erreur : " . $e->getMessage() . "</p>";
    }
}

// === Pagination ===
$limit = 5;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// Tri (par défaut A–Z)
$order = isset($_GET['order']) && $_GET['order'] === 'desc' ? 'DESC' : 'ASC';
$nextOrder = $order === 'ASC' ? 'desc' : 'asc';

// Comptage total
$totalStmt = $db->query("SELECT COUNT(*) FROM filieres");
$totalRows = $totalStmt->fetchColumn();
$totalPages = ceil($totalRows / $limit);

// Récupération paginée et triée
$stmt = $db->prepare("SELECT * FROM filieres ORDER BY designation_filiere $order LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$filieres = $stmt->fetchAll();

// Compteur dynamique
$start = $totalRows > 0 ? $offset + 1 : 0;
$end = min($offset + $limit, $totalRows);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestion des Filières</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp"> <!-- Ajout de l'icône dans l'onglet -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
    body {
        font-family: 'Segoe UI', sans-serif;
        background: #f4f7fb;
        margin: 0;
        padding: 0;
    }
    header {
        background: linear-gradient(90deg, #0b3b6a, #c58a00);
        color: #fff;
        text-align: center;
        padding: 1rem;
    }
    h1 { margin: 0; font-size: 1.8rem; }
    .container {
        width: 90%;
        max-width: 1000px;
        margin: 30px auto;
        background: #fff;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 3px 10px rgba(0,0,0,0.1);
    }
    .btn {
        background-color: #28a745;
        color: #fff;
        border: none;
        padding: 10px 18px;
        border-radius: 6px;
        cursor: pointer;
        text-decoration: none;
        margin: 5px;
        display: inline-block;
    }
    .btn:hover { background-color: #218838; }
    .error, .success {
        text-align: center;
        font-weight: bold;
        margin: 10px 0;
    }
    .success { color: green; }
    .error { color: red; }
    form {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        margin-bottom: 20px;
    }
    form input {
        flex: 1;
        padding: 10px;
        border-radius: 6px;
        border: 1px solid #ccc;
        font-size: 1rem;
    }
    form button {
        background-color: #007bff;
        border: none;
        color: #fff;
        padding: 10px 15px;
        border-radius: 6px;
        cursor: pointer;
    }
    form button:hover { background-color: #0056b3; }
    .search-box {
        width: 100%;
        max-width: 300px;
        padding: 10px;
        border-radius: 6px;
        border: 1px solid #ccc;
        margin-bottom: 15px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
    }
    th {
        background-color: #0b3b6a;
        color: white;
        padding: 12px;
        text-align: left;
        cursor: pointer;
    }
    th:hover { background-color: #09406e; }
    td {
        padding: 10px;
        border-bottom: 1px solid #ddd;
    }
    tr:hover { background-color: #f8f9fa; }
    .delete-btn {
        background-color: #dc3545;
        color: white;
        border: none;
        padding: 6px 12px;
        border-radius: 5px;
        cursor: pointer;
    }
    .delete-btn:hover { background-color: #b52a36; }
    .pagination {
        text-align: center;
        margin-top: 25px;
    }
    .pagination a {
        color: #007bff;
        text-decoration: none;
        padding: 8px 14px;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin: 0 3px;
    }
    .pagination a.active {
        background-color: #007bff;
        color: white;
        font-weight: bold;
    }
    .pagination a:hover {
        background-color: #0056b3;
        color: white;
    }
    .count-info {
        text-align: right;
        font-style: italic;
        color: #555;
        margin-bottom: 5px;
        font-size: 0.95rem;
    }
    @media (max-width: 768px) {
        form { flex-direction: column; }
        .btn { width: 100%; text-align: center; }
        table, th, td { font-size: 0.9rem; }
        .count-info { text-align: center; }
    }
</style>
</head>
<body>

<header>
    <h1><i class="fa-solid fa-layer-group"></i> Gestion des Filières</h1>
</header>

<div class="container">
    <?= $message ?? '' ?>

    <a href="admin_dashboard.php" class="btn"><i class="fa-solid fa-home"></i> Accueil</a>

    <form method="POST" action="filieres.php">
        <input type="text" name="designation_filiere" placeholder="Nom de la filière..." required>
        <button type="submit" name="add"><i class="fa-solid fa-plus"></i> Ajouter</button>
    </form>

    <input type="text" id="searchInput" class="search-box" placeholder="🔍 Rechercher une filière..." onkeyup="searchFiliere()">

    <p class="count-info">Affichage de <?= $start ?> à <?= $end ?> sur <?= $totalRows ?> filières</p>

    <table id="filiereTable">
        <thead>
            <tr>
                <th onclick="sortFilieres()">
                    Nom de la Filière
                    <i class="fa-solid fa-sort"></i>
                </th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($filieres as $filiere): ?>
                <tr>
                    <td><?= htmlspecialchars($filiere['designation_filiere']); ?></td>
                    <td>
                        <form method="POST" action="filieres.php" style="display:inline;">
                            <input type="hidden" name="id_filiere" value="<?= $filiere['id_filiere']; ?>">
                            <input type="text" name="designation_filiere" value="<?= htmlspecialchars($filiere['designation_filiere']); ?>" required>
                            <button type="submit" name="update"><i class="fa-solid fa-pen-to-square"></i></button>
                        </form>
                        <a href="filieres.php?delete=<?= $filiere['id_filiere']; ?>" onclick="return confirm('Supprimer cette filière ?')">
                            <button class="delete-btn"><i class="fa-solid fa-trash"></i></button>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?page=<?= $page - 1; ?>&order=<?= strtolower($order); ?>">&laquo; Précédent</a>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="?page=<?= $i; ?>&order=<?= strtolower($order); ?>" class="<?= $i == $page ? 'active' : ''; ?>"><?= $i; ?></a>
        <?php endfor; ?>

        <?php if ($page < $totalPages): ?>
            <a href="?page=<?= $page + 1; ?>&order=<?= strtolower($order); ?>">Suivant &raquo;</a>
        <?php endif; ?>
    </div>

    <div style="text-align:center; margin-top:10px;">
        <a href="?page=<?= $page; ?>&order=<?= strtolower($nextOrder); ?>" class="btn">
            <i class="fa-solid fa-arrow-up-wide-short"></i> Trier <?= $order === 'ASC' ? '(Z–A)' : '(A–Z)' ?>
        </a>
    </div>
</div>

<script>
function searchFiliere() {
    let input = document.getElementById("searchInput").value.toUpperCase();
    let table = document.getElementById("filiereTable");
    let tr = table.getElementsByTagName("tr");
    for (let i = 1; i < tr.length; i++) {
        let td = tr[i].getElementsByTagName("td")[0];
        if (td) {
            let text = td.textContent || td.innerText;
            tr[i].style.display = text.toUpperCase().indexOf(input) > -1 ? "" : "none";
        }
    }
}
setTimeout(() => {
    const msg = document.getElementById('msg');
    if (msg) msg.style.display = 'none';
}, 5000);
</script>

</body>
</html>
