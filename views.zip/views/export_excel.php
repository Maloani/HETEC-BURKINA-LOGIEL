<?php
require_once '../config/db.php';
require_once '../vendor/autoload.php'; // si tu utilises composer
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

if (!isset($_GET['option'])) {
    die("Option non spécifiée !");
}

$option = urldecode($_GET['option']);

$stmt = $db->prepare("
    SELECT i.*, o.designation_option, f.designation_filiere
    FROM inscriptions i
    LEFT JOIN options o ON i.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    WHERE o.designation_option = :opt
    ORDER BY i.nom_etudiant
");
$stmt->execute([':opt' => $option]);
$etudiants = $stmt->fetchAll(PDO::FETCH_ASSOC);
if (!$etudiants) die("Aucun étudiant trouvé.");

$filiere = $etudiants[0]['designation_filiere'];

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

$sheet->setCellValue('A1', 'ECOLE SUPÉRIEURE DES HAUTES ÉTUDES TECHNOLOGIQUES ET COMMERCIALES (HETEC)');
$sheet->mergeCells('A1:H1');
$sheet->getStyle('A1')->getFont()->setBold(true)->setSize(12);
$sheet->getStyle('A1')->getAlignment()->setHorizontal('center');

$sheet->setCellValue('A3', "LISTE DES ETUDIANTS EN $option – $filiere");
$sheet->mergeCells('A3:H3');
$sheet->getStyle('A3')->getFont()->setBold(true)->setSize(11);
$sheet->getStyle('A3')->getAlignment()->setHorizontal('center');

$headers = ['Matricule', 'Nom', 'Prénom', 'Sexe', 'Date de naissance', 'Lieu de naissance', 'Téléphone', 'Photo'];
$col = 'A';
foreach ($headers as $header) {
    $sheet->setCellValue($col.'5', $header);
    $sheet->getStyle($col.'5')->getFont()->setBold(true);
    $sheet->getColumnDimension($col)->setWidth(20);
    $col++;
}

$row = 6;
foreach ($etudiants as $et) {
    $sheet->setCellValue("A$row", $et['matricule_etudiant']);
    $sheet->setCellValue("B$row", $et['nom_etudiant']);
    $sheet->setCellValue("C$row", $et['prenom_etudiant']);
    $sheet->setCellValue("D$row", $et['sexe']);
    $sheet->setCellValue("E$row", $et['date_naissance']);
    $sheet->setCellValue("F$row", $et['lieu_naissance']);
    $sheet->setCellValue("G$row", $et['telephone']);
    $sheet->setCellValue("H$row", $et['photo_etudiant']);
    $row++;
}

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="Liste_etudiants_'.$option.'_'.$filiere.'.xlsx"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
?>
