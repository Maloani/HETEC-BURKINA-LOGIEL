<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.html");
    exit();
}

require_once '../config/db.php';

// === Filtre unique : Type de document ===
$filtre_type = $_GET['type_doc'] ?? '';

// === Ajout d’une correspondance ===
if (isset($_POST['add'])) {
    $type_doc = trim($_POST['type_doc']);
    $objet = trim($_POST['objet']);
    $concerne = trim($_POST['concerne']); // <-- cohérent sans accent
    $statut = trim($_POST['statut']);
    $fichier = $_FILES['fichier']['name'] ?? null;

    if (!empty($type_doc) && !empty($objet) && !empty($concerne) && !empty($statut)) {
        try {
            $uploadPath = "../uploads/correspondances/";
            if (!file_exists($uploadPath)) mkdir($uploadPath, 0777, true);

            if ($fichier) {
                $filename = time() . "_" . basename($fichier);
                move_uploaded_file($_FILES['fichier']['tmp_name'], $uploadPath . $filename);
            } else {
                $filename = null;
            }

            // Insertion avec date automatique
            $stmt = $db->prepare("
                INSERT INTO correspondances (type_doc, objet, date_envoi, concerne, statut, fichier)
                VALUES (:type_doc, :objet, CURRENT_DATE, :concerne, :statut, :fichier)
            ");
            $stmt->execute([
                ':type_doc' => $type_doc,
                ':objet' => $objet,
                ':concerne' => $concerne,
                ':statut' => $statut,
                ':fichier' => $filename
            ]);

            $message = "<p class='success'>✅ Correspondance enregistrée avec succès.</p>";
        } catch (PDOException $e) {
            $message = "<p class='error'>Erreur : " . $e->getMessage() . "</p>";
        }
    } else {
        $message = "<p class='error beep'>⚠️ Tous les champs sont obligatoires.</p>";
    }
}

// === Mise à jour du statut ===
if (isset($_POST['update_status'])) {
    $id_corresp = (int)$_POST['id_corresp'];
    $statut = trim($_POST['statut']);
    $stmt = $db->prepare("UPDATE correspondances SET statut = :statut WHERE id_corresp = :id");
    $stmt->execute([':statut' => $statut, ':id' => $id_corresp]);
    $message = "<p class='success'>🔄 Statut mis à jour avec succès.</p>";
}

// === Suppression ===
if (isset($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM correspondances WHERE id_corresp = :id");
    $stmt->execute([':id' => $_GET['delete']]);
    $message = "<p class='success'>🗑️ Correspondance supprimée avec succès.</p>";
}

// === PAGINATION + FILTRE TYPE ===
$where = "";
if ($filtre_type !== '') {
    $where = "WHERE type_doc = :type_doc";
}

$limit = 7;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// --- Compter le total filtré ---
$countSql = "SELECT COUNT(*) FROM correspondances " . $where;
$countStmt = $db->prepare($countSql);
if ($filtre_type !== '') {
    $countStmt->bindValue(':type_doc', $filtre_type, PDO::PARAM_STR);
}
$countStmt->execute();
$totalRows = (int)$countStmt->fetchColumn();
$totalPages = max(1, ceil($totalRows / $limit));

// --- Requête principale ---
$query = "SELECT * FROM correspondances " . $where . " ORDER BY date_envoi DESC LIMIT $limit OFFSET $offset";
$stmt = $db->prepare($query);
if ($filtre_type !== '') {
    $stmt->bindValue(':type_doc', $filtre_type, PDO::PARAM_STR);
}
$stmt->execute();
$docs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Correspondances administratives</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
body{font-family:'Segoe UI';background:#f4f7fb;margin:0;padding:0;}
header{background:linear-gradient(90deg,#0b3b6a,#c58a00);color:#fff;text-align:center;padding:1rem;}
.container{width:90%;max-width:1100px;margin:30px auto;background:#fff;padding:25px;border-radius:10px;box-shadow:0 3px 10px rgba(0,0,0,0.1);}
.btn{background:#28a745;color:#fff;border:none;padding:10px 18px;border-radius:6px;cursor:pointer;text-decoration:none;}
.btn:hover{background:#218838;}
form{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;}
form input,form select{flex:1;padding:10px;border-radius:6px;border:1px solid #ccc;font-size:1rem;}
form button{background:#007bff;color:#fff;border:none;padding:10px 15px;border-radius:6px;cursor:pointer;}
form button:hover{background:#0056b3;}
table{width:100%;border-collapse:collapse;margin-top:15px;}
th{background:#0b3b6a;color:#fff;padding:12px;text-align:left;}
td{padding:10px;border-bottom:1px solid #ddd;}
tr:hover{background:#f8f9fa;}
.delete-btn{background:#dc3545;color:#fff;border:none;padding:6px 12px;border-radius:5px;cursor:pointer;}
.delete-btn:hover{background:#b52a36;}
.success{background:#d4edda;color:#155724;padding:10px;border-radius:5px;}
.error{background:#f8d7da;color:#721c24;padding:10px;border-radius:5px;}
.pagination{text-align:center;margin-top:20px;}
.pagination a{display:inline-block;margin:0 5px;padding:8px 14px;border-radius:5px;border:1px solid #ccc;text-decoration:none;color:#007bff;}
.pagination a.active{background:#007bff;color:#fff;font-weight:bold;}
.pagination a:hover{background:#0056b3;color:#fff;}
.filter-bar{background:#f1f1f1;padding:10px;border-radius:6px;margin-bottom:15px;display:flex;gap:10px;}
.counter{font-weight:bold;color:#0b3b6a;margin-bottom:10px;}
</style>
</head>
<body>

<header><h1><i class="fa fa-envelope"></i> Gestion des Correspondances</h1></header>

<div class="container">
<?= $message ?? '' ?>
<a href="doc_administratifs.php" class="btn"><i class="fa fa-home"></i> Accueil</a><br><br>

<!-- === FILTRE PAR TYPE SEUL === -->
<form method="GET" class="filter-bar">
<select name="type_doc">
    <option value="">Tous types</option>
    <option value="Lettre" <?= $filtre_type=='Lettre'?'selected':'' ?>>Lettre</option>
    <option value="Communiqué officiel" <?= $filtre_type=='Communiqué officiel'?'selected':'' ?>>Communiqué officiel</option>
    <option value="Avis" <?= $filtre_type=='Avis'?'selected':'' ?>>Avis</option>
    <option value="Note de service" <?= $filtre_type=='Note de service'?'selected':'' ?>>Note de service</option>
</select>
<button type="submit"><i class="fa fa-search"></i> Rechercher</button>
</form>

<!-- === FORMULAIRE D’AJOUT === -->
<form method="POST" enctype="multipart/form-data">
<select name="type_doc" required>
    <option value="">-- Type de document --</option>
    <option value="Lettre">Lettre</option>
    <option value="Communiqué officiel">Communiqué officiel</option>
    <option value="Avis">Avis</option>
    <option value="Note de service">Note de service</option>
</select>

<input type="text" name="objet" placeholder="Objet du document..." required>

<select name="concerne" required>
    <option value="">-- Concerné --</option>
    <option value="Étudiant">Étudiant</option>
    <option value="Enseignant">Enseignant</option>
    <option value="Administration">Administration</option>
    <option value="Autre">Autre</option>
</select>

<select name="statut" required>
    <option value="">-- Statut --</option>
    <option value="Envoyé">Envoyé</option>
    <option value="En attente">En attente</option>
    <option value="Archivé">Archivé</option>
</select>

<input type="file" name="fichier" accept=".pdf,.docx,.jpg,.png,.jpeg">
<button type="submit" name="add"><i class="fa fa-save"></i> Enregistrer</button>
</form>

<!-- === COMPTEUR DE RESULTATS === -->
<p class="counter"><?= $totalRows ?> correspondance<?= $totalRows > 1 ? 's' : '' ?> trouvée<?= $filtre_type ? " (filtrées par type : <b>" . htmlspecialchars($filtre_type) . "</b>)" : '' ?>.</p>

<!-- === TABLEAU === -->
<table>
<tr>
<th>Type</th><th>Objet</th><th>Date</th><th>Concerné</th><th>Statut</th><th>Fichier</th><th>Action</th>
</tr>
<?php if ($docs): foreach($docs as $d): ?>
<tr>
<td><?= htmlspecialchars($d['type_doc']) ?></td>
<td><?= htmlspecialchars($d['objet']) ?></td>
<td><?= htmlspecialchars($d['date_envoi']) ?></td>
<td><?= htmlspecialchars($d['concerne']) ?></td>
<td>
<form method="POST" style="display:inline;">
<input type="hidden" name="id_corresp" value="<?= $d['id_corresp'] ?>">
<select name="statut" onchange="this.form.submit()">
    <option value="Envoyé" <?= $d['statut']=='Envoyé'?'selected':'' ?>>Envoyé</option>
    <option value="En attente" <?= $d['statut']=='En attente'?'selected':'' ?>>En attente</option>
    <option value="Archivé" <?= $d['statut']=='Archivé'?'selected':'' ?>>Archivé</option>
</select>
<input type="hidden" name="update_status" value="1">
</form>
</td>
<td>
<?php if ($d['fichier']): ?>
<a href="../uploads/correspondances/<?= htmlspecialchars($d['fichier']) ?>" target="_blank">
<i class="fa fa-download"></i> Voir
</a>
<?php else: ?>—<?php endif; ?>
</td>
<td>
<a href="?delete=<?= $d['id_corresp'] ?>" onclick="return confirm('Supprimer cette correspondance ?')">
<button type="button" class="delete-btn"><i class="fa fa-trash"></i> Supprimer</button></a>
</td>
</tr>
<?php endforeach; else: ?>
<tr><td colspan="7" style="text-align:center;color:#888;">Aucune correspondance trouvée.</td></tr>
<?php endif; ?>
</table>

<!-- === PAGINATION === -->
<div class="pagination">
<?php if ($page > 1): ?><a href="?page=<?= $page - 1 ?>"><i class="fa fa-arrow-left"></i> Précédent</a><?php endif; ?>
<span>Page <?= $page ?> / <?= $totalPages ?></span>
<?php if ($page < $totalPages): ?><a href="?page=<?= $page + 1 ?>">Suivant <i class="fa fa-arrow-right"></i></a><?php endif; ?>
</div>
</div>
</body>
</html>
