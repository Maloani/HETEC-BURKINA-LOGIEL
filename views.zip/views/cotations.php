<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
require_once '../models/config.php';

// 🔐 Vérification session
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'enseignant') {
    header("Location: ../login.php");
    exit();
}

$id_enseignant = $_SESSION['user_id'];
$nom_enseignant = $_SESSION['nom'];

// === Étape 1 : UEs de l’enseignant ===
$sqlUE = "
SELECT DISTINCT 
    u.id_ue, u.code_ue, u.intitule_ue
FROM cours c
LEFT JOIN ues u ON c.id_ue = u.id_ue
WHERE c.id_enseignant = :id
ORDER BY u.intitule_ue ASC";
$stmtUE = $pdo->prepare($sqlUE);
$stmtUE->execute([':id' => $id_enseignant]);
$ues = $stmtUE->fetchAll(PDO::FETCH_ASSOC);

// === Étape 2 : cours ===
$cours = [];
if (!empty($_GET['id_ue'])) {
    $id_ue = (int)$_GET['id_ue'];
    $sqlCours = "
    SELECT c.id_cours, c.designation_cours, o.designation_option, f.designation_filiere
    FROM cours c
    LEFT JOIN options o ON c.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    WHERE c.id_enseignant = :id_ens AND c.id_ue = :id_ue
    ORDER BY c.designation_cours ASC";
    $stmtCours = $pdo->prepare($sqlCours);
    $stmtCours->execute([':id_ens' => $id_enseignant, ':id_ue' => $id_ue]);
    $cours = $stmtCours->fetchAll(PDO::FETCH_ASSOC);
}

// === Étape 3 : étudiants + moyennes ===
$etudiants = [];
$totalEtudiants = $totalComplets = $totalPartiels = $totalNonCotes = 0;
$limit = 10;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

if (!empty($_GET['id_cours'])) {
    $id_cours = (int)$_GET['id_cours'];

    // Compter les étudiants
    $count = $pdo->prepare("SELECT COUNT(*) FROM inscriptions i JOIN cours c ON i.id_option = c.id_option WHERE c.id_cours = :id_cours");
    $count->execute([':id_cours' => $id_cours]);
    $totalEtudiants = $count->fetchColumn();

    // Récupération des cotes
    $stmt = $pdo->prepare("
        SELECT 
            i.matricule_etudiant, i.nom_etudiant, i.prenom_etudiant,
            ct.note_td, ct.note_tp, ct.note_examen
        FROM inscriptions i
        JOIN cours c ON i.id_option = c.id_option
        LEFT JOIN cotes ct 
            ON ct.matricule_etudiant = i.matricule_etudiant 
            AND ct.id_cours = c.id_cours
        WHERE c.id_cours = :id_cours
        ORDER BY i.nom_etudiant ASC
        LIMIT :limit OFFSET :offset
    ");
    $stmt->bindValue(':id_cours', $id_cours, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $etudiants = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Statistiques globales
    foreach ($etudiants as $e) {
        $td = $e['note_td']; $tp = $e['note_tp']; $ex = $e['note_examen'];
        if (is_null($td) && is_null($tp) && is_null($ex)) $totalNonCotes++;
        elseif (!is_null($td) && !is_null($tp) && !is_null($ex)) $totalComplets++;
        else $totalPartiels++;
    }

    $totalPages = max(1, ceil($totalEtudiants / $limit));
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cotations – HETEC Burkina Faso</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
:root {
  --primary: #0B3B6A;
  --secondary: #C58A00;
  --bg: #f4f7fb;
  --text: #222;
  --success: #27ae60;
  --warning: #e67e22;
  --danger: #c0392b;
}
body { margin: 0; font-family: "Segoe UI", sans-serif; background: var(--bg); color: var(--text); display: flex; }

/* Sidebar */
.sidebar {
  width: 230px;
  background: linear-gradient(180deg, var(--primary), #082f55);
  color: white;
  height: 100vh;
  position: fixed;
  left: 0;
  top: 0;
  padding-top: 20px;
  display: flex;
  flex-direction: column;
  box-shadow: 2px 0 6px rgba(0,0,0,0.2);
}
.sidebar .logo { text-align: center; margin-bottom: 25px; }
.sidebar .logo img { width: 60px; border-radius: 50%; }
.sidebar .logo h2 { margin: 10px 0 0; font-size: 1.1rem; color: var(--secondary); }
.sidebar .menu a {
  display: flex; align-items: center; color: white; text-decoration: none;
  padding: 12px 20px; gap: 12px; transition: 0.3s; border-left: 4px solid transparent;
}
.sidebar .menu a:hover, .sidebar .menu a.active {
  background: var(--secondary); border-left: 4px solid #fff;
}

/* Main */
.main { margin-left: 230px; flex: 1; padding: 25px; }
header {
  background: linear-gradient(90deg, var(--primary), var(--secondary));
  color: #fff; padding: 15px; border-radius: 8px; text-align: center; margin-bottom: 20px;
}
.stats {
  display: flex; justify-content: space-around; margin: 20px 0; flex-wrap: wrap;
}
.card {
  background: white; border-left: 6px solid var(--primary);
  border-radius: 8px; padding: 15px 25px; box-shadow: 0 3px 8px rgba(0,0,0,0.1);
  min-width: 180px; text-align: center; margin-bottom: 15px;
}
.card h3 { margin: 5px 0; color: var(--primary); }
.card span { font-weight: bold; font-size: 1.2rem; color: var(--secondary); }

.moyenne-label {
  font-weight: bold;
  padding: 4px 8px;
  border-radius: 6px;
  display: inline-block;
  margin-left: 6px;
}
.m1 { background: #e74c3c; color: #fff; }     /* Faible */
.m2 { background: #e67e22; color: #fff; }     /* Insuffisant */
.m3 { background: #f1c40f; color: #000; }     /* Passable */
.m4 { background: #2ecc71; color: #fff; }     /* Assez bien */
.m5 { background: #27ae60; color: #fff; }     /* Bien */
.m6 { background: #16a085; color: #fff; }     /* Très bien */
.m7 { background: #2980b9; color: #fff; }     /* Excellent */

select {
  padding: 10px; border-radius: 6px; border: 1px solid #ccc; width: 60%; font-size: 1rem; margin-bottom: 20px;
}
button, .btn-action {
  background: var(--secondary); color: white; border: none; border-radius: 6px;
  padding: 8px 14px; cursor: pointer; font-weight: bold;
}
button:hover, .btn-action:hover { background: #b47800; }

/* Table */
table {
  width: 100%; border-collapse: collapse; background: white; border-radius: 8px;
  overflow: hidden; box-shadow: 0 3px 8px rgba(0,0,0,0.1);
}
th, td { padding: 12px; border-bottom: 1px solid #ddd; text-align: center; }
th { background: var(--primary); color: white; }
tr:hover { background: #f9f9f9; }

.status { padding: 6px 10px; border-radius: 6px; color: white; font-weight: bold; }
.status.green { background: var(--success); }
.status.orange { background: var(--warning); }
.status.red { background: var(--danger); }

.pagination { text-align: center; margin-top: 15px; }
.pagination a {
  background: var(--secondary); color: white; padding: 8px 14px;
  border-radius: 6px; margin: 0 5px; text-decoration: none;
}
.pagination a:hover { background: #b47800; }
</style>
</head>

<body>
<!-- Sidebar -->
<aside class="sidebar">
  <div class="logo">
    <img src="../img/hetec.jpg-2.webp" alt="HETEC">
    <h2>HETEC</h2>
  </div>
  <nav class="menu">
    <a href="enseignant_dashboard.html"><i class="fa-solid fa-house"></i><span>Accueil</span></a>
    <a href="mes_cours.php"><i class="fa-solid fa-book"></i><span>Mes Cours</span></a>
    <a href="cotations.php" class="active"><i class="fa-solid fa-graduation-cap"></i><span>Attribuer les notes</span></a>
    <a href="communiques_ens.php"><i class="fa-solid fa-bullhorn"></i><span>Communiqués</span></a>
    <a href="profil_ens.php"><i class="fa-solid fa-user"></i><span>Profil</span></a>
   
  </nav>
</aside>

<!-- Main -->
<div class="main">
  <header><h1><i class="fa-solid fa-graduation-cap"></i> Attribution des notes</h1></header>

  <?php if ($totalEtudiants > 0): ?>
  <div class="stats">
    <div class="card"><h3>Total étudiants</h3><span><?= $totalEtudiants ?></span></div>
    <div class="card"><h3>Cotés complètement</h3><span><?= $totalComplets ?></span></div>
    <div class="card"><h3>Cotés partiellement</h3><span><?= $totalPartiels ?></span></div>
    <div class="card"><h3>Non cotés</h3><span><?= $totalNonCotes ?></span></div>
  </div>
  <?php endif; ?>

  <h2>Étape 1 : Choisir une UE</h2>
  <form method="GET">
    <select name="id_ue" onchange="this.form.submit()" required>
      <option value="">-- Choisissez une UE --</option>
      <?php foreach ($ues as $ue): ?>
        <option value="<?= $ue['id_ue'] ?>" <?= (!empty($_GET['id_ue']) && $_GET['id_ue'] == $ue['id_ue']) ? 'selected' : '' ?>>
          <?= htmlspecialchars($ue['code_ue'].' — '.$ue['intitule_ue']) ?>
        </option>
      <?php endforeach; ?>
    </select>
  </form>

  <?php if (!empty($cours)): ?>
  <h2>Étape 2 : Choisir un cours</h2>
  <form method="GET">
    <input type="hidden" name="id_ue" value="<?= htmlspecialchars($_GET['id_ue']) ?>">
    <select name="id_cours" required>
      <option value="">-- Choisissez un cours --</option>
      <?php foreach ($cours as $c): ?>
        <option value="<?= $c['id_cours'] ?>" <?= (!empty($_GET['id_cours']) && $_GET['id_cours'] == $c['id_cours']) ? 'selected' : '' ?>>
          <?= htmlspecialchars($c['designation_cours']) ?> — <?= htmlspecialchars($c['designation_option']) ?> (<?= htmlspecialchars($c['designation_filiere']) ?>)
        </option>
      <?php endforeach; ?>
    </select>
    <button type="submit"><i class="fa-solid fa-check"></i> Valider</button>
  </form>
  <?php endif; ?>

  <?php if (!empty($etudiants)): ?>
  <h3>Étudiants inscrits au cours sélectionné</h3>
  <table>
    <thead>
      <tr>
        <th>Matricule</th>
        <th>Nom complet</th>
        <th>Moyenne /20 & Mention</th>
        <th>Statut</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($etudiants as $et):
        $td = $et['note_td']; $tp = $et['note_tp']; $ex = $et['note_examen'];
        $moyenne = (!is_null($td) && !is_null($tp) && !is_null($ex))
            ? round((($td / 10 * 20) * 0.3) + (($tp / 10 * 20) * 0.2) + ($ex * 0.5), 2)
            : null;

        // Détermination de la mention et couleur
        $mention = "—"; $class = "";
        if (!is_null($moyenne)) {
            if ($moyenne < 8) { $mention = "Faible"; $class = "m1"; }
            elseif ($moyenne < 10) { $mention = "Insuffisant"; $class = "m2"; }
            elseif ($moyenne < 12) { $mention = "Passable"; $class = "m3"; }
            elseif ($moyenne < 14) { $mention = "Assez bien"; $class = "m4"; }
            elseif ($moyenne < 16) { $mention = "Bien"; $class = "m5"; }
            elseif ($moyenne < 18) { $mention = "Très bien"; $class = "m6"; }
            else { $mention = "Excellent"; $class = "m7"; }
        }

        // Statuts et actions
        if (is_null($td) && is_null($tp) && is_null($ex)) {
            $status = "<span class='status red'>Non coté</span>";
            $msg = "<a class='btn-action' href='coter_etudiant.php?matricule=".urlencode($et['matricule_etudiant'])."&id_cours=$id_cours'><i class='fa-solid fa-pen'></i> Coter</a>";
        } else {
            $status = "<span class='status green'>Cotation complète / modifiable</span>";
            $msg = "<a class='btn-action' href='coter_etudiant.php?matricule=".urlencode($et['matricule_etudiant'])."&id_cours=$id_cours'><i class='fa-solid fa-edit'></i> Modifier</a>";
        }
      ?>
      <tr>
        <td><?= htmlspecialchars($et['matricule_etudiant']) ?></td>
        <td><?= htmlspecialchars($et['nom_etudiant'].' '.$et['prenom_etudiant']) ?></td>
        <td>
          <?= $moyenne !== null ? $moyenne."/20 <span class='moyenne-label ".$class."'>".$mention."</span>" : "—" ?>
        </td>
        <td><?= $status ?></td>
        <td><?= $msg ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <div class="pagination">
    <?php if ($page > 1): ?>
      <a href="?id_ue=<?= $id_ue ?>&id_cours=<?= $id_cours ?>&page=<?= $page - 1 ?>"><i class="fa fa-arrow-left"></i> Précédent</a>
    <?php endif; ?>
    <span>Page <?= $page ?> / <?= $totalPages ?></span>
    <?php if ($page < $totalPages): ?>
      <a href="?id_ue=<?= $id_ue ?>&id_cours=<?= $id_cours ?>&page=<?= $page + 1 ?>">Suivant <i class="fa fa-arrow-right"></i></a>
    <?php endif; ?>
  </div>

  <?php elseif (isset($_GET['id_cours'])): ?>
  <p>Aucun étudiant inscrit à ce cours.</p>
  <?php endif; ?>
</div>
</body>
</html>
