<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
require_once '../models/config.php';

// Vérification session
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'enseignant') {
    header("Location: ../index.html");
    exit();
}

$id_enseignant = $_SESSION['user_id'];
$nom_enseignant = $_SESSION['nom'];

if (!isset($_GET['matricule']) || !isset($_GET['id_cours'])) {
    header("Location: cotations.php");
    exit();
}

$matricule = $_GET['matricule'];
$id_cours = (int)$_GET['id_cours'];

// Vérification si déjà coté
$stmt = $pdo->prepare("SELECT * FROM cotes WHERE matricule_etudiant = :mat AND id_cours = :cours");
$stmt->execute([':mat' => $matricule, ':cours' => $id_cours]);
$coteExistante = $stmt->fetch(PDO::FETCH_ASSOC);

// Récup infos étudiant
$info = $pdo->prepare("
    SELECT i.nom_etudiant, i.prenom_etudiant, o.designation_option, f.designation_filiere, c.designation_cours
    FROM inscriptions i
    JOIN cours c ON i.id_option = c.id_option
    LEFT JOIN options o ON c.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    WHERE i.matricule_etudiant = :mat AND c.id_cours = :cours
");
$info->execute([':mat' => $matricule, ':cours' => $id_cours]);
$etudiant = $info->fetch(PDO::FETCH_ASSOC);

// Enregistrement / mise à jour
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $note_td = $_POST['note_td'] !== "" ? $_POST['note_td'] : null;
    $note_tp = $_POST['note_tp'] !== "" ? $_POST['note_tp'] : null;
    $note_examen = $_POST['note_examen'] !== "" ? $_POST['note_examen'] : null;

    if ($coteExistante) {
        $update = $pdo->prepare("
            UPDATE cotes 
            SET 
                note_td = COALESCE(:td, note_td),
                note_tp = COALESCE(:tp, note_tp),
                note_examen = COALESCE(:exam, note_examen),
                statut = 'coté',
                date_cotation = NOW()
            WHERE id_cote = :id
        ");
        $update->execute([
            ':td' => $note_td,
            ':tp' => $note_tp,
            ':exam' => $note_examen,
            ':id' => $coteExistante['id_cote']
        ]);
        $message = "<div class='success'>✅ Mise à jour enregistrée avec succès.</div>";
    } else {
        $insert = $pdo->prepare("
            INSERT INTO cotes (matricule_etudiant, id_cours, id_enseignant, note_td, note_tp, note_examen, statut)
            VALUES (:mat, :cours, :ens, :td, :tp, :exam, 'coté')
        ");
        $insert->execute([
            ':mat' => $matricule,
            ':cours' => $id_cours,
            ':ens' => $id_enseignant,
            ':td' => $note_td,
            ':tp' => $note_tp,
            ':exam' => $note_examen
        ]);
        $message = "<div class='success'>✅ Cotation enregistrée avec succès.</div>";
    }

    $stmt->execute([':mat' => $matricule, ':cours' => $id_cours]);
    $coteExistante = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Détermination du statut
$statutProgression = "Aucune note enregistrée.";
$color = "gray";
if ($coteExistante) {
    $hasTD = !is_null($coteExistante['note_td']);
    $hasTP = !is_null($coteExistante['note_tp']);
    $hasExam = !is_null($coteExistante['note_examen']);

    if ($hasTD && !$hasTP && !$hasExam) {
        $statutProgression = "🟢 TD coté – En attente de TP et Examen.";
        $color = "#27ae60";
    } elseif ($hasTD && $hasTP && !$hasExam) {
        $statutProgression = "🟡 TD et TP cotés – En attente d’Examen.";
        $color = "#e67e22";
    } elseif ($hasTD && $hasTP && $hasExam) {
        $statutProgression = "✅ Cotation complète – Toutes les notes enregistrées.";
        $color = "#2ecc71";
    } else {
        $statutProgression = "⚪ Cotation partielle en cours.";
        $color = "#95a5a6";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Coter un étudiant – HETEC Burkina Faso</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
:root {
  --primary: #0B3B6A;
  --secondary: #C58A00;
  --bg: #f4f7fb;
}
body { margin: 0; font-family: "Segoe UI", sans-serif; background: var(--bg); }
.container {
  width: 65%; margin: 40px auto; background: white; border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.1); padding: 30px;
}
h1 {
  background: linear-gradient(90deg, var(--primary), var(--secondary));
  color: white; padding: 15px; text-align: center; border-radius: 8px;
}
.info { margin: 20px 0; background: #eef5ff; padding: 15px; border-radius: 8px; }
.status-box {
  padding: 12px; background: #ecf0f1; border-left: 6px solid <?= $color ?>;
  border-radius: 8px; font-weight: 600; margin-bottom: 20px;
}
label { display: block; margin-top: 12px; font-weight: bold; }
input[type="number"] {
  width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 6px; margin-top: 5px;
}
button {
  background: var(--secondary); color: white; border: none; padding: 10px 18px;
  border-radius: 6px; cursor: pointer; font-weight: bold; margin-top: 20px;
}
button:hover { background: #b47800; }
.success {
  background: #d4edda; color: #155724; padding: 10px; border-radius: 6px; text-align: center; margin-bottom: 10px;
}
#result {
  margin-top: 15px; font-weight: bold; text-align: center; font-size: 1.1rem;
}
a.back { display: inline-block; margin-top: 15px; color: var(--primary); font-weight: bold; text-decoration: none; }
a.back:hover { text-decoration: underline; }
</style>
<script>
function calculerMoyenne() {
  const td = parseFloat(document.querySelector('[name="note_td"]').value) || 0;
  const tp = parseFloat(document.querySelector('[name="note_tp"]').value) || 0;
  const examen = parseFloat(document.querySelector('[name="note_examen"]').value) || 0;

  const moyenne = (td * 0.3) + (tp * 0.2) + (examen * 0.5);
  let mention = '';
  let couleur = '';

  if (moyenne < 8) { mention = 'Faible'; couleur = '#e74c3c'; }
  else if (moyenne < 10) { mention = 'Insuffisant'; couleur = '#e67e22'; }
  else if (moyenne < 12) { mention = 'Passable'; couleur = '#f1c40f'; }
  else if (moyenne < 14) { mention = 'Assez bien'; couleur = '#2ecc71'; }
  else if (moyenne < 16) { mention = 'Bien'; couleur = '#27ae60'; }
  else if (moyenne < 18) { mention = 'Très bien'; couleur = '#16a085'; }
  else { mention = 'Excellent'; couleur = '#2980b9'; }

  document.getElementById('result').innerHTML = 
    `Moyenne : <strong>${moyenne.toFixed(2)}/20</strong> <span style="background:${couleur};color:white;padding:4px 8px;border-radius:6px;">${mention}</span>`;
}
</script>
</head>

<body>
<div class="container">
  <h1><i class="fa-solid fa-pen"></i> Coter un étudiant</h1>
  <?= $message ?>

  <?php if ($etudiant): ?>
    <div class="info">
      <p><strong>Étudiant :</strong> <?= htmlspecialchars($etudiant['nom_etudiant'].' '.$etudiant['prenom_etudiant']) ?></p>
      <p><strong>Matricule :</strong> <?= htmlspecialchars($matricule) ?></p>
      <p><strong>Cours :</strong> <?= htmlspecialchars($etudiant['designation_cours']) ?></p>
      <p><strong>Option :</strong> <?= htmlspecialchars($etudiant['designation_option']) ?> — 
         <strong>Filière :</strong> <?= htmlspecialchars($etudiant['designation_filiere']) ?></p>
    </div>

    <div class="status-box" style="border-color: <?= $color ?>;">
      <?= htmlspecialchars($statutProgression) ?>
    </div>

    <form method="POST" oninput="calculerMoyenne()">
      <label>Note TD (sur 10)</label>
      <input type="number" name="note_td" step="0.01" min="0" max="10" value="<?= $coteExistante['note_td'] ?? '' ?>">

      <label>Note TP (sur 10)</label>
      <input type="number" name="note_tp" step="0.01" min="0" max="10" value="<?= $coteExistante['note_tp'] ?? '' ?>">

      <label>Note Examen (sur 20)</label>
      <input type="number" name="note_examen" step="0.01" min="0" max="20" value="<?= $coteExistante['note_examen'] ?? '' ?>">

      <div id="result"></div>

      <button type="submit"><i class="fa-solid fa-save"></i> Enregistrer / Mettre à jour</button>
    </form>

    <a href="cotations.php?id_cours=<?= $id_cours ?>&id_ue=<?= $_GET['id_ue'] ?? '' ?>" class="back">
      <i class="fa-solid fa-arrow-left"></i> Retour à la liste des étudiants
    </a>

  <?php else: ?>
    <p style="color:red;">Étudiant introuvable.</p>
  <?php endif; ?>
</div>
</body>
</html>
