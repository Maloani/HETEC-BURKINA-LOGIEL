<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

require_once '../config/db.php';

// === Liste des filières ===
$filiereStmt = $db->query("SELECT id_filiere, designation_filiere FROM filieres ORDER BY designation_filiere ASC");
$filiereList = $filiereStmt->fetchAll(PDO::FETCH_ASSOC);

// === Filtrage par filière ===
$filter_filiere = isset($_GET['filiere']) && $_GET['filiere'] !== '' ? (int)$_GET['filiere'] : null;
$filter_condition = $filter_filiere ? "WHERE o.id_filiere = :id_filiere" : "";

// === Ajout d’une option ===
if (isset($_POST['add'])) {
    $designation_option = trim($_POST['designation_option']);
    $id_filiere = (int)$_POST['id_filiere'];

    if (!empty($designation_option) && $id_filiere > 0) {
        try {
            // Vérifier doublon
            $check = $db->prepare("SELECT COUNT(*) FROM options WHERE designation_option = :designation_option AND id_filiere = :id_filiere");
            $check->execute([':designation_option' => $designation_option, ':id_filiere' => $id_filiere]);
            if ($check->fetchColumn() > 0) {
                $message = "<p class='error'>⚠️ Cette option existe déjà dans la filière sélectionnée.</p>";
            } else {
                $stmt = $db->prepare("INSERT INTO options (designation_option, id_filiere) VALUES (:designation_option, :id_filiere)");
                $stmt->execute([':designation_option' => $designation_option, ':id_filiere' => $id_filiere]);
                $message = "<p class='success' id='msg'>✅ Option ajoutée avec succès !</p>";
            }
        } catch (PDOException $e) {
            $message = "<p class='error'>Erreur : " . $e->getMessage() . "</p>";
        }
    } else {
        $message = "<p class='error'>⚠️ Tous les champs sont obligatoires.</p>";
    }
}

// === Modification ===
if (isset($_POST['update'])) {
    $id_option = (int)$_POST['id_option'];
    $designation_option = trim($_POST['designation_option']);
    $id_filiere = (int)$_POST['id_filiere'];

    if (!empty($designation_option) && $id_filiere > 0) {
        try {
            // Vérifier doublon avant mise à jour
            $check = $db->prepare("SELECT COUNT(*) FROM options WHERE designation_option = :designation_option AND id_filiere = :id_filiere AND id_option != :id_option");
            $check->execute([':designation_option' => $designation_option, ':id_filiere' => $id_filiere, ':id_option' => $id_option]);
            if ($check->fetchColumn() > 0) {
                $message = "<p class='error'>⚠️ Cette option existe déjà dans cette filière.</p>";
            } else {
                $stmt = $db->prepare("UPDATE options SET designation_option = :designation_option, id_filiere = :id_filiere WHERE id_option = :id_option");
                $stmt->execute([':designation_option' => $designation_option, ':id_filiere' => $id_filiere, ':id_option' => $id_option]);
                $message = "<p class='success' id='msg'>✅ Option mise à jour avec succès !</p>";
            }
        } catch (PDOException $e) {
            $message = "<p class='error'>Erreur : " . $e->getMessage() . "</p>";
        }
    }
}

// === Suppression ===
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $stmt = $db->prepare("DELETE FROM options WHERE id_option = :id");
        $stmt->execute([':id' => $id]);
        $message = "<p class='success' id='msg'>🗑️ Option supprimée avec succès.</p>";
    } catch (PDOException $e) {
        $message = "<p class='error'>Erreur : " . $e->getMessage() . "</p>";
    }
}

// === Pagination ===
$limit = 5;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// === Comptage ===
if ($filter_filiere) {
    $countStmt = $db->prepare("SELECT COUNT(*) FROM options WHERE id_filiere = :id_filiere");
    $countStmt->execute([':id_filiere' => $filter_filiere]);
} else {
    $countStmt = $db->query("SELECT COUNT(*) FROM options");
}
$totalRows = $countStmt->fetchColumn();
$totalPages = ceil($totalRows / $limit);

// === Statistiques globales ===
$totalGlobal = $db->query("SELECT COUNT(*) FROM options")->fetchColumn();
$statsDetail = $db->query("
    SELECT f.designation_filiere, COUNT(o.id_option) AS total_options
    FROM filieres f
    LEFT JOIN options o ON f.id_filiere = o.id_filiere
    GROUP BY f.id_filiere
    ORDER BY f.designation_filiere ASC
")->fetchAll(PDO::FETCH_ASSOC);

// === Récupération des données ===
$sql = "
    SELECT o.id_option, o.designation_option, f.designation_filiere
    FROM options o
    JOIN filieres f ON o.id_filiere = f.id_filiere
    $filter_condition
    ORDER BY f.designation_filiere ASC, o.designation_option ASC
    LIMIT :limit OFFSET :offset
";
$stmt = $db->prepare($sql);
if ($filter_filiere) $stmt->bindValue(':id_filiere', $filter_filiere, PDO::PARAM_INT);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$options = $stmt->fetchAll();

$start = $totalRows > 0 ? $offset + 1 : 0;
$end = min($offset + $limit, $totalRows);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestion des Options</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp"> <!-- Ajout de l'icône dans l'onglet -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
    body {font-family: 'Segoe UI', sans-serif; background: #f4f7fb; margin: 0; padding: 0;}
    header {background: linear-gradient(90deg, #0b3b6a, #c58a00); color: #fff; text-align: center; padding: 1rem;}
    .container {width: 90%; max-width: 1000px; margin: 30px auto; background: #fff; padding: 25px; border-radius: 10px; box-shadow: 0 3px 10px rgba(0,0,0,0.1);}
    .btn {background-color: #28a745; color: #fff; border: none; padding: 10px 18px; border-radius: 6px; cursor: pointer; text-decoration: none;}
    .btn:hover {background-color: #218838;}
    .error, .success {text-align: center; font-weight: bold; margin: 10px 0;}
    .success {color: green;}
    .error {color: red;}
    form {display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 20px;}
    form input, form select {flex: 1; padding: 10px; border-radius: 6px; border: 1px solid #ccc; font-size: 1rem;}
    form button {background-color: #007bff; border: none; color: #fff; padding: 10px 15px; border-radius: 6px; cursor: pointer;}
    form button:hover {background-color: #0056b3;}
    table {width: 100%; border-collapse: collapse; margin-top: 15px;}
    th {background-color: #0b3b6a; color: white; padding: 12px; text-align: left;}
    td {padding: 10px; border-bottom: 1px solid #ddd;}
    tr:hover {background-color: #f8f9fa;}
    .delete-btn {background-color: #dc3545; color: white; border: none; padding: 6px 12px; border-radius: 5px; cursor: pointer;}
    .delete-btn:hover {background-color: #b52a36;}
    .pagination {text-align: center; margin-top: 25px;}
    .pagination a {color: #007bff; text-decoration: none; padding: 8px 14px; border: 1px solid #ccc; border-radius: 5px; margin: 0 3px;}
    .pagination a.active {background-color: #007bff; color: white; font-weight: bold;}
    .filter-bar {margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;}
    .stats-box {background:#e9f4ff;border-left:5px solid #0b3b6a;padding:15px;margin-bottom:20px;border-radius:8px;}
    .stats-box h3 {margin-top:0;color:#0b3b6a;}
</style>
</head>
<body>

<header>
    <h1><i class="fa-solid fa-list-ul"></i> Gestion des Options</h1>
</header>

<div class="container">
    <?= $message ?? '' ?>

    <!-- ✅ Statistiques globales -->
    <div class="stats-box">
        <h3>📊 Statistiques des options</h3>
        <p><strong>Total global :</strong> <?= $totalGlobal ?> option(s)</p>
        <ul style="margin-left:20px;">
            <?php foreach ($statsDetail as $st): ?>
                <li><strong><?= htmlspecialchars($st['designation_filiere']); ?></strong> : <?= $st['total_options'] ?> option(s)</li>
            <?php endforeach; ?>
        </ul>
    </div>

    <a href="admin_dashboard.php" class="btn"><i class="fa-solid fa-home"></i> Accueil</a>  </br>  </br>

    <form method="POST" action="options.php">
        <input type="text" name="designation_option" placeholder="Nom de l'option..." required>
        <select name="id_filiere" required>
            <option value="">-- Choisir une filière --</option>
            <?php foreach ($filiereList as $f): ?>
                <option value="<?= $f['id_filiere']; ?>"><?= htmlspecialchars($f['designation_filiere']); ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" name="add"><i class="fa-solid fa-plus"></i> Ajouter</button>
    </form>

    <!-- Barre de filtre -->
    <div class="filter-bar">
        <form method="GET" action="options.php">
            <select name="filiere" onchange="this.form.submit()">
                <option value="">-- Filtrer par filière --</option>
                <?php foreach ($filiereList as $f): ?>
                    <option value="<?= $f['id_filiere']; ?>" <?= ($filter_filiere == $f['id_filiere']) ? 'selected' : ''; ?>>
                        <?= htmlspecialchars($f['designation_filiere']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
        <p style="font-style:italic; color:#555;">Affichage de <?= $start ?> à <?= $end ?> sur <?= $totalRows ?> options</p>
    </div>

    <table>
        <thead>
            <tr>
                <th>Nom de l'Option</th>
                <th>Filière</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($options as $opt): ?>
                <tr>
                    <td><?= htmlspecialchars($opt['designation_option']); ?></td>
                    <td><?= htmlspecialchars($opt['designation_filiere']); ?></td>
                    <td>
                        <form method="POST" action="options.php" style="display:inline;">
                            <input type="hidden" name="id_option" value="<?= $opt['id_option']; ?>">
                            <input type="text" name="designation_option" value="<?= htmlspecialchars($opt['designation_option']); ?>" required>
                            <select name="id_filiere" required>
                                <?php foreach ($filiereList as $f): ?>
                                    <option value="<?= $f['id_filiere']; ?>" <?= $f['designation_filiere'] == $opt['designation_filiere'] ? 'selected' : ''; ?>>
                                        <?= htmlspecialchars($f['designation_filiere']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" name="update"><i class="fa-solid fa-pen-to-square"></i></button>
                        </form>
                        <a href="options.php?delete=<?= $opt['id_option']; ?>" onclick="return confirm('Supprimer cette option ?')">
                            <button class="delete-btn"><i class="fa-solid fa-trash"></i></button>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?page=<?= $page - 1; ?>&filiere=<?= $filter_filiere ?>">« Précédent</a>
        <?php endif; ?>
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="?page=<?= $i; ?>&filiere=<?= $filter_filiere ?>" class="<?= $i == $page ? 'active' : ''; ?>"><?= $i; ?></a>
        <?php endfor; ?>
        <?php if ($page < $totalPages): ?>
            <a href="?page=<?= $page + 1; ?>&filiere=<?= $filter_filiere ?>">Suivant »</a>
        <?php endif; ?>
    </div>
</div>

<script>
setTimeout(() => {
    const msg = document.getElementById('msg');
    if (msg) msg.style.display = 'none';
}, 5000);
</script>

</body>
</html>
