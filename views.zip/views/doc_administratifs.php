<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tableau de bord – Administration HETEC</title>
  <link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
  <style>
    body {
      font-family: "Segoe UI", sans-serif;
      background: #f6f8fc;
      color: #222;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      height: 100vh;
    }

    header {
      background: linear-gradient(90deg, #0b3b6a, #c58a00);
      color: white;
      padding: 1rem 2%;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    header h1 {
      font-size: 1.3rem;
      margin: 0;
    }

    .logout-btn {
      background: white;
      color: #0b3b6a;
      border: none;
      border-radius: 6px;
      padding: 0.5rem 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.3s ease, transform 0.2s ease-in-out;
    }

    .logout-btn:hover {
      background: #f0f0f0;
      transform: scale(1.05);
    }

    .main-content {
      padding: 2rem;
      flex-grow: 1;
      overflow-y: auto;
    }

    .card {
      background: white;
      padding: 1rem;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      text-align: center;
      margin-bottom: 2rem;
    }

    .card h2 {
      color: #0b3b6a;
      margin-bottom: 10px;
    }

    .card-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 1.2rem;
      margin-top: 2rem;
    }

    .card-item {
      background: white;
      padding: 1rem;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      text-align: center;
      cursor: pointer;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card-item:hover {
      transform: translateY(-8px);
      box-shadow: 0 6px 18px rgba(0, 0, 0, 0.15);
    }

    .card-item i {
      font-size: 2rem;
      color: #c58a00;
      margin-bottom: 10px;
    }

    .card-item h2 {
      color: #0b3b6a;
      margin-bottom: 10px;
    }

    footer {
      background-color: #0a0f1a;
      color: white;
      text-align: center;
      padding: 20px;
      font-size: 0.9rem;
    }

    @media (max-width: 768px) {
      .card-container {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>

<body>

  <header>
    <h1><i class="fa-solid fa-shield-halved"></i> Tableau de bord – HETEC</h1>
    <button class="logout-btn" onclick="retourAccueil()">
      <i class="fa-solid fa-arrow-left"></i> Retour à l’accueil
    </button>
  </header>

  <div class="main-content">
    <div class="card">
      <h2>Bienvenue dans l’espace administratif</h2>
      <p>Gérez ici les documents et opérations académiques.</p>
    </div>

    <div class="card-container">
      <div class="card-item" onclick="window.location.href='carte_etudiant.php'">
        <i class="fa fa-id-card"></i>
        <h2>Carte d’étudiant</h2>
        <p>Imprimez et gérez les cartes des étudiants.</p>
      </div>

      <div class="card-item" onclick="window.location.href='attributions_cours.php'">
        <i class="fa fa-book-open"></i>
        <h2>Attributions de cours</h2>
        <p>Assignez les cours et gérez les enseignants.</p>
      </div>

      <div class="card-item" onclick="window.location.href='correspondances.php'">
        <i class="fa fa-envelope"></i>
        <h2>Correspondances</h2>
        <p>Gérez les lettres et communications officielles.</p>
      </div>

      <div class="card-item" onclick="window.location.href='attestation_inscription.php'">
        <i class="fa fa-file-signature"></i>
        <h2>Attestation d’inscription</h2>
        <p>Générez les attestations d’inscription.</p>
      </div>

      <div class="card-item" onclick="window.location.href='attestation_admission.php'">
        <i class="fa fa-certificate"></i>
        <h2>Attestation d’admission</h2>
        <p>Délivrez les attestations d’admission.</p>
      </div>

      <div class="card-item" onclick="window.location.href='attestation_admissibilite.php'">
        <i class="fa fa-award"></i>
        <h2>Attestation d’admissibilité</h2>
        <p>Éditez les attestations d’admissibilité.</p>
      </div>

      <div class="card-item" onclick="window.location.href='releves_notes.php'">
        <i class="fa fa-file-alt"></i>
        <h2>Relevés de notes</h2>
        <p>Générez et imprimez les relevés officiels.</p>
      </div>
    </div>
  </div>


  <script>
    function retourAccueil() {
      window.location.href = "admin_dashboard.php"; // ✅ Redirige vers admin_dashboard.html
    }
  </script>

</body>
</html>
