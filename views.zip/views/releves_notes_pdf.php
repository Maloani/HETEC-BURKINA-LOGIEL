<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../models/config.php';
require_once __DIR__ . '/fpdf/fpdf.php';

function normalize_text($text) {
    $text = str_replace(
        ["’","‘","‛","‚","´","`","“","”","„"],
        ["'","'","'","'","'","'","\"","\"","\""],
        $text
    );
    return utf8_decode($text);
}

if (!isset($_GET['id'])) die('Aucun ID fourni.');
$id = (int)$_GET['id'];

// === Infos étudiant ===
$stmt = $pdo->prepare("
    SELECT i.*, o.designation_option, f.designation_filiere
    FROM inscriptions i
    LEFT JOIN options o ON i.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    WHERE i.id_inscription = :id
");
$stmt->execute([':id' => $id]);
$etudiant = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$etudiant) die('Étudiant introuvable.');

// === Cours + notes ===
$stmtNotes = $pdo->prepare("
    SELECT cr.code_cours, cr.designation_cours, cr.credits,
           u.code_ue, u.intitule_ue,
           c.note_td, c.note_tp, c.note_examen
    FROM cotes c
    JOIN cours cr ON c.id_cours = cr.id_cours
    LEFT JOIN ues u ON cr.id_ue = u.id_ue
    WHERE c.matricule_etudiant = :mat
    ORDER BY u.code_ue, cr.designation_cours
");
$stmtNotes->execute([':mat' => $etudiant['matricule_etudiant']]);
$cours = $stmtNotes->fetchAll(PDO::FETCH_ASSOC);

// === Moyennes ===
$total_credits = 0;
$total_pondere = 0;
foreach ($cours as &$c) {
    $td = floatval($c['note_td']);
    $tp = floatval($c['note_tp']);
    $ex = floatval($c['note_examen']);
    $moy = round(($td + $tp + $ex) / 3, 2);
    $c['moyenne'] = $moy;
    if ($moy >= 16) $mention = "TRÈS BIEN";
    elseif ($moy >= 14) $mention = "BIEN";
    elseif ($moy >= 12) $mention = "ASSEZ BIEN";
    elseif ($moy >= 10) $mention = "PASSABLE";
    else $mention = "INSUFFISANT";
    $c['mention'] = $mention;
    $c['appreciation'] = ($moy >= 10) ? "UE VALIDÉE" : "NON VALIDÉE";
    $total_credits += $c['credits'];
    $total_pondere += $moy * $c['credits'];
}
$moy_gen = ($total_credits > 0) ? round($total_pondere / $total_credits, 2) : 0;
$mention_gen = ($moy_gen >= 16) ? "TRÈS BIEN" : (($moy_gen >= 14) ? "BIEN" : (($moy_gen >= 12) ? "ASSEZ BIEN" : (($moy_gen >= 10) ? "PASSABLE" : "INSUFFISANT")));
$resultat = ($moy_gen >= 10) ? "SEMESTRE VALIDÉ" : "SEMESTRE NON VALIDÉ";

// === Classe PDF (paysage) ===
class PDF extends FPDF {
    function Header() {
        $this->SetFillColor(11,59,106);
        $this->Rect(0,0,297,20,'F');
        $this->Image('../img/hetec.png',10,2,25);
        $this->SetTextColor(255,255,255);
        $this->SetFont('Arial','B',13);
        $this->Cell(0,8,normalize_text("ECOLE SUPÉRIEURE DES HAUTES ÉTUDES TECHNOLOGIQUES ET COMMERCIALES (HETEC)"),0,1,'C');
        $this->SetFont('Arial','',10);
        $this->Cell(0,6,normalize_text("Agréée et Reconnue par l’État - Diplômes reconnus par le CAMES - Membre de l’AACSB"),0,1,'C');
        $this->Ln(6);
    }

    function Footer() {
        $this->SetY(-18);
        $this->SetFont('Arial','I',9);
        $this->SetTextColor(80,80,80);
        $this->MultiCell(0,5,normalize_text("HETEC OUAGA / ISTECH - DFC • Siège : Secteur 24, Rue de la Jeunesse (à ZAD), Ouagadougou, Burkina Faso • Tél. : +226 54 40 15 00 / 63 42 99 99 • Site : www.groupehetec.net • Email : scolarite@hetecburkina.net"),0,'C');
        $this->SetTextColor(0,0,0);
    }
}

$pdf = new PDF('L','mm','A4');
$pdf->AddPage();
$pdf->SetFont('Arial','',11);
$pdf->SetTextColor(0,0,0);

// === En-tête d'identité ===
$pdf->SetFont('Arial','B',11);
$pdf->Cell(120,8,normalize_text("GRADE : ".$etudiant['grade']),0,0,'L');
$pdf->Cell(0,8,normalize_text("ANNÉE ACADÉMIQUE : ".$etudiant['annee_academique']),0,1,'R');
$pdf->SetFont('Arial','',11);
$pdf->Cell(120,8,normalize_text("DOMAINE : ".$etudiant['domaine']),0,0,'L');
$pdf->Cell(0,8,normalize_text("SEMESTRE : SESSION NORMALE"),0,1,'R');
$pdf->Cell(120,8,normalize_text("SPÉCIALITÉ : ".$etudiant['designation_filiere']),0,0,'L');
$pdf->Cell(0,8,normalize_text("NIVEAU : ".$etudiant['niveau']),0,1,'R');
$pdf->Ln(2);
$pdf->Cell(0,8,normalize_text("NOM ET PRÉNOMS : ".strtoupper($etudiant['nom_etudiant'])." ".ucfirst($etudiant['prenom_etudiant'])),0,1,'L');
$pdf->Cell(0,8,normalize_text("NÉ(E) LE : ".date("d/m/Y",strtotime($etudiant['date_naissance']))." À ".strtoupper($etudiant['lieu_naissance'])),0,1,'L');
$pdf->Cell(0,8,normalize_text("MATRICULE : ".$etudiant['matricule_etudiant']),0,1,'L');
$pdf->Ln(3);

// === Tableau principal ===
$pdf->SetFont('Arial','B',10);
$pdf->SetFillColor(11,59,106);
$pdf->SetTextColor(255,255,255);
$pdf->Cell(35,9,normalize_text("CODE UE"),1,0,'C',true);
$pdf->Cell(80,9,normalize_text("UNITÉ D’ENSEIGNEMENT (UE) / COURS"),1,0,'C',true);
$pdf->Cell(20,9,normalize_text("CRÉDITS"),1,0,'C',true);
$pdf->Cell(25,9,normalize_text("MOYENNE"),1,0,'C',true);
$pdf->Cell(40,9,normalize_text("MENTION"),1,0,'C',true);
$pdf->Cell(40,9,normalize_text("APPRÉCIATION"),1,1,'C',true);
$pdf->SetTextColor(0,0,0);
$pdf->SetFont('Arial','',10);

foreach($cours as $c){
    $pdf->Cell(35,8,normalize_text($c['code_ue']),1);
    $pdf->Cell(80,8,normalize_text($c['designation_cours']),1);
    $pdf->Cell(20,8,$c['credits'],1,0,'C');
    $pdf->Cell(25,8,$c['moyenne'],1,0,'C');
    $pdf->Cell(40,8,normalize_text($c['mention']),1,0,'C');
    $pdf->Cell(40,8,normalize_text($c['appreciation']),1,1,'C');
}

// === Résumé à droite ===
$pdf->Ln(5);
$pdf->SetFont('Arial','B',11);
$pdf->Cell(0,8,normalize_text("BILAN DU SEMESTRE"),0,1,'L');
$pdf->SetFont('Arial','',11);
$pdf->Cell(150,7,normalize_text("TOTAL CRÉDITS : ".$total_credits),0,0,'L');
$pdf->Cell(100,7,normalize_text("MOYENNE SEMESTRIELLE : ".$moy_gen."/20"),0,1,'R');
$pdf->Cell(150,7,normalize_text("MENTION : ".strtoupper($mention_gen)),0,0,'L');
$pdf->Cell(100,7,normalize_text("RÉSULTAT : ".$resultat),0,1,'R');
$pdf->Ln(10);

// === Signature et cachet ===
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,8,normalize_text("LE DIRECTEUR DÉLÉGUÉ"),0,1,'R');
$pdf->Image('../img/cachet.JPG',230,$pdf->GetY()+3,30);
$pdf->Image('../img/signature.JPG',260,$pdf->GetY()+3,30);

// === Sortie PDF ===
$filename = "Releve_Notes_".$etudiant['nom_etudiant']."_".$etudiant['prenom_etudiant'].".pdf";
$pdf->Output('I',$filename);
?>
