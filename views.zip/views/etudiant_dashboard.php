<?php   
session_start(); 

if (!isset($_SESSION['id_etudiant'])) { 
    header("Location: ../portail.php"); 
    exit(); 
}

require_once '../models/config.php'; 

$id = $_SESSION['id_etudiant']; 

// 🔹 On récupère la filière et l’option en faisant une double jointure
$stmt = $pdo->prepare("
    SELECT 
        i.*, 
        o.designation_option, 
        f.designation_filiere
    FROM inscriptions i
    LEFT JOIN options o ON i.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    WHERE i.id_inscription = :id
");
$stmt->execute(['id' => $id]);
$etudiant = $stmt->fetch(PDO::FETCH_ASSOC); 

if (!$etudiant) { 
    header("Location: ../etudiant_login.php"); 
    exit(); 
}

$formattedDate = date("d/m/Y", strtotime($etudiant['date_naissance'])); 
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Tableau de Bord Étudiant – HETEC Burkina Faso</title>
    <link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0-alpha1/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: "Segoe UI", sans-serif; background: #f4f7fb; margin: 0; color: #222; }
        header { background: linear-gradient(90deg, #0b3b6a, #c58a00); color: #fff; padding: 20px 25px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        header h1 { margin: 0; font-size: 1.5rem; display: flex; align-items: center; gap: 10px; }
        header .logout { color: #fff; text-decoration: none; background: rgba(255,255,255,0.15); padding: 8px 14px; border-radius: 6px; font-weight: 600; transition: 0.3s; }
        header .logout:hover { background: rgba(255,255,255,0.3); }
        .container { max-width: 1000px; margin: 40px auto; background: #fff; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); padding: 30px; }
        h2 { color: #0b3b6a; border-left: 4px solid #c58a00; padding-left: 10px; margin-bottom: 20px; }
        .profile { display: flex; flex-wrap: wrap; align-items: center; gap: 25px; }
        .profile img { width: 130px; height: 130px; border-radius: 50%; object-fit: cover; border: 3px solid #0b3b6a; box-shadow: 0 0 6px rgba(0,0,0,0.1); }
        .info, .details { flex: 1; min-width: 250px; }
        .info p, .details p { margin: 8px 0; font-size: 0.9rem; color: #555; }
        .info strong, .details strong { color: #0b3b6a; }
        .btn { background: linear-gradient(90deg, #0b3b6a, #c58a00); color: #fff; padding: 8px 15px; border-radius: 8px; text-decoration: none; font-weight: 600; transition: 0.3s; }
        .btn:hover { opacity: 0.9; transform: translateY(-2px); }
        .btn-group { margin-top: 25px; display: flex; gap: 10px; flex-wrap: wrap; justify-content: space-between; }
        .btn-group .btn { flex: 1; max-width: 200px; }
        footer { text-align: center; padding: 20px; font-size: 0.9rem; color: #666; }
        footer a { color: #0b3b6a; text-decoration: none; }
        footer a:hover { text-decoration: underline; }
        @media (max-width: 768px) {
            .profile { flex-direction: column; align-items: flex-start; }
            .btn-group { flex-direction: column; }
        }
    </style>
</head>
<body>

<header>
  <h1><i class="fa-solid fa-user-graduate"></i> Espace Étudiant</h1>
  <a href="portail.php" class="logout"><i class="fa-solid fa-right-from-bracket"></i> Déconnexion</a>
</header>

<div class="container">
  <h2>Bienvenue, <?= htmlspecialchars($_SESSION['nom_etudiant']) ?> 👋</h2>

  <div class="profile">
    <img src="<?= !empty($etudiant['photo_etudiant']) ? '../uploads/'.$etudiant['photo_etudiant'] : '../img/avatar.png'; ?>" alt="Photo Étudiant">
    <div class="info">
      <p><strong>Matricule :</strong> <?= htmlspecialchars($etudiant['matricule_etudiant']) ?></p>
      <p><strong>Sexe :</strong> <?= htmlspecialchars($etudiant['sexe']) ?></p>
      <p><strong>Téléphone :</strong> <?= htmlspecialchars($etudiant['telephone']) ?></p>
      <p><strong>Mot de passe :</strong> <?= htmlspecialchars($etudiant['mot_de_passe']) ?></p>
      <p><strong>Date de naissance :</strong> <?= $formattedDate ?></p>
      <p><strong>Lieu de naissance :</strong> <?= htmlspecialchars($etudiant['lieu_naissance'] ?? 'Non précisé') ?></p>
    </div>

    <div class="details">
      <p><strong>Filière et Option :</strong> 
        <?= htmlspecialchars($etudiant['designation_option'] . ' — ' . $etudiant['designation_filiere']) ?>
      </p>
      <p><strong>Grade :</strong> <?= htmlspecialchars($etudiant['grade'] ?? 'Non précisé') ?></p>
      <p><strong>Mention :</strong> <?= htmlspecialchars($etudiant['mention'] ?? 'Non précisé') ?></p>
      <p><strong>Niveau :</strong> <?= htmlspecialchars($etudiant['niveau']) ?></p>
      <p><strong>Domaine :</strong> <?= htmlspecialchars($etudiant['domaine']) ?></p>
      <p><strong>Semestre :</strong> <?= htmlspecialchars($etudiant['semestre']) ?></p>
      <p><strong>Statut d'inscription :</strong> <?= htmlspecialchars($etudiant['statut_inscription']) ?></p>
    </div>
  </div>

  <!-- Liens directs vers fichiers -->
  <div class="btn-group">
    <a href="nos_cours.php" class="btn"><i class="fa-solid fa-book"></i> Nos cours</a>
    <a href="mes_cotes.php" class="btn"><i class="fa-solid fa-chart-line"></i> Mes cotes</a>
    <a href="documents_academiques.php" class="btn"><i class="fa-solid fa-file-alt"></i> Mes documents académiques</a>
    <a href="mes_notifications.php" class="btn"><i class="fa-solid fa-bell"></i> Mes Notifications</a>
    <a href="mes_correspondances.php" class="btn"><i class="fa-solid fa-envelope"></i> Mes correspondances</a>
  </div>

</div>

<footer>
  &copy; <?= date('Y') ?> HETEC Burkina Faso — Plateforme Académique Numérique |
  Développé par <a href="https://www.ms-solutionslab.com" target="_blank"><strong>MS Solutions Lab</strong></a>
</footer>

</body>
</html>
