<?php
/**
 * ===========================================================
 *  Fichier : reset_impression.php
 *  Description : Réinitialise l’état d’impression de la carte d’un étudiant
 *  Auteur : MS Solutions Lab / HETEC Burkina Faso
 *  ===========================================================
 */

require_once '../models/config.php';

// Vérifie que l’ID est bien transmis
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("<h3 style='color:red;'>Erreur : ID étudiant manquant ou invalide.</h3>");
}

$id = (int)$_GET['id'];

try {
    // Réinitialisation du statut d’impression
    $stmt = $pdo->prepare("UPDATE inscriptions SET carte_imprimee = 0 WHERE id_inscription = ?");
    $stmt->execute([$id]);

    // Redirection vers la liste des cartes
    header("Location: carte_etudiant.php?reset=success");
    exit();
} catch (PDOException $e) {
    echo "<h3 style='color:red;'>Erreur lors de la réinitialisation :</h3> " . htmlspecialchars($e->getMessage());
    exit();
}
?>
