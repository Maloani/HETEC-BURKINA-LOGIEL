<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

require_once '../config/db.php';

// === Fonction pour générer un matricule ===
function generateMatricule() {
    return 'HO ' . str_pad(rand(0, 99999), 5, '0', STR_PAD_LEFT);
}

// === Récupération des options avec leurs filières ===
$stmtOption = $db->query("
    SELECT o.id_option, o.designation_option, f.designation_filiere
    FROM options o
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    ORDER BY f.designation_filiere ASC, o.designation_option ASC
");
$options = $stmtOption->fetchAll(PDO::FETCH_ASSOC);

// === Enregistrement d'une nouvelle inscription ===
if (isset($_POST['ajouter_inscription'])) {
    $matricule = generateMatricule();
    $nom = trim($_POST['nom_etudiant']);
    $prenom = trim($_POST['prenom_etudiant']);
    $sexe = $_POST['sexe'];
    $date_naissance = $_POST['date_naissance'];
    $lieu_naissance = trim($_POST['lieu_naissance']);
    $telephone = trim($_POST['telephone']);
    $mot_de_passe = trim($_POST['mot_de_passe']);
    $id_option = (int)$_POST['id_option'];
    $annee_academique = trim($_POST['annee_academique']);
    $grade = $_POST['grade'];
    $domaine = trim($_POST['domaine']);
    $mention = trim($_POST['mention']);
    $niveau = $_POST['niveau'];
    $semestre = $_POST['semestre'];
    $photo = null;

    // === Vérification de doublon ===
    $check = $db->prepare("
        SELECT COUNT(*) FROM inscriptions 
        WHERE nom_etudiant = :nom 
        AND prenom_etudiant = :prenom 
        AND id_option = :id_option 
        AND annee_academique = :annee
    ");
    $check->execute([
        ':nom' => $nom,
        ':prenom' => $prenom,
        ':id_option' => $id_option,
        ':annee' => $annee_academique
    ]);

    if ($check->fetchColumn() > 0) {
        $message = "<p class='error' id='msg'>⚠️ Cet étudiant est déjà inscrit dans la même option pour cette année académique.</p>";
    } else {
        // === Upload photo ===
        if (!empty($_FILES['photo_etudiant']['name'])) {
            $targetDir = "../uploads/";
            if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
            $photo = time() . "_" . basename($_FILES["photo_etudiant"]["name"]);
            move_uploaded_file($_FILES["photo_etudiant"]["tmp_name"], $targetDir . $photo);
        }

        // === Insertion avec les nouveaux champs ===
        $stmt = $db->prepare("INSERT INTO inscriptions 
            (matricule_etudiant, nom_etudiant, prenom_etudiant, sexe, date_naissance, lieu_naissance, telephone, mot_de_passe, id_option, grade, domaine, mention, niveau, semestre, photo_etudiant, annee_academique)
            VALUES (:matricule, :nom, :prenom, :sexe, :date_naissance, :lieu_naissance, :telephone, :mot_de_passe, :id_option, :grade, :domaine, :mention, :niveau, :semestre, :photo, :annee)
        ");
        $stmt->execute([
            ':matricule' => $matricule,
            ':nom' => $nom,
            ':prenom' => $prenom,
            ':sexe' => $sexe,
            ':date_naissance' => $date_naissance,
            ':lieu_naissance' => $lieu_naissance,
            ':telephone' => $telephone,
            ':mot_de_passe' => $mot_de_passe,
            ':id_option' => $id_option,
            ':grade' => $grade,
            ':domaine' => $domaine,
            ':mention' => $mention,
            ':niveau' => $niveau,
            ':semestre' => $semestre,
            ':photo' => $photo,
            ':annee' => $annee_academique
        ]);

        $message = "<p class='success' id='msg'>✅ Nouvelle inscription enregistrée avec succès !</p>";
    }
}

// === CONFIRMATION / REJET ===
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    if ($_GET['action'] === 'confirmer') {
        $newStatut = 'confirmée';
    } elseif ($_GET['action'] === 'rejeter') {
        $newStatut = 'rejetée';
    }

    if (isset($newStatut)) {
        $stmt = $db->prepare("UPDATE inscriptions SET statut_inscription = :statut WHERE id_inscription = :id");
        $stmt->execute([':statut' => $newStatut, ':id' => $id]);
        $message = "<p class='success' id='msg'>✅ Statut mis à jour : $newStatut</p>";
    }
}

// === Pagination ===
$limit = 5;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;
$total = $db->query("SELECT COUNT(*) FROM inscriptions")->fetchColumn();
$totalPages = ceil($total / $limit);

// === Liste des inscriptions ===
$stmt = $db->prepare("
    SELECT i.*, o.designation_option, f.designation_filiere
    FROM inscriptions i
    LEFT JOIN options o ON i.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    ORDER BY i.date_inscription DESC
    LIMIT :limit OFFSET :offset
");
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$inscriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Gestion des Inscriptions</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
body {
  font-family: 'Segoe UI', sans-serif;
  background: #f4f7fb;
  margin: 0;
  padding: 0;
}

header {
  background: linear-gradient(90deg, #0b3b6a, #c58a00);
  color: white;
  text-align: center;
  padding: 1rem;
}

.container {
  width: 90%;
  max-width: 1100px;
  margin: 30px auto;
  background: #fff;
  padding: 25px;
  border-radius: 12px;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.1);
}

/* === Bouton principal === */
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  background: #198754;
  color: #fff;
  border: none;
  padding: 8px 14px;
  border-radius: 8px;
  cursor: pointer;
  text-decoration: none;
  transition: all 0.3s ease;
  font-weight: 500;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}
.btn:hover {
  background: #157347;
  transform: translateY(-2px);
}
.btn i {
  font-size: 0.9rem;
}

/* === Table === */
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 15px;
}
th {
  background: #0b3b6a;
  color: #fff;
  padding: 10px;
  text-align: left;
  font-size: 0.95rem;
}
td {
  padding: 10px;
  border-bottom: 1px solid #eee;
  vertical-align: middle;
  font-size: 0.95rem;
}

/* === Statuts === */
.status {
  font-weight: 600;
  padding: 6px 12px;
  border-radius: 20px;
  text-align: center;
  display: inline-block;
}
.status.en_attente {
  background: #fff3cd;
  color: #856404;
}
.status.confirmée {
  background: #d4edda;
  color: #155724;
}
.status.rejetée {
  background: #f8d7da;
  color: #721c24;
}

/* === Boutons d'action === */
.action-btns {
  display: flex;
  gap: 6px;
}

.action-btns a {
  width: 34px;
  height: 34px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  color: #fff;
  text-decoration: none;
  font-size: 0.9rem;
  transition: all 0.25s ease;
}

.confirmer {
  background: #198754;
}
.confirmer:hover {
  background: #157347;
  transform: scale(1.05);
}

.rejeter {
  background: #dc3545;
}
.rejeter:hover {
  background: #bb2d3b;
  transform: scale(1.05);
}

.modifier {
  background: #ffc107;
  color: #000;
}
.modifier:hover {
  background: #e0a800;
  transform: scale(1.05);
}

/* === Photo arrondie === */
.photo-thumb {
  width: 55px;
  height: 55px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid #eee;
  box-shadow: 0 2px 4px rgba(0,0,0,0.08);
}

/* === Pagination === */
.pagination {
  text-align: center;
  margin-top: 20px;
}
.pagination a {
  display: inline-block;
  margin: 0 5px;
  padding: 8px 14px;
  border-radius: 6px;
  border: 1px solid #ccc;
  text-decoration: none;
  color: #007bff;
  transition: all 0.3s ease;
}
.pagination a.active {
  background: #007bff;
  color: #fff;
  font-weight: bold;
}
.pagination a:hover {
  background: #0056b3;
  color: #fff;
}
/* === FORMULAIRE D’INSCRIPTION — MISE EN FORME MODERNE === */
form {
  background: #ffffff;
  border: 1px solid #dcdfe6;
  border-radius: 12px;
  padding: 25px 30px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.05);
  margin-bottom: 35px;
}

form h2 {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 1.3rem;
  color: #0b3b6a;
  margin-bottom: 20px;
  border-bottom: 2px solid #c58a00;
  padding-bottom: 8px;
}

form label {
  display: block;
  font-weight: 600;
  color: #333;
  margin-bottom: 4px;
}

form input,
form select {
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 0.95rem;
  color: #333;
  background-color: #f9fafc;
  transition: border-color 0.3s, box-shadow 0.3s;
}

form input:focus,
form select:focus {
  outline: none;
  border-color: #0b3b6a;
  box-shadow: 0 0 4px rgba(11,59,106,0.3);
  background-color: #fff;
}

/* Champs côte à côte sur grand écran */
form div {
  margin-bottom: 15px;
}

form .form-row {
  display: flex;
  gap: 15px;
  flex-wrap: wrap;
}

form .form-row > div {
  flex: 1;
  min-width: 220px;
}

form button {
  background: linear-gradient(90deg, #0b3b6a, #c58a00);
  color: white;
  border: none;
  padding: 12px 18px;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  font-size: 0.95rem;
  transition: all 0.3s ease;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

form button:hover {
  transform: translateY(-2px);
  background: linear-gradient(90deg, #084070, #b37a00);
}

input[type="file"] {
  background-color: #fff;
  padding: 6px;
  border: 1px dashed #bbb;
  cursor: pointer;
}

.success {
  background: #e9f9ef;
  color: #145a32;
  border: 1px solid #bde5b8;
  border-radius: 8px;
  padding: 10px 15px;
  margin-bottom: 15px;
  font-weight: 500;
  text-align: center;
}
.error {
  background: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
  border-radius: 8px;
  padding: 10px 15px;
  text-align: center;
  font-weight: 500;
  margin-bottom: 15px;
}


</style>
</head>
<body>

<header><h1><i class="fa fa-clipboard-list"></i> Gestion des Inscriptions</h1></header>
<div class="container">
<?= $message ?? '' ?>

<a href="admin_dashboard.php" class="btn btn-primary mb-3"><i class="fa fa-home"></i> Accueil</a><br><br>

<form method="post" enctype="multipart/form-data">
  <h2><i class="fa fa-user-plus"></i> Nouvelle Inscription</h2>

  <div class="form-row">
    <div><label>Nom :</label><input type="text" name="nom_etudiant" required></div>
    <div><label>Prénom :</label><input type="text" name="prenom_etudiant" required></div>
    <div><label>Sexe :</label>
      <select name="sexe" required>
        <option value="">-- Sélectionner --</option>
        <option value="Homme">Homme</option>
        <option value="Femme">Femme</option>
      </select>
    </div>
  </div>

  <div class="form-row">
    <div><label>Date de naissance :</label><input type="date" name="date_naissance" required></div>
    <div><label>Lieu de naissance :</label><input type="text" name="lieu_naissance" required></div>
    <div><label>Téléphone :</label><input type="text" name="telephone" required></div>
  </div>

  <div class="form-row">
    <div><label>Mot de passe :</label><input type="password" name="mot_de_passe" required></div>
    <div><label>Filière & Option :</label>
      <select name="id_option" required>
        <option value="">-- Choisir --</option>
        <?php foreach ($options as $opt): ?>
          <option value="<?= $opt['id_option'] ?>">
            <?= htmlspecialchars($opt['designation_option'] . ' – ' . $opt['designation_filiere']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div><label>Année académique :</label>
      <select name="annee_academique" required>
        <option value="">-- Sélectionner --</option>
        <?php $y = 2024; for ($i = 0; $i < 15; $i++) echo "<option>{$y}-".($y+1)."</option>"; $y++; ?>
      </select>
    </div>
  </div>

  <div class="form-row">
    <div><label>Grade :</label>
      <select name="grade" required>
        <option value="">-- Sélectionner --</option>
        <option value="LICENCE PROFESSIONNELLE">LICENCE PROFESSIONNELLE</option>
        <option value="MASTER PROFESSIONNELLE">MASTER PROFESSIONNELLE</option>
      </select>
    </div>
    <div><label>Domaine :</label><input type="text" name="domaine" placeholder="Ex : Sciences Économiques et de Gestion" required></div>
    <div><label>Mention :</label><input type="text" name="mention" placeholder="Ex : Gestion" required></div>
  </div>

  <div class="form-row">
    <div><label>Niveau :</label>
      <select name="niveau" required>
        <option value="">-- Sélectionner --</option>
        <option value="LICENCE I">LICENCE I</option>
        <option value="LICENCE II">LICENCE II</option>
        <option value="LICENCE III">LICENCE III</option>
        <option value="MASTER I">MASTER I</option>
        <option value="MASTER II">MASTER II</option>
      </select>
    </div>
    <div><label>Semestre :</label>
      <select name="semestre" required>
        <option value="">-- Choisir --</option>
        <option value="Semestre 1">Semestre 1</option>
        <option value="Semestre 2">Semestre 2</option>
        <option value="Semestre 3">Semestre 3</option>
        <option value="Semestre 4">Semestre 4</option>
        <option value="Semestre 5">Semestre 5</option>
        <option value="Semestre 6">Semestre 6</option>
      </select>
    </div>
    <div><label>Photo de l’étudiant :</label><input type="file" name="photo_etudiant" accept="image/*"></div>
  </div>

  <button type="submit" name="ajouter_inscription"><i class="fa fa-save"></i> Enregistrer</button>
</form>

<!-- TABLEAU -->
<table>
<tr>
    <th>Photo</th>
    <th>Matricule</th>
    <th>Nom</th>
    <th>Prénom</th>
    <th>Téléphone</th>
    <th>Mot de passe</th> <!-- ✅ Champ déjà ajouté -->
    <th>Sexe</th>
    <th>Grade</th> <!-- ✅ Nouveau -->
    <th>Domaine</th> <!-- ✅ Nouveau -->
    <th>Mention</th> <!-- ✅ Nouveau -->
    <th>Niveau</th> <!-- ✅ Nouveau -->
    <th>Semestre</th> <!-- ✅ Nouveau -->
    <th>Filière</th>
    <th>Option</th>
    <th>Année</th>
    <th>Statut</th>
    <th>Actions</th>
    <th>Imprimer</th>
</tr>

<?php foreach($inscriptions as $i): ?>
<tr>
    <td>
        <?php if (!empty($i['photo_etudiant'])): ?>
            <img src="../uploads/<?= htmlspecialchars($i['photo_etudiant'] ?? '') ?>" 
                 alt="Photo" 
                 class="photo-thumb" 
                 style="width:50px;height:50px;border-radius:50%;object-fit:cover;cursor:pointer;border:1px solid #ccc;">
        <?php else: ?>
            <i class="fa fa-user-circle" style="font-size:40px;color:#bbb;"></i>
        <?php endif; ?>
    </td>
    <td><?= htmlspecialchars($i['matricule_etudiant'] ?? '') ?></td>
    <td><?= htmlspecialchars($i['nom_etudiant'] ?? '') ?></td>
    <td><?= htmlspecialchars($i['prenom_etudiant'] ?? '') ?></td>
    <td><?= htmlspecialchars($i['telephone'] ?? '') ?></td>
    <td><?= htmlspecialchars($i['mot_de_passe'] ?? '') ?></td> <!-- ✅ Mot de passe -->
    <td><?= htmlspecialchars($i['sexe'] ?? '') ?></td>
    <td><?= htmlspecialchars($i['grade'] ?? '') ?></td> <!-- ✅ Nouveau -->
    <td><?= htmlspecialchars($i['domaine'] ?? '') ?></td> <!-- ✅ Nouveau -->
    <td><?= htmlspecialchars($i['mention'] ?? '') ?></td> <!-- ✅ Nouveau -->
    <td><?= htmlspecialchars($i['niveau'] ?? '') ?></td> <!-- ✅ Nouveau -->
    <td><?= htmlspecialchars($i['semestre'] ?? '') ?></td> <!-- ✅ Nouveau -->
    <td><?= htmlspecialchars($i['designation_filiere'] ?? '') ?></td>
    <td><?= htmlspecialchars($i['designation_option'] ?? '') ?></td>
    <td><?= htmlspecialchars($i['annee_academique'] ?? '') ?></td>
    <td>
        <?php
            $statut = $i['statut_inscription'] ?? 'en_attente';
            $class = $statut === 'confirmée' ? 'confirmée' : ($statut === 'rejetée' ? 'rejetée' : 'en_attente');
        ?>
        <span class="status <?= $class ?>"><?= ucfirst($statut) ?></span>
    </td>
    <td class="action-btns">
        <a href="?action=confirmer&id=<?= $i['id_inscription'] ?>" class="confirmer" title="Confirmer"><i class="fa fa-check"></i></a>
        <a href="?action=rejeter&id=<?= $i['id_inscription'] ?>" class="rejeter" title="Rejeter"><i class="fa fa-times"></i></a>
        <a href="modifier_etudiant.php?id=<?= $i['id_inscription'] ?>" class="modifier" title="Modifier"><i class="fa fa-pen"></i></a>
    </td>
    <td>
       <a href="imprimer_carte.php?id=<?= $i['id_inscription'] ?>" 
          class="btn btn-primary" 
          title="Imprimer sa carte d'étudiant" 
          target="_blank">
          <i class="fa fa-id-card"></i> Imprimer sa carte
       </a>
    </td>
</tr>
<?php endforeach; ?>
</table>



<div class="pagination">
<?php if ($page > 1): ?><a href="?page=<?= $page-1 ?>"><i class="fa fa-arrow-left"></i> Précédent</a><?php endif; ?>
<span>Page <?= $page ?> / <?= $totalPages ?></span>
<?php if ($page < $totalPages): ?><a href="?page=<?= $page+1 ?>">Suivant <i class="fa fa-arrow-right"></i></a><?php endif; ?>
</div>

</div>
</body>
</html>
