<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../models/config.php';
require_once __DIR__ . '/fpdf/fpdf.php';
require_once __DIR__ . '/phpqrcode/qrlib.php';

// === Fonction de normalisation ===
function normalize_text($text) {
    $text = str_replace(
        ["’", "‘", "‛", "‚", "´", "`", "“", "”", "„"],
        ["'", "'", "'", "'", "'", "'", '"', '"', '"'],
        $text
    );
    return utf8_decode($text);
}

// === Récupération des données ===
$stmt = $pdo->query("
    SELECT 
        i.matricule_etudiant, i.nom_etudiant, i.prenom_etudiant, i.sexe, 
        i.date_naissance, i.lieu_naissance, i.telephone, i.photo_etudiant,
        o.designation_option, f.designation_filiere
    FROM inscriptions i
    LEFT JOIN options o ON i.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    ORDER BY f.designation_filiere ASC, o.designation_option ASC, i.nom_etudiant ASC
");
$etudiants = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$etudiants) {
    die("Aucun étudiant trouvé.");
}

// === Génération du QR code (dernière page uniquement) ===
$qrText = "HETEC - Liste complète des étudiants\nGénéré le " . date('d/m/Y');
$qrFile = __DIR__ . "/../uploads/qrcode_all_" . md5($qrText) . ".png";
QRcode::png($qrText, $qrFile, QR_ECLEVEL_L, 3);

// === Classe PDF personnalisée ===
class PDF extends FPDF {
    public $firstPage = true; 
    public $showFooter = false;

    function Header() {
        if ($this->firstPage) {
            // === Logo + entête complet uniquement sur la première page ===
            $this->Image('../img/hetec.png', 85, 8, 40);
            $this->Ln(30);
            $this->SetFont('Arial','B',10);
            $this->Cell(0,6,utf8_decode("Ministère de l'Enseignement Supérieur, de la Recherche et de l'Innovation (MESRI)"),0,1,'C');
            $this->Ln(1);
            $this->SetFont('Arial','B',12);
            $this->Cell(0,7,utf8_decode("ECOLE SUPERIEURE DES HAUTES ETUDES TECHNOLOGIQUES ET COMMERCIALES (HETEC)"),0,1,'C');
            $this->SetFont('Arial','',10);
            $this->Cell(0,6,utf8_decode("Diplômes reconnus par le CAMES - Membre de l'AACSB"),0,1,'C');
            $this->Ln(8);
            $this->Line(10, 48, 200, 48);
        }
    }

    function Footer() {
        // === Numérotation automatique des pages ===
        $this->SetY(-15);
        $this->SetFont('Arial','I',8);
        $this->Cell(0,10,utf8_decode('Page '.$this->PageNo().' sur {nb}'),0,0,'R');

        // === Footer complet uniquement sur la dernière page ===
        if ($this->showFooter) {
            $this->SetY(-50);
            $this->SetDrawColor(11,59,106);
            $this->Line(10, $this->GetY(), 200, $this->GetY());
            $this->Ln(3);
            $this->SetFont('Arial','',8);
            $this->Cell(0,4,utf8_decode("Siège : Ouagadougou (Burkina Faso), Secteur 24, Rue de la Jeunesse (à la ZAD)"),0,1,'C');
            $this->Cell(0,4,utf8_decode("Tél : (+226) 56 15 00 00 / 63 42 99 99 / 69 36 03 36"),0,1,'C');
            $this->Cell(0,4,utf8_decode("Adresse : 11 BP 765 cms Ouaga 11 | Facebook : HETEC OUAGA | Site web : www.groupehetec.net"),0,1,'C');
            $this->Cell(0,4,utf8_decode("E-mail : scolarite@hetecburkina.net"),0,1,'C');
        }
    }
}

// === Création du PDF ===
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->Ln(10);

// === Titre principal (répété par filière) ===
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,10,utf8_decode("LISTE COMPLÈTE DES ÉTUDIANTS CLASSÉS PAR FILIÈRE ET OPTION"),0,1,'C');
$pdf->Ln(8);

$currentFiliere = '';
$currentOption = '';
$header = ["Matricule","Nom","Prénom","Sexe","Naissance","Lieu","Téléphone","Photo"];
$widths = [20,28,28,15,25,25,25,20];

// === Boucle principale ===
foreach ($etudiants as $et) {
    // === Nouvelle page pour chaque filière ===
    if ($currentFiliere != $et['designation_filiere']) {
        if ($currentFiliere != '') {
            $pdf->AddPage();
            $pdf->firstPage = false;
            $pdf->SetFont('Arial','B',12);
            $pdf->Cell(0,10,utf8_decode("LISTE COMPLÈTE DES ÉTUDIANTS CLASSÉS PAR FILIÈRE ET OPTION"),0,1,'C');
            $pdf->Ln(8);
        }
        $currentFiliere = $et['designation_filiere'];
        $currentOption = '';

        $pdf->SetFont('Arial','B',11);
        $pdf->SetTextColor(11,59,106);
        $pdf->Cell(0,8,utf8_decode("FILIÈRE : " . strtoupper($currentFiliere)),0,1,'L');
        $pdf->SetTextColor(0);
        $pdf->Ln(2);
    }

    // === Nouvelle section pour chaque option ===
    if ($currentOption != $et['designation_option']) {
        $currentOption = $et['designation_option'];
        $pdf->Ln(3);
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(0,7,utf8_decode("Option : " . $currentOption),0,1,'L');

        $pdf->SetFont('Arial','B',9);
        $pdf->SetFillColor(11,59,106);
        $pdf->SetTextColor(255);
        foreach ($header as $i => $col) {
            $pdf->Cell($widths[$i],8,utf8_decode($col),1,0,'C',true);
        }
        $pdf->Ln();
        $pdf->SetTextColor(0);
    }

    // === Étudiant ===
    $pdf->SetFont('Arial','',9);
    $pdf->Cell($widths[0],20,utf8_decode($et['matricule_etudiant']),1);
    $pdf->Cell($widths[1],20,utf8_decode($et['nom_etudiant']),1);
    $pdf->Cell($widths[2],20,utf8_decode($et['prenom_etudiant']),1);
    $pdf->Cell($widths[3],20,utf8_decode($et['sexe']),1);
    $pdf->Cell($widths[4],20,$et['date_naissance'],1);
    $pdf->Cell($widths[5],20,utf8_decode($et['lieu_naissance']),1);
    $pdf->Cell($widths[6],20,utf8_decode($et['telephone']),1);

    $photoPath = '../uploads/'.$et['photo_etudiant'];
    if (!empty($et['photo_etudiant']) && file_exists($photoPath)) {
        $x = $pdf->GetX();
        $y = $pdf->GetY();
        $pdf->Cell($widths[7],20,'',1,0,'C');
        $pdf->Image($photoPath, $x + 3, $y + 3, 14, 14);
        $pdf->Ln();
    } else {
        $pdf->Cell($widths[7],20,'-',1,1,'C');
    }
}

// === Dernière page : QR + signature + footer ===
$pdf->AddPage();
$pdf->firstPage = false;
$pdf->showFooter = true;

// QR code
$pdf->Image($qrFile, 15, $pdf->GetY() + 20, 25, 25);

// Signature
$pdf->SetY($pdf->GetY() + 30);
$pdf->SetFont('Arial','',11);
$pdf->Cell(0,8,utf8_decode("Fait à Ouagadougou, le " . date('d/m/Y') . "."),0,1,'R');
$pdf->Ln(4);
$pdf->SetFont('Arial','B',11);
$pdf->Cell(0,8,utf8_decode("LE DIRECTEUR DÉLÉGUÉ"),0,1,'R');

// Sortie PDF
$pdf->Output("I", "Liste_complète_étudiants_HETEC.pdf");

// Nettoyage QR temporaire
if (file_exists($qrFile)) unlink($qrFile);
exit;
?>
