<?php
// === Configuration et sécurité ===
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../config/db.php';
session_start();

// Vérification de la session admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.html");
    exit();
}

// Vérifier si un ID est passé
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<p class='error'>Aucun administrateur sélectionné.</p>";
    exit();
}

$id_admin = (int) $_GET['id'];

// Récupération de l’administrateur
try {
    $stmt = $db->prepare("SELECT * FROM administrateurs WHERE id_admin = :id_admin");
    $stmt->bindParam(':id_admin', $id_admin, PDO::PARAM_INT);
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        echo "<p class='error'>Administrateur introuvable.</p>";
        exit();
    }
} catch (PDOException $e) {
    echo "<p class='error'>Erreur lors de la récupération : " . $e->getMessage() . "</p>";
    exit();
}

// === Traitement de la mise à jour ===
if (isset($_POST['update'])) {
    $nom_complet = trim($_POST['nom_complet']);
    $telephone = trim($_POST['telephone']);
    $email = trim($_POST['email']);
    $poste = trim($_POST['poste']);
    $statut = trim($_POST['statut']);
    $mot_de_passe = trim($_POST['mot_de_passe']);

    if (!empty($nom_complet) && !empty($telephone) && !empty($email)) {
        try {
            if (!empty($mot_de_passe)) {
                $hashed_password = password_hash($mot_de_passe, PASSWORD_DEFAULT);
                $query = "UPDATE administrateurs 
                          SET nom_complet = :nom_complet, telephone = :telephone, email = :email, 
                              poste = :poste, statut = :statut, mot_de_passe = :mot_de_passe 
                          WHERE id_admin = :id_admin";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':mot_de_passe', $hashed_password);
            } else {
                $query = "UPDATE administrateurs 
                          SET nom_complet = :nom_complet, telephone = :telephone, email = :email, 
                              poste = :poste, statut = :statut 
                          WHERE id_admin = :id_admin";
                $stmt = $db->prepare($query);
            }

            $stmt->bindParam(':nom_complet', $nom_complet);
            $stmt->bindParam(':telephone', $telephone);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':poste', $poste);
            $stmt->bindParam(':statut', $statut);
            $stmt->bindParam(':id_admin', $id_admin, PDO::PARAM_INT);

            if ($stmt->execute()) {
                echo "<p class='success'>✅ Administrateur mis à jour avec succès !</p>";
                // Rafraîchir les données
                $stmt = $db->prepare("SELECT * FROM administrateurs WHERE id_admin = :id_admin");
                $stmt->bindParam(':id_admin', $id_admin, PDO::PARAM_INT);
                $stmt->execute();
                $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            } else {
                echo "<p class='error'>❌ Erreur lors de la mise à jour.</p>";
            }
        } catch (PDOException $e) {
            echo "<p class='error'>Erreur SQL : " . $e->getMessage() . "</p>";
        }
    } else {
        echo "<p class='error'>⚠️ Veuillez remplir tous les champs obligatoires.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Modifier un Administrateur</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
    body {
        font-family: 'Segoe UI', sans-serif;
        background: #f4f7fb;
        margin: 0;
        padding: 0;
    }
    header {
        background: linear-gradient(90deg, #0b3b6a, #c58a00);
        color: #fff;
        padding: 1rem;
        text-align: center;
    }
    h1 {
        margin: 0;
        font-size: 1.7rem;
    }
    .container {
        background: #fff;
        max-width: 700px;
        margin: 40px auto;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 3px 10px rgba(0,0,0,0.1);
    }
    form label {
        font-weight: bold;
        display: block;
        margin-top: 15px;
    }
    form input, form select {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 6px;
        margin-top: 5px;
        font-size: 1rem;
    }
    .password-box {
        background: #f9f9f9;
        border: 1px dashed #ccc;
        padding: 10px;
        font-family: monospace;
        border-radius: 6px;
        color: #555;
        font-size: 0.9rem;
        word-wrap: break-word;
    }
    button {
        width: 100%;
        background-color: #28a745;
        color: white;
        border: none;
        padding: 12px;
        border-radius: 6px;
        margin-top: 20px;
        font-size: 1rem;
        cursor: pointer;
        transition: 0.3s;
    }
    button:hover {
        background-color: #218838;
    }
    .success, .error {
        text-align: center;
        font-weight: bold;
        margin: 15px 0;
    }
    .success { color: green; }
    .error { color: red; }
    .back-btn {
        display: inline-block;
        margin: 20px auto;
        text-decoration: none;
        background-color: #007bff;
        color: #fff;
        padding: 10px 20px;
        border-radius: 6px;
        display: block;
        text-align: center;
        width: fit-content;
    }
    .back-btn:hover {
        background-color: #0056b3;
    }
    @media(max-width:768px){
        .container{width:90%;padding:20px;}
    }
</style>
</head>
<body>

<header>
    <h1><i class="fa-solid fa-user-pen"></i> Modifier un Administrateur</h1>
</header>

<div class="container">
    <a href="users.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Retour à la liste</a>

    <form method="POST">
        <label>Nom Complet :</label>
        <input type="text" name="nom_complet" value="<?= htmlspecialchars($admin['nom_complet']); ?>" required>

        <label>Téléphone :</label>
        <input type="text" name="telephone" value="<?= htmlspecialchars($admin['telephone']); ?>" required>

        <label>Email :</label>
        <input type="email" name="email" value="<?= htmlspecialchars($admin['email']); ?>" required>

        <label>Poste :</label>
        <input type="text" name="poste" value="<?= htmlspecialchars($admin['poste']); ?>" required>

        <label>Statut :</label>
        <select name="statut" required>
            <option value="actif" <?= $admin['statut'] === 'actif' ? 'selected' : ''; ?>>Actif</option>
            <option value="inactif" <?= $admin['statut'] === 'inactif' ? 'selected' : ''; ?>>Inactif</option>
        </select>

        <label>Mot de passe actuel (haché) :</label>
        <div class="password-box"><?= htmlspecialchars($admin['mot_de_passe']); ?></div>

        <label>Nouveau mot de passe (laisser vide pour ne pas changer) :</label>
        <input type="password" name="mot_de_passe" placeholder="Entrer un nouveau mot de passe">

        <button type="submit" name="update"><i class="fa-solid fa-save"></i> Mettre à jour</button>
    </form>
</div>

</body>
</html>
