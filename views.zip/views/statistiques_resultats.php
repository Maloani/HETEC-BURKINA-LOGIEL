<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once '../models/config.php';

// === Vérification session (admin uniquement) ===
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

// === Total étudiants cotés ===
$totalEtudiantsStmt = $pdo->query("SELECT COUNT(DISTINCT matricule_etudiant) FROM cotes");
$totalEtudiants = $totalEtudiantsStmt->fetchColumn();

// === Moyenne générale = moyenne des moyennes des étudiants ===
$moyenneGeneraleStmt = $pdo->query("
    SELECT ROUND(AVG(moyenne_etudiant),2) AS moyenne_generale FROM (
        SELECT matricule_etudiant,
               ROUND(AVG(((note_td/10*20)*0.3 + (note_tp/10*20)*0.2 + (note_examen)*0.5)),2) AS moyenne_etudiant
        FROM cotes
        WHERE note_td IS NOT NULL AND note_tp IS NOT NULL AND note_examen IS NOT NULL
        GROUP BY matricule_etudiant
    ) AS moyennes
");
$moyenneGenerale = $moyenneGeneraleStmt->fetchColumn();

// === Mentions globales ===
$mentions = [
    'Excellent' => [18, 20],
    'Très bien' => [16, 17.99],
    'Bien' => [14, 15.99],
    'Assez bien' => [12, 13.99],
    'Passable' => [10, 11.99],
    'Insuffisant' => [8, 9.99],
    'Faible' => [0, 7.99]
];
$mentionStats = [];
foreach ($mentions as $mention => $interval) {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM (
            SELECT matricule_etudiant,
                   ROUND(AVG(((note_td/10*20)*0.3 + (note_tp/10*20)*0.2 + note_examen*0.5)),2) AS moyenne
            FROM cotes
            WHERE note_td IS NOT NULL AND note_tp IS NOT NULL AND note_examen IS NOT NULL
            GROUP BY matricule_etudiant
        ) AS m
        WHERE m.moyenne BETWEEN :min AND :max
    ");
    $stmt->execute([':min' => $interval[0], ':max' => $interval[1]]);
    $mentionStats[$mention] = $stmt->fetchColumn();
}

// === Statistiques par filière ===
$filiereStatsStmt = $pdo->query("
  SELECT f.designation_filiere, COUNT(DISTINCT i.matricule_etudiant) AS nb_etudiants,
         ROUND(AVG(((c.note_td/10*20)*0.3 + (c.note_tp/10*20)*0.2 + (c.note_examen)*0.5)),2) AS moyenne_filiere
  FROM inscriptions i
  JOIN cotes c ON i.matricule_etudiant = c.matricule_etudiant
  JOIN options o ON i.id_option = o.id_option
  JOIN filieres f ON o.id_filiere = f.id_filiere
  WHERE i.statut_inscription = 'confirmée'
  GROUP BY f.id_filiere
  ORDER BY f.designation_filiere ASC
");
$filiereStats = $filiereStatsStmt->fetchAll(PDO::FETCH_ASSOC);

// === Top 5 meilleurs étudiants par filière ===
$topEtudiantsStmt = $pdo->query("
  SELECT 
    f.designation_filiere,
    i.nom_etudiant,
    i.prenom_etudiant,
    ROUND(AVG(((c.note_td/10*20)*0.3 + (c.note_tp/10*20)*0.2 + (c.note_examen)*0.5)),2) AS moyenne
  FROM inscriptions i
  JOIN cotes c ON i.matricule_etudiant = c.matricule_etudiant
  JOIN options o ON i.id_option = o.id_option
  JOIN filieres f ON o.id_filiere = f.id_filiere
  WHERE i.statut_inscription = 'confirmée'
  GROUP BY f.id_filiere, i.matricule_etudiant
  HAVING moyenne IS NOT NULL
  ORDER BY f.designation_filiere, moyenne DESC
");
$tops = $topEtudiantsStmt->fetchAll(PDO::FETCH_ASSOC);

// === Regrouper les top 5 par filière ===
$topParFiliere = [];
foreach ($tops as $row) {
    $filiere = $row['designation_filiere'];
    if (!isset($topParFiliere[$filiere])) $topParFiliere[$filiere] = [];
    if (count($topParFiliere[$filiere]) < 5) {
        $m = $row['moyenne'];
        if ($m < 8) $mention = "Faible";
        elseif ($m < 10) $mention = "Insuffisant";
        elseif ($m < 12) $mention = "Passable";
        elseif ($m < 14) $mention = "Assez bien";
        elseif ($m < 16) $mention = "Bien";
        elseif ($m < 18) $mention = "Très bien";
        else $mention = "Excellent";

        $topParFiliere[$filiere][] = [
            'nom' => $row['nom_etudiant'].' '.$row['prenom_etudiant'],
            'moyenne' => $row['moyenne'],
            'mention' => $mention
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Statistiques des Résultats - HETEC Burkina Faso</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
body {
  font-family: Arial, sans-serif;
  background: #f7f7f9;
  margin: 0;
  padding: 0;
}
.container {
  max-width: 1200px;
  margin: 30px auto;
  background: #fff;
  border-radius: 10px;
  padding: 20px 30px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.08);
}
h1 {
  text-align: center;
  color: #0b3b6a;
  margin-bottom: 25px;
}
.top-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}
.top-bar a {
  background: #884ea0;
  color: #fff;
  text-decoration: none;
  padding: 8px 16px;
  border-radius: 6px;
  font-weight: bold;
  font-size: 14px;
}
.top-bar a:hover { background: #6d397e; }
.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 15px;
  margin-bottom: 25px;
}
.card {
  background: #f4f7fb;
  border: 1px solid #ddd;
  border-radius: 10px;
  padding: 18px;
  text-align: center;
}
.card h2 {
  color: #0b3b6a;
  margin: 0;
  font-size: 1.2rem;
}
.card p { margin: 6px 0 0; font-weight: bold; color: #333; }

table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 15px;
  margin-bottom: 25px;
}
th, td {
  border: 1px solid #ddd;
  padding: 10px;
  text-align: center;
}
th {
  background: #0b3b6a;
  color: #fff;
}
tr:nth-child(even) { background: #f5f5f5; }

.filiere-block {
  margin-bottom: 35px;
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 10px 15px;
  background: #fdfdfd;
}
.filiere-block h3 {
  color: #884ea0;
  border-bottom: 2px solid #884ea0;
  padding-bottom: 6px;
}
.footer {
  text-align: center;
  color: #777;
  font-size: 13px;
  padding-top: 10px;
  border-top: 1px solid #ddd;
  margin-top: 20px;
}
</style>
</head>
<body>
<div class="container">
  <div class="top-bar">
    <a href="admin_dashboard.php"><i class="fa-solid fa-arrow-left"></i> Retour au tableau de bord</a>
    <h1><i class="fa-solid fa-chart-line"></i> Statistiques des Résultats</h1>
  </div>

  <div class="stats-grid">
    <div class="card"><h2><i class="fa-solid fa-users"></i> Étudiants cotés</h2><p><?= $totalEtudiants ?></p></div>
    <div class="card"><h2><i class="fa-solid fa-chart-column"></i> Moyenne générale</h2><p><?= $moyenneGenerale ?>/20</p></div>
    <?php foreach ($mentionStats as $mention => $nb): ?>
      <div class="card">
        <h2><?= $mention ?></h2>
        <p><?= $nb ?> étudiant(s)</p>
      </div>
    <?php endforeach; ?>
  </div>

  <h2 style="color:#0b3b6a; text-align:center;">📘 Statistiques par Filière</h2>
  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Filière</th>
        <th>Étudiants</th>
        <th>Moyenne Filière</th>
      </tr>
    </thead>
    <tbody>
      <?php
      if (empty($filiereStats)) {
          echo "<tr><td colspan='4'>Aucune donnée disponible</td></tr>";
      } else {
          $i = 1;
          foreach ($filiereStats as $f) {
              echo "<tr>
                      <td>{$i}</td>
                      <td>{$f['designation_filiere']}</td>
                      <td>{$f['nb_etudiants']}</td>
                      <td>{$f['moyenne_filiere']}</td>
                    </tr>";
              $i++;
          }
      }
      ?>
    </tbody>
  </table>

  <h2 style="color:#0b3b6a; text-align:center;">🏅 Top 5 Meilleurs Étudiants par Filière</h2>
  <?php foreach ($topParFiliere as $filiere => $etuds): ?>
  <div class="filiere-block">
    <h3><?= htmlspecialchars($filiere) ?></h3>
    <table>
      <thead>
        <tr>
          <th>Rang</th>
          <th>Nom complet</th>
          <th>Moyenne /20</th>
          <th>Mention</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $r = 1;
        foreach ($etuds as $e) {
            echo "<tr>
                    <td>{$r}</td>
                    <td>".htmlspecialchars($e['nom'])."</td>
                    <td>{$e['moyenne']}</td>
                    <td>{$e['mention']}</td>
                  </tr>";
            $r++;
        }
        ?>
      </tbody>
    </table>
  </div>
  <?php endforeach; ?>

  <div class="footer">
    © <?= date('Y') ?> HETEC Burkina Faso – Plateforme Académique Numérique |
    Développé par <strong>MS Solutions Lab</strong>
  </div>
</div>
</body>
</html>
