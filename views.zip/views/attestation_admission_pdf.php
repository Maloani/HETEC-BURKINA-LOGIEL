<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../models/config.php';
require_once __DIR__ . '/fpdf/fpdf.php';
require_once __DIR__ . '/phpqrcode/qrlib.php';

// === Fonction de normalisation ===
function normalize_text($text) {
    $text = str_replace(
        ["’", "‘", "‛", "‚", "´", "`", "“", "”", "„"],
        ["'", "'", "'", "'", "'", "'", '"', '"', '"'],
        $text
    );
    return utf8_decode($text);
}

if (!isset($_GET['id'])) die('Aucun ID fourni.');
$id = (int)$_GET['id'];

// === Récupération des données étudiant ===
$stmt = $pdo->prepare("
    SELECT i.*, o.designation_option, f.designation_filiere
    FROM inscriptions i
    LEFT JOIN options o ON i.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    WHERE i.id_inscription = :id
");
$stmt->execute([':id' => $id]);
$etudiant = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$etudiant) die('Étudiant introuvable.');

// === Calcul de la moyenne générale ===
$stmtMoy = $pdo->prepare("
    SELECT AVG(
        ((IFNULL(c.note_td,0)/10*20)*0.3 + (IFNULL(c.note_tp,0)/10*20)*0.2 + IFNULL(c.note_examen,0)*0.5)
    ) AS moyenne_generale
    FROM cotes c
    JOIN cours cr ON c.id_cours = cr.id_cours
    WHERE c.matricule_etudiant = :mat
");
$stmtMoy->execute([':mat' => $etudiant['matricule_etudiant']]);
$moyenne_generale = round($stmtMoy->fetchColumn(), 2);

// === Détermination de la mention ===
$mention = "";
if ($moyenne_generale >= 18) $mention = "Excellent";
elseif ($moyenne_generale >= 16) $mention = "Très Bien";
elseif ($moyenne_generale >= 14) $mention = "Bien";
elseif ($moyenne_generale >= 12) $mention = "Assez Bien";
elseif ($moyenne_generale >= 10) $mention = "Passable";
elseif ($moyenne_generale >= 8)  $mention = "Insuffisant";
else $mention = "Faible";

// === QR Code enrichi ===
$verificationUrl = "https://osseboa.com/hetec_administration/views/attestation_admission_pdf.php?id=" . $etudiant['id_inscription'];

$qrText = 
    "Université : HETEC Burkina Faso\n" .
    "Nom : " . strtoupper($etudiant['nom_etudiant']) . " " . ucfirst($etudiant['prenom_etudiant']) . "\n" .
    "Matricule : " . strtoupper($etudiant['matricule_etudiant']) . "\n" .
    "Filière : " . strtoupper($etudiant['designation_filiere']) . "\n" .
    "Option : " . strtoupper($etudiant['designation_option']) . "\n" .
    "Moyenne générale : " . $moyenne_generale . "/20\n" .
    "Mention : " . strtoupper($mention) . "\n\n" .
    "🔗 Vérifier l’authenticité : " . $verificationUrl;

$qrDir = __DIR__ . "/qrcodes/";
if (!is_dir($qrDir)) mkdir($qrDir);
$qrFile = $qrDir . "qr_" . $etudiant['id_inscription'] . ".png";
QRcode::png($qrText, $qrFile, QR_ECLEVEL_Q, 4);

// === Classe PDF ===
class PDF extends FPDF {
    function Header() {
        $this->SetLineWidth(2);
        $this->SetDrawColor(128, 0, 32); // Bordeaux
        $this->Rect(5, 5, 200, 287);
        $this->SetDrawColor(100, 100, 100); // Gris
        $this->Rect(8, 8, 194, 281);

        // Logo
        $this->Image('../img/hetec.png', 90, 10, 30);
        $this->Ln(22);

        // En-tête
        $this->SetFont('Arial', 'B', 13);
        $this->Cell(0, 6, normalize_text("GROUPE ÉCOLES D’INGÉNIEURS"), 0, 1, 'C');
        $this->SetFont('Arial', 'B', 11);
        $this->Cell(0, 6, normalize_text("ÉCOLE SUPÉRIEURE DES HAUTES ÉTUDES TECHNOLOGIQUES ET COMMERCIALES (HETEC)"), 0, 1, 'C');
        $this->SetFont('Arial', '', 10);
        $this->Cell(0, 6, normalize_text("Ministère de l’Enseignement Supérieur, de la Recherche et de l’Innovation (MESRI)"), 0, 1, 'C');
        $this->Cell(0, 6, normalize_text("Diplômes reconnus par le CAMES - Membre de l’AACSB"), 0, 1, 'C');
        $this->Ln(12);
    }
}

$pdf = new PDF('P', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetMargins(20, 20, 20);
$pdf->SetAutoPageBreak(false);

// === Titre principal ===
$pdf->SetFillColor(128, 0, 32);
$pdf->SetTextColor(255, 255, 255);
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 12, normalize_text("ATTESTATION D’ADMISSION"), 1, 1, 'C', true);
$pdf->Ln(10);

// === Corps du texte ===
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('Times', '', 13);
$pdf->MultiCell(0, 6, normalize_text("POUR SERVIR ET VALOIR CE QUE DE DROIT,"));
$pdf->Ln(3);
$pdf->MultiCell(0, 8, normalize_text("Nous, Direction Générale du Groupe HETEC (École Supérieure des Hautes Études Technologiques et Commerciales),"));
$pdf->MultiCell(0, 8, normalize_text("Vu le protocole d’accord de partenariat du 17 octobre 2023 entre HETEC ABIDJAN et HETEC OUAGADOUGOU,"));
$pdf->MultiCell(0, 8, normalize_text("Vu le rapport du jury interne d’évaluation des étudiants de fin de cycle,"));
$pdf->MultiCell(0, 8, normalize_text("Vu le Procès-Verbal de soutenance du " . date("d/m/Y") . ","));
$pdf->MultiCell(0, 8, normalize_text("attestons que :"));
$pdf->Ln(6);

// === Bloc nom étudiant ===
$pdf->SetFont('Times', 'B', 14);
$pdf->SetFillColor(240, 240, 240);
$pdf->Cell(0, 10, normalize_text(strtoupper($etudiant['nom_etudiant']) . " " . ucfirst($etudiant['prenom_etudiant'])), 1, 1, 'C', true);
$pdf->Ln(6);

// === Date de naissance formatée ===
$date_naissance = "";
if (!empty($etudiant['date_naissance']) && $etudiant['date_naissance'] != "0000-00-00") {
    $date_naissance = date("d/m/Y", strtotime($etudiant['date_naissance']));
}

// === Informations académiques ===
$pdf->SetFont('Times', '', 13);
$pdf->MultiCell(0, 8, normalize_text("Né(e) le " . $date_naissance . " à " . strtoupper($etudiant['lieu_naissance']) . "."));
$pdf->MultiCell(0, 8, normalize_text("a subi avec succès les épreuves de soutenance de la Licence Professionnelle en " . strtoupper($etudiant['designation_filiere']) . "."));
$pdf->MultiCell(0, 8, normalize_text("MENTION : " . strtoupper($mention)));
$pdf->MultiCell(0, 8, normalize_text("Moyenne générale : " . $moyenne_generale . "/20"));
$pdf->MultiCell(0, 8, normalize_text("Au titre de l’année académique " . $etudiant['annee_academique'] . "."));
$pdf->Ln(6);



// === Bas de page ===
$yBase = 230;

// Date et signature
$pdf->SetXY(120, $yBase - 6);
$pdf->SetFont('Times', 'I', 12);
$pdf->Cell(70, 8, normalize_text("Fait à Ouagadougou, le " . date("d/m/Y")), 0, 2, 'C');

$pdf->SetXY(120, $yBase + 5);
$pdf->SetFont('Arial', 'B', 13);
$pdf->Cell(70, 8, normalize_text("DIRECTEUR DÉLÉGUÉ"), 0, 2, 'C');

// Cachet et signature
$pdf->Image('../img/cachet.JPG', 135, $yBase + 13, 32);
$pdf->Image('../img/signature.JPG', 165, $yBase + 13, 32);

// QR Code
$pdf->Image($qrFile, 25, $yBase, 35, 35);

// Ligne dorée et note bas de page
$pdf->SetY(277);
$pdf->SetDrawColor(197, 138, 0);
$pdf->SetLineWidth(0.5);
$pdf->Line(20, 277, 190, 277);

$pdf->SetY(278);
$pdf->SetFont('Arial', 'I', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(0, 6, normalize_text("NB : La présente attestation n’a pas valeur de diplôme définitif. Le parchemin définitif sera délivré à l’intéressé(e) dès qu’il sera disponible."), 0, 'C');

// Sortie PDF
$filename = "Attestation_Admission_" . strtoupper($etudiant['nom_etudiant']) . "_" . ucfirst($etudiant['prenom_etudiant']) . ".pdf";
$pdf->Output('I', $filename);
?>
