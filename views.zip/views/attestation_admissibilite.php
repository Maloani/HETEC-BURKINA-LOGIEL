<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.html");
    exit();
}

require_once '../config/db.php';

// ✅ Message de succès après réinitialisation
$resetSuccess = isset($_GET['reset']) && $_GET['reset'] === 'success';

// === Si c’est une requête AJAX (recherche ou filtrage dynamique) ===
if (isset($_GET['ajax'])) {
    $id_option = isset($_GET['id_option']) ? (int)$_GET['id_option'] : 0;
    $search_nom = isset($_GET['search_nom']) ? trim($_GET['search_nom']) : "";
    $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $limit = 10;
    $offset = ($page - 1) * $limit;

    $sql = "
        SELECT i.*, o.designation_option, f.designation_filiere
        FROM inscriptions i
        LEFT JOIN options o ON i.id_option = o.id_option
        LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
        WHERE i.statut_inscription = 'confirmée'
    ";
    $params = [];

    if ($id_option > 0) {
        $sql .= " AND o.id_option = :id_option";
        $params[':id_option'] = $id_option;
    }
    if (!empty($search_nom)) {
        $sql .= " AND (i.nom_etudiant LIKE :search OR i.prenom_etudiant LIKE :search)";
        $params[':search'] = "%$search_nom%";
    }

    $countSql = preg_replace('/SELECT(.*?)FROM/', 'SELECT COUNT(*) AS total FROM', $sql, 1);
    $countStmt = $db->prepare($countSql);
    $countStmt->execute($params);
    $total = $countStmt->fetchColumn();
    $totalPages = ceil($total / $limit);

    $sql .= " ORDER BY f.designation_filiere, o.designation_option, i.nom_etudiant LIMIT :limit OFFSET :offset";
    $stmt = $db->prepare($sql);
    foreach ($params as $key => $val) {
        $stmt->bindValue($key, $val);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $inscriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // === Génération directe du tableau ===
    ob_start();
    if (empty($inscriptions)) {
        echo "<p style='text-align:center;color:#888;'>Aucun étudiant trouvé.</p>";
    } else {
        echo "<p style='font-weight:bold;margin-bottom:10px;'>👩‍🎓 Total étudiants confirmés : " . count($inscriptions) . "</p>";
        echo "<table>
        <tr>
            <th>Photo</th>
            <th>Matricule</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Téléphone</th>
            <th>Mot de passe</th>
            <th>Sexe</th>
            <th>Filière</th>
            <th>Option</th>
            <th>Année</th>
            <th>Statut</th>
            <th>Attestation</th>
        </tr>";
        foreach ($inscriptions as $i) {
            echo "<tr>
                <td>";
            if (!empty($i['photo_etudiant'])) {
                echo "<img src='../uploads/" . htmlspecialchars($i['photo_etudiant']) . "' class='photo-thumb'>";
            } else {
                echo "<i class='fa fa-user-circle' style='font-size:40px;color:#bbb;'></i>";
            }
            echo "</td>
                <td>" . htmlspecialchars($i['matricule_etudiant']) . "</td>
                <td>" . htmlspecialchars($i['nom_etudiant']) . "</td>
                <td>" . htmlspecialchars($i['prenom_etudiant']) . "</td>
                <td>" . htmlspecialchars($i['telephone']) . "</td>
                <td>" . htmlspecialchars($i['mot_de_passe']) . "</td>
                <td>" . htmlspecialchars($i['sexe']) . "</td>
                <td>" . htmlspecialchars($i['designation_filiere']) . "</td>
                <td>" . htmlspecialchars($i['designation_option']) . "</td>
                <td>" . htmlspecialchars($i['annee_academique']) . "</td>
                <td><span class='status confirmée'>Confirmée</span></td>";

            // ✅ Attestation imprimée ou non
            if (!empty($i['carte_imprimee']) && $i['carte_imprimee'] == 1) {
                echo "<td>
                    <span style='color:green;font-weight:bold;'>🟢 Déjà imprimée</span>
                    <a href='reset_impression.php?id=" . $i['id_inscription'] . "' 
                       onclick=\"return confirm('Voulez-vous réinitialiser ce statut ?');\"
                       style='color:#b00;font-size:0.8rem;text-decoration:none;margin-left:5px;'>
                       ↺ Réinitialiser
                    </a>
                </td>";
            } else {
                echo "<td>
                    <a href='attestation_admissibilite_pdf.php?id=" . $i['id_inscription'] . "' class='btn' target='_blank'>
                        📄 Imprimer attestation
                    </a>
                </td>";
            }

            echo "</tr>";
        }
        echo "</table>";

        echo "<div class='pagination'>";
        if ($page > 1) {
            echo "<a href='#' data-page='" . ($page-1) . "'><i class='fa fa-arrow-left'></i> Précédent</a>";
        }
        echo "<span>Page $page / $totalPages</span>";
        if ($page < $totalPages) {
            echo "<a href='#' data-page='" . ($page+1) . "'>Suivant <i class='fa fa-arrow-right'></i></a>";
        }
        echo "</div>";
    }
    echo ob_get_clean();
    exit;
}

// === RÉCUPÉRATION OPTIONS ===
$options = $db->query("
    SELECT o.id_option, o.designation_option, f.designation_filiere
    FROM options o
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    ORDER BY f.designation_filiere, o.designation_option
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Attestations d’inscription – HETEC</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
body {
  font-family: 'Segoe UI', sans-serif;
  background: #f6f8fc;
  margin: 0;
  padding: 0;
}
header {
  background: linear-gradient(90deg, #0b3b6a, #c58a00);
  color: white;
  text-align: center;
  padding: 1rem;
}
.container {
  width: 95%;
  max-width: 1200px;
  margin: 25px auto;
  background: white;
  border-radius: 10px;
  padding: 25px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

/* Message de succès */
.alert-success {
  background: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
  border-radius: 5px;
  padding: 10px 15px;
  margin: 15px auto;
  width: 90%;
  text-align: center;
  font-weight: bold;
}

/* FILTRE */
.filter-bar {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  align-items: center;
  margin-bottom: 15px;
}
.filter-bar select, .filter-bar input {
  padding: 8px;
  border-radius: 6px;
  border: 1px solid #ccc;
  flex: 1;
}
.filter-bar input {
  min-width: 220px;
}
button {
  background: #0b3b6a;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 8px 15px;
  cursor: pointer;
  font-weight: bold;
}
button:hover {
  background: #084070;
}

/* Bouton Retour */
.back-btn {
  background: #c58a00;
  color: white;
  border: none;
  border-radius: 6px;
  padding: 8px 14px;
  font-weight: bold;
  cursor: pointer;
  transition: 0.3s;
}
.back-btn:hover {
  background: #b67d00;
}

/* TABLEAU */
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 10px;
}
th {
  background: #0b3b6a;
  color: #fff;
  padding: 10px;
  text-align: left;
}
td {
  padding: 8px;
  border-bottom: 1px solid #eee;
}
.photo-thumb {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  object-fit: cover;
  border: 1px solid #ccc;
}
.status {
  font-weight: bold;
  padding: 5px 10px;
  border-radius: 20px;
}
.status.confirmée {
  background: #d4edda;
  color: #155724;
}

/* Bouton imprimer */
.btn {
  background: #0b3b6a;
  color: white;
  padding: 6px 10px;
  border-radius: 6px;
  text-decoration: none;
  font-size: 0.9rem;
}
.btn:hover {
  background: #084070;
}

/* Pagination */
.pagination {
  text-align: center;
  margin-top: 20px;
}
.pagination a {
  display: inline-block;
  margin: 0 4px;
  padding: 8px 12px;
  border-radius: 6px;
  border: 1px solid #ccc;
  text-decoration: none;
  color: #007bff;
}
.pagination a.active {
  background: #007bff;
  color: white;
  font-weight: bold;
}
.pagination a:hover {
  background: #0056b3;
  color: white;
}

/* Loader */
.loader {
  display: none;
  text-align: center;
  margin: 20px;
}
.loader i {
  font-size: 28px;
  color: #0b3b6a;
  animation: spin 1s linear infinite;
}
@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
</style>
</head>

<body>
<header>
  <h1><i class="fa fa-file-alt"></i> Liste des étudiants pour les Attestations d’admissibilité</h1>
</header>

<?php if ($resetSuccess): ?>
  <div class="alert-success">✅ Réinitialisation effectuée avec succès.</div>
<?php endif; ?>

<div class="container">
  <div class="filter-bar">
    <label for="id_option"><strong>Option – Filière :</strong></label>
    <select name="id_option" id="id_option" onchange="loadStudents()">
      <option value="0">-- Toutes les options --</option>
      <?php foreach ($options as $opt): ?>
        <option value="<?= $opt['id_option'] ?>">
          <?= htmlspecialchars($opt['designation_option'] . " – " . $opt['designation_filiere']) ?>
        </option>
      <?php endforeach; ?>
    </select>

    <button class="back-btn" onclick="window.location.href='doc_administratifs.php'">⬅️ Retour</button>

    <label for="search_nom"><strong>Recherche par nom :</strong></label>
    <input type="text" id="search_nom" placeholder="Saisir le nom ou prénom..." onkeyup="loadStudents()">

    <button type="button" onclick="resetFilters()" style="background:#6c757d;">
      <i class="fa fa-sync"></i> Réinitialiser
    </button>
  </div>

  <div class="loader" id="loader"><i class="fa fa-spinner"></i> Chargement...</div>
  <div id="tableContainer"></div>
</div>

<script>
function loadStudents(page = 1) {
  const option = document.getElementById('id_option').value;
  const nom = document.getElementById('search_nom').value;
  const url = `attestation_admissibilite.php?ajax=1&id_option=${option}&search_nom=${encodeURIComponent(nom)}&page=${page}`;
  
  document.getElementById('loader').style.display = 'block';
  
  fetch(url)
    .then(res => res.text())
    .then(html => {
      document.getElementById('loader').style.display = 'none';
      document.getElementById('tableContainer').innerHTML = html;
      document.querySelectorAll('.pagination a').forEach(a => {
        a.addEventListener('click', e => {
          e.preventDefault();
          const newPage = a.getAttribute('data-page');
          loadStudents(newPage);
        });
      });
    })
    .catch(() => {
      document.getElementById('loader').style.display = 'none';
      document.getElementById('tableContainer').innerHTML = "<p style='color:red;text-align:center;'>Erreur de chargement</p>";
    });
}

function resetFilters() {
  document.getElementById('id_option').value = 0;
  document.getElementById('search_nom').value = "";
  loadStudents(1);
}

window.onload = () => loadStudents();
</script>
</body>
</html>
