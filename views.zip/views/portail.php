<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Connexion Étudiant – HETEC Burkina Faso</title>
  <link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
  <style>
    :root {
      --primary: #0b3b6a;
      --secondary: #c58a00;
      --bg: linear-gradient(135deg, rgba(11,59,106,0.95), rgba(197,138,0,0.85));
      --input-bg: #f4f7fb;
    }

    body {
      margin: 0;
      font-family: "Segoe UI", sans-serif;
      background: var(--bg);
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      color: #fff;
    }

    /* === Boîte principale === */
    .login-box {
      background: #fff;
      color: #222;
      max-width: 420px;
      width: 100%;
      padding: 2.8rem 2rem;
      border-radius: 1rem;
      box-shadow: 0 10px 30px rgba(0,0,0,0.25);
      animation: fadeIn 0.6s ease;
    }

    @keyframes fadeIn {
      from {opacity: 0; transform: translateY(30px);}
      to {opacity: 1; transform: translateY(0);}
    }

    /* === En-tête === */
    .login-header {
      text-align: center;
      margin-bottom: 1.5rem;
    }

    .login-header img {
      width: 90px;
      height: 90px;
      object-fit: cover;
      border-radius: 50%;
      background: #fff;
      box-shadow: 0 0 10px rgba(11,59,106,0.3);
      margin-bottom: 10px;
    }

    .login-header h2 {
      color: var(--primary);
      font-size: 1.5rem;
      margin-bottom: 0.3rem;
      font-weight: 700;
    }

    .login-header p {
      color: #666;
      font-size: 0.9rem;
      margin: 0;
    }

    /* === Champs === */
    .input-group {
      margin-bottom: 1.2rem;
      width: 100%;
    }

    label {
      font-weight: 600;
      color: var(--primary);
      margin-bottom: 0.3rem;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .input-group input {
      width: 100%;
      padding: 0.8rem 0.9rem;
      border-radius: 8px;
      border: 1.5px solid #ccc;
      background: var(--input-bg);
      font-size: 1rem;
      transition: all 0.3s ease;
      box-sizing: border-box;
    }

    .input-group input:focus {
      border-color: var(--primary);
      box-shadow: 0 0 6px rgba(11,59,106,0.25);
      outline: none;
    }

    /* === Mot de passe === */
    .password-wrapper {
      position: relative;
      display: flex;
      align-items: center;
      width: 100%;
    }

    .password-wrapper input {
      width: 100%;
      padding-right: 2.5rem;
      box-sizing: border-box;
    }

    .toggle-password {
      position: absolute;
      right: 10px;
      top: 50%;
      transform: translateY(-50%);
      cursor: pointer;
      color: #888;
      transition: color 0.3s;
    }

    .toggle-password:hover {
      color: var(--primary);
    }

    /* === Boutons === */
    .btn-login {
      width: 100%;
      background: linear-gradient(90deg, var(--primary), var(--secondary));
      color: white;
      border: none;
      padding: 0.9rem;
      border-radius: 8px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: 0.25s;
    }

    .btn-login:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 15px rgba(11,59,106,0.25);
    }

    .btn-login i {
      margin-right: 8px;
    }

    .btn-back {
      width: 100%;
      background: #f3f3f3;
      color: var(--primary);
      border: none;
      padding: 0.8rem;
      border-radius: 8px;
      font-size: 0.95rem;
      font-weight: 600;
      cursor: pointer;
      margin-top: 10px;
      transition: 0.25s;
    }

    .btn-back:hover {
      background: #e0e0e0;
      transform: translateY(-2px);
    }

    /* === Mot de passe oublié === */
    .forgot {
      text-align: center;
      margin-top: 1rem;
    }

    .forgot a {
      color: var(--primary);
      text-decoration: none;
      font-weight: 600;
    }

    .forgot a:hover {
      color: var(--secondary);
      text-decoration: underline;
    }

    .forgot-info {
      display: none;
      text-align: center;
      margin-top: 1rem;
      color: var(--primary);
      font-weight: 600;
    }

    /* === Message connexion === */
    #loginMessage {
      text-align: center;
      margin-top: 1rem;
      font-weight: 600;
    }

    /* === Responsive === */
    @media (max-width: 600px) {
      .login-box {
        width: 90%;
        padding: 2rem;
      }

      .login-header h2 {
        font-size: 1.25rem;
      }
    }
  </style>
</head>

<body>
  <div class="login-box">
    <div class="login-header">
      <img src="../img/loginStudent.jpeg" alt="Icône Étudiant" />
      <h2><i class="fa-solid fa-user-graduate"></i> Connexion Étudiant</h2>
      <p>Accédez à votre espace personnel HETEC</p>
    </div>

    <form id="loginForm">
      <div class="input-group">
        <label for="matricule"><i class="fa-solid fa-id-card"></i> Matricule</label>
        <input type="text" id="matricule" name="matricule" placeholder="Ex : HETEC2025-1234" required>
      </div>

      <div class="input-group">
        <label for="mot_de_passe"><i class="fa-solid fa-lock"></i> Mot de passe</label>
        <div class="password-wrapper">
          <input type="password" id="mot_de_passe" name="mot_de_passe" placeholder="********" required>
          <i class="fa-solid fa-eye toggle-password" id="togglePassword"></i>
        </div>
      </div>

      <button type="submit" class="btn-login">
        <i class="fa-solid fa-right-to-bracket"></i> Se connecter
      </button>

      <button type="button" class="btn-back" onclick="window.location.href='../index.php'">
        <i class="fa-solid fa-arrow-left"></i> Retour à l’accueil
      </button>

      <p class="forgot">
        <a href="#" onclick="showForgotInfo()">Mot de passe oublié ?</a>
      </p>
      <div class="forgot-info" id="forgotInfo">
        <p>Contactez-nous à l'adresse email suivante : <a href="mailto:georgesmaloanis@gmail.com">georgesmaloanis@gmail.com</a></p>
        <p>Ou contactez-nous par WhatsApp : <br>
        <a href="tel:+243826704930">+243 826 704 930</a> ou <a href="tel:+243971312601">+243 971 312 601</a></p>
      </div>

      <p id="loginMessage"></p>
    </form>
  </div>

  <script>
    const toggle = document.getElementById("togglePassword");
    const pass = document.getElementById("mot_de_passe");
    const msg = document.getElementById("loginMessage");
    const form = document.getElementById("loginForm");

    toggle.addEventListener("click", () => {
      const visible = pass.type === "text";
      pass.type = visible ? "password" : "text";
      toggle.classList.toggle("fa-eye");
      toggle.classList.toggle("fa-eye-slash");
    });

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      msg.textContent = "⏳ Connexion en cours...";
      msg.style.color = "#0b3b6a";

      const data = new FormData(form);
      try {
        const response = await fetch("../etudiant_login.php", {
          method: "POST",
          body: data
        });
        const result = await response.json();

        if (result.status === "success") {
          msg.textContent = "✅ Connexion réussie ! Redirection...";
          msg.style.color = "green";
          setTimeout(() => {
            window.location.href = "etudiant_dashboard.php";
          }, 1000);
        } else {
          msg.textContent = result.message;
          msg.style.color = "red";
        }
      } catch (error) {
        msg.textContent = "⚠️ Erreur de connexion au serveur.";
        msg.style.color = "red";
      }
    });

    function showForgotInfo() {
      const forgotInfo = document.getElementById("forgotInfo");
      forgotInfo.style.display = forgotInfo.style.display === "none" || forgotInfo.style.display === "" ? "block" : "none";
    }
  </script>
</body>
</html>
