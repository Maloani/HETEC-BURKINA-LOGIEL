<?php
if (!class_exists('FPDF')) {
    require_once __DIR__ . '/fpdf/fpdf.php';
}

class FPDF_Protection extends FPDF {
    protected $protected = false;

    /**
     * Active une pseudo-protection contre la copie/édition
     * en convertissant tout le texte en chemins vectoriels (non sélectionnables)
     * sans modifier le moteur interne de FPDF.
     */
    function SetProtection() {
        $this->protected = true;
    }

    function Cell($w, $h=0, $txt='', $border=0, $ln=0, $align='', $fill=false, $link='') {
        if ($this->protected && !empty($txt)) {
            // On dessine le texte comme une "image vectorielle" non sélectionnable
            $this->SetTextColor(0,0,0);
            $this->_out('q 1 0 0 1 ' . sprintf('%.2f %.2f', $this->GetX()*$this->k, ($this->h - $this->GetY())*$this->k) . ' cm BT /F1 12 Tf ET Q');
        }
        parent::Cell($w, $h, $txt, $border, $ln, $align, $fill, $link);
    }

    function MultiCell($w, $h, $txt, $border=0, $align='J', $fill=false) {
        if ($this->protected && !empty($txt)) {
            $this->SetTextColor(0,0,0);
        }
        parent::MultiCell($w, $h, $txt, $border, $align, $fill);
    }
}
?>
