<?php 
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../models/config.php';
require_once __DIR__ . '/fpdf/fpdf.php';
require_once __DIR__ . '/phpqrcode/qrlib.php';

if (!isset($_GET['id'])) die('Aucun ID fourni.');
$id = (int)$_GET['id'];

// === Données étudiant ===
$stmt = $pdo->prepare("
    SELECT i.*, o.designation_option, f.designation_filiere
    FROM inscriptions i
    LEFT JOIN options o ON i.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    WHERE i.id_inscription = :id
");
$stmt->execute([':id' => $id]);
$etudiant = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$etudiant) die('Étudiant introuvable.');

// ✅ Marquer la carte comme imprimée
$update = $pdo->prepare("UPDATE inscriptions SET carte_imprimee = 1 WHERE id_inscription = :id");
$update->execute([':id' => $id]);

// === Lien de vérification dynamique ===
$verificationUrl = "https://osseboa.com/hetec_administration/views/imprimer_carte.php?id=" . $etudiant['id_inscription'];

// === QR code temporaire ===
$qrcodePath = __DIR__ . "/qrcodes/";
if (!is_dir($qrcodePath)) mkdir($qrcodePath);
$fileQR = $qrcodePath . $etudiant['matricule_etudiant'] . ".png";

// 🔹 Contenu enrichi du QR Code (avec lien de vérification)
$qrText = 
    "🎓 HETEC BURKINA FASO\n" .
    "Nom : " . strtoupper($etudiant['nom_etudiant']) . " " . ucfirst($etudiant['prenom_etudiant']) . "\n" .
    "Matricule : " . strtoupper($etudiant['matricule_etudiant']) . "\n" .
    "Filière : " . strtoupper($etudiant['designation_filiere']) . "\n" .
    "Option : " . strtoupper($etudiant['designation_option']) . "\n\n" .
    "🔗 Vérifier la carte : " . $verificationUrl;

// Génération du QR
QRcode::png($qrText, $fileQR, QR_ECLEVEL_Q, 4);

// === FORMAT ÉTENDU (125x75 mm) ===
$pdf = new FPDF('L', 'mm', [125, 75]);
$pdf->SetAutoPageBreak(false);

/* -------------------- RECTO -------------------- */
$pdf->AddPage();
$pdf->SetFillColor(255,255,255);
$pdf->Rect(0,0,125,75,'F');

// Bande bleue
$pdf->SetFillColor(11,59,106);
$pdf->Rect(0,0,125,12,'F');

// Logo
$pdf->Image('../img/hetec.png',5,2,22);

// Titre principal
$pdf->SetTextColor(255,255,255);
$pdf->SetFont('Arial','B',9);
$pdf->SetXY(30,3.5);
$pdf->Cell(80,4,utf8_decode("ÉCOLE SUPÉRIEURE DES HAUTES ÉTUDES"),0,1,'L');
$pdf->SetXY(30,7);
$pdf->Cell(80,4,utf8_decode("TECHNOLOGIQUES ET COMMERCIALES (HETEC)"),0,1,'L');

// Bande rouge CARTE ÉTUDIANT
$pdf->SetFillColor(224,27,36);
$pdf->Rect(35,14,55,7,'F');
$pdf->SetTextColor(255,255,255);
$pdf->SetFont('Arial','B',10);
$pdf->SetXY(35,14.5);
$pdf->Cell(55,6,utf8_decode("CARTE ÉTUDIANT ".$etudiant['annee_academique']),0,1,'C');

// Photo + cadre bleu
$pdf->SetDrawColor(11,59,106);
$pdf->Rect(8,22,32,38);
if (!empty($etudiant['photo_etudiant']) && file_exists("../uploads/".$etudiant['photo_etudiant'])) {
    $pdf->Image("../uploads/".$etudiant['photo_etudiant'],8.8,22.8,30.4,36);
}

// Matricule sous photo
$pdf->SetFillColor(224,27,36);
$pdf->Rect(8,60,32,7,'F');
$pdf->SetTextColor(255,255,255);
$pdf->SetFont('Arial','B',8);
$pdf->SetXY(8,61);
$pdf->Cell(32,5,utf8_decode("MATRICULE : ".$etudiant['matricule_etudiant']),0,0,'C');

// Infos étudiant
$startX = 46;
$pdf->SetTextColor(0,0,0);
$pdf->SetXY($startX,23);
$pdf->SetFont('Arial','B',6);
$pdf->Cell(38,6,utf8_decode("NOM :"),0,0);
$pdf->Cell(0,6,utf8_decode(strtoupper($etudiant['nom_etudiant'])),0,1);

$pdf->SetX($startX);
$pdf->Cell(38,6,utf8_decode("PRÉNOM(S) :"),0,0);
$pdf->Cell(0,6,utf8_decode(ucfirst($etudiant['prenom_etudiant'])),0,1);

$pdf->SetX($startX);
$pdf->Cell(38,6,utf8_decode("DATE DE NAISSANCE :"),0,0);
$pdf->Cell(0,6,utf8_decode($etudiant['date_naissance']),0,1);

$pdf->SetX($startX);
$pdf->Cell(38,6,utf8_decode("LIEU DE NAISSANCE :"),0,0);
$pdf->Cell(0,6,utf8_decode(strtoupper($etudiant['lieu_naissance'])),0,1);

$pdf->SetX($startX);
$pdf->Cell(38,6,utf8_decode("NIVEAU :"),0,0);
$pdf->Cell(0,6,utf8_decode(strtoupper($etudiant['designation_option'])),0,1);

$pdf->SetX($startX);
$pdf->Cell(38,6,utf8_decode("FILIÈRE :"),0,0);
$pdf->Cell(0,6,utf8_decode(strtoupper($etudiant['designation_filiere'])),0,1);

// Espace avant le Directeur Délégué
$pdf->Ln(13);
$pdf->SetXY(85,57);
$pdf->SetFont('Arial','I',9);
$pdf->Cell(30,5,utf8_decode("Le Directeur Délégué"),0,1,'C');

// Cachet et signature (mêmes positions)
$pdf->Image('../img/cachet.JPG', 90, 63, 10);
$pdf->Image('../img/signature.JPG', 102, 63, 10);

// Nom Directeur
$pdf->SetXY(85,69);
$pdf->SetFont('Arial','',9);
$pdf->Cell(30,4,utf8_decode("Hermann OCHOU"),0,1,'C');

// Bande bleue bas
$pdf->SetFillColor(11,59,106);
$pdf->Rect(0,70,75,5,'F');
$pdf->SetTextColor(255,255,255);
$pdf->SetFont('Arial','',7);
$pdf->SetXY(2,71);
$pdf->Cell(70,3,utf8_decode("(226) 56 15 00 00 / 63 42 99 99   scolarite@hetecburkina.net"),0,0,'L');

/* -------------------- VERSO -------------------- */
$pdf->AddPage();
$pdf->SetFillColor(255,255,255);
$pdf->Rect(0,0,125,75,'F');

// Bande bleue (haut)
$pdf->SetFillColor(11,59,106);
$pdf->Rect(0,0,125,6,'F');

// Logo centré
$pdf->Image('../img/hetec.png',47,6,32);

// Espace sous le logo
$pdf->Ln(22);

// Texte "HETEC OUAGA"
$pdf->SetTextColor(11,59,106);
$pdf->SetFont('Arial','B',10);
$pdf->SetXY(0,30);
$pdf->Cell(125,6,utf8_decode("HETEC OUAGA"),0,1,'C');

// QR code à gauche (version enrichie)
$pdf->Image($fileQR,10,34,18,18);

// Icônes + Infos contact
$iconX = 35;
$textX = 42;

$pdf->Image('../img/web.png', $iconX, 49, 4);
$pdf->SetXY($textX, 49);
$pdf->SetFont('Arial','',8);
$pdf->Cell(80,5,utf8_decode("www.hetecburkina.com"),0,1,'L');

$pdf->Image('../img/map.jpeg', $iconX, 54, 4);
$pdf->SetXY($textX, 54);
$pdf->SetFont('Arial','',8);
$pdf->Cell(80,5,utf8_decode("scolarite@hetecburkina.net"),0,1,'L');

$pdf->SetXY($textX, 59);
$pdf->Cell(80,5,utf8_decode("(+226) 56 15 00 00 / 63 42 99 99"),0,1,'L');
$pdf->SetFont('Arial','I',7.5);
$pdf->SetXY($textX, 64);
$pdf->MultiCell(80,4,utf8_decode("Ouagadougou, Secteur 24, Rue de la Jeunesse (Zad)"),0,'L');

// Bande bleue bas + message
$pdf->SetFillColor(11,59,106);
$pdf->Rect(0,69,125,6,'F');
$pdf->SetTextColor(255,215,0);
$pdf->SetFont('Arial','I',7.5);
$pdf->SetXY(5,70.5);
$pdf->Cell(115,4,utf8_decode("Les autorités civiles tant militaires sont priées d'apporter assistance au porteur de la présente."),0,1,'C');

// Nettoyage QR
unlink($fileQR);

// Sortie PDF
$pdf->Output('I', 'Carte_'.$etudiant['matricule_etudiant'].'.pdf');
exit;
?>
