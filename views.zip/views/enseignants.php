<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

require_once '../config/db.php';

// === Ajout d’un enseignant ===
if (isset($_POST['add'])) {
    $nom_complet = trim($_POST['nom_complet']);
    $sexe = trim($_POST['sexe']);
    $niveau_etude = trim($_POST['niveau_etude']);
    $mail_enseignant = trim($_POST['mail_enseignant']);
    $telephone = trim($_POST['telephone']);
    $mot_de_passe = trim($_POST['mot_de_passe']); // <-- PAS DE HASH ICI
    $statut = trim($_POST['statut']);
    $date_creation = date('Y-m-d H:i:s');

    if (!empty($nom_complet) && !empty($telephone) && !empty($mot_de_passe)) {
        try {
            // Vérifier doublons en tenant compte de l'email facultatif
            $checkQuery = "SELECT COUNT(*) FROM enseignants WHERE telephone = :tel";
            
            // Si l'email est fourni, on l'ajoute dans la requête
            if (!empty($mail_enseignant)) {
                $checkQuery .= " OR mail_enseignant = :email";
            }

            $check = $db->prepare($checkQuery);
            $params = [':tel' => $telephone];
            
            // Ajouter l'email dans les paramètres si l'email est renseigné
            if (!empty($mail_enseignant)) {
                $params[':email'] = $mail_enseignant;
            }

            $check->execute($params);
            
            if ($check->fetchColumn() > 0) {
                $message = "<p class='error'>⚠️ Cet enseignant existe déjà (email ou téléphone).</p>";
            } else {
                $stmt = $db->prepare("INSERT INTO enseignants (nom_complet, sexe, niveau_etude, mail_enseignant, telephone, mot_de_passe, statut, date_creation)
                                      VALUES (:nom_complet, :sexe, :niveau_etude, :mail_enseignant, :telephone, :mot_de_passe, :statut, :date_creation)");
                $stmt->execute([ 
                    ':nom_complet' => $nom_complet, 
                    ':sexe' => $sexe, 
                    ':niveau_etude' => $niveau_etude, 
                    ':mail_enseignant' => $mail_enseignant, 
                    ':telephone' => $telephone, 
                    ':mot_de_passe' => $mot_de_passe, // enregistré en clair
                    ':statut' => $statut, 
                    ':date_creation' => $date_creation 
                ]);
                $message = "<p class='success' id='msg'>✅ Enseignant ajouté avec succès !</p>";
            }
        } catch (PDOException $e) {
            $message = "<p class='error'>Erreur : " . $e->getMessage() . "</p>";
        }
    }
}

// === Suppression ===
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $stmt = $db->prepare("DELETE FROM enseignants WHERE id_enseignant = :id");
        $stmt->execute([':id' => $id]);
        $message = "<p class='success' id='msg'>🗑️ Enseignant supprimé avec succès.</p>";
    } catch (PDOException $e) {
        $message = "<p class='error'>Erreur : " . $e->getMessage() . "</p>";
    }
}

// === Statistiques globales ===
$total = $db->query("SELECT COUNT(*) FROM enseignants")->fetchColumn();
$total_hommes = $db->query("SELECT COUNT(*) FROM enseignants WHERE sexe = 'Homme'")->fetchColumn();
$total_femmes = $db->query("SELECT COUNT(*) FROM enseignants WHERE sexe = 'Femme'")->fetchColumn();

$lic = $db->query("SELECT COUNT(*) FROM enseignants WHERE niveau_etude = 'Licencié'")->fetchColumn();
$master = $db->query("SELECT COUNT(*) FROM enseignants WHERE niveau_etude = 'Master'")->fetchColumn();
$doc = $db->query("SELECT COUNT(*) FROM enseignants WHERE niveau_etude = 'Docteur'")->fetchColumn();
$prof = $db->query("SELECT COUNT(*) FROM enseignants WHERE niveau_etude = 'Professeur'")->fetchColumn();

// === Pagination ===
$limit = 5;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

$totalRows = $total;
$totalPages = ceil($totalRows / $limit);

// === Récupération ===
$stmt = $db->prepare("SELECT * FROM enseignants ORDER BY nom_complet ASC LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$enseignants = $stmt->fetchAll();

$start = $totalRows > 0 ? $offset + 1 : 0;
$end = min($offset + $limit, $totalRows);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gestion des Enseignants</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp"> <!-- Icône du logo HETEC -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
body{font-family:'Segoe UI',sans-serif;background:#f4f7fb;margin:0;padding:0;}
header{background:linear-gradient(90deg,#0b3b6a,#c58a00);color:#fff;text-align:center;padding:1rem;}
.container{width:90%;max-width:1100px;margin:30px auto;background:#fff;padding:25px;border-radius:10px;box-shadow:0 3px 10px rgba(0,0,0,0.1);}
.stats-box{background:#e9f4ff;border-left:5px solid #0b3b6a;padding:15px;margin-bottom:20px;border-radius:8px;}
.stats-box p{margin:5px 0;font-size:0.95rem;}
.stats-box strong{color:#0b3b6a;}
form{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;}
form input,form select{flex:1;padding:10px;border:1px solid #ccc;border-radius:6px;font-size:1rem;}
form button{background:#007bff;color:white;border:none;padding:10px 15px;border-radius:6px;cursor:pointer;}
form button:hover{background:#0056b3;}
.btn{background:#28a745;color:#fff;padding:10px 15px;border-radius:6px;text-decoration:none;}
.btn:hover{background:#218838;}
.error,.success{text-align:center;font-weight:bold;margin:10px 0;}
.success{color:green;}
.error{color:red;}
table{width:100%;border-collapse:collapse;margin-top:20px;}
th{background:#0b3b6a;color:white;padding:12px;text-align:left;}
td{padding:10px;border-bottom:1px solid #ddd;}
tr:hover{background:#f8f9fa;}
.action-btn{border:none;padding:7px 10px;border-radius:5px;cursor:pointer;color:white;}
.edit-btn{background:#007bff;}
.edit-btn:hover{background:#0056b3;}
.delete-btn{background:#dc3545;}
.delete-btn:hover{background:#b52a36;}
.pagination{text-align:center;margin-top:25px;}
.pagination a{color:#007bff;text-decoration:none;padding:8px 14px;border:1px solid #ccc;border-radius:5px;margin:0 3px;}
.pagination a.active{background:#007bff;color:white;}
@media(max-width:768px){form{flex-direction:column;}}
</style>
</head>
<body>

<header>
  <h1><i class="fa-solid fa-chalkboard-user"></i> Gestion des Enseignants</h1>
</header>

<div class="container">
<?= $message ?? '' ?>

<!-- ✅ Statistiques globales -->
<div class="stats-box">
  <p><strong>Vous avez <?= $total ?> enseignant(s)</strong></p>
  <p>👨 Hommes : <strong><?= $total_hommes ?></strong> &nbsp; | &nbsp; 👩 Femmes : <strong><?= $total_femmes ?></strong></p>
  <p>🎓 Licenciés : <strong><?= $lic ?></strong> &nbsp; | &nbsp; 🎓 Masters : <strong><?= $master ?></strong> &nbsp; | &nbsp; 🧑‍🎓 Docteurs : <strong><?= $doc ?></strong> &nbsp; | &nbsp; 👨‍🏫 Professeurs : <strong><?= $prof ?></strong></p>
</div>

<a href="admin_dashboard.php" class="btn"><i class="fa-solid fa-home"></i> Accueil</a></br>  </br>

<!-- ✅ Formulaire d'ajout -->
<form method="POST" action="enseignants.php">
  <input type="text" name="nom_complet" placeholder="Nom complet" required>
  <select name="sexe" required>
    <option value="">Sexe</option>
    <option value="Homme">Homme</option>
    <option value="Femme">Femme</option>
  </select>
  <select name="niveau_etude" required>
    <option value="">Niveau d'étude</option>
    <option value="Licencié">Licencié</option>
    <option value="Master">Master</option>
    <option value="Docteur">Docteur</option>
    <option value="Professeur">Professeur</option>
  </select>
  <input type="email" name="mail_enseignant" placeholder="Email (facultatif)">
  <input type="text" name="telephone" placeholder="Téléphone" required>
  <input type="text" name="mot_de_passe" placeholder="Mot de passe" required>
  <select name="statut" required>
    <option value="">Statut</option>
    <option value="Actif">Actif</option>
    <option value="Inactif">Inactif</option>
  </select>
  <button type="submit" name="add"><i class="fa-solid fa-plus"></i> Ajouter</button>
</form>

<!-- ✅ Tableau -->
<input type="text" id="searchInput" placeholder="🔍 Rechercher un enseignant..." style="width:100%;padding:10px;border:1px solid #ccc;border-radius:6px;">

<p style="text-align:right;font-style:italic;color:#555;">Affichage de <?= $start ?> à <?= $end ?> sur <?= $totalRows ?> enseignants</p>

<table id="enseignantTable">
<thead>
<tr>
  <th>Nom complet</th>
  <th>Sexe</th>
  <th>Niveau d'étude</th>
  <th>Email</th>
  <th>Téléphone</th>
  <th>Mot de passe</th>
  <th>Statut</th>
  <th>Actions</th>
</tr>
</thead>
<tbody>
<?php foreach ($enseignants as $ens): ?>
<tr>
  <td><?= htmlspecialchars($ens['nom_complet']); ?></td>
  <td><?= htmlspecialchars($ens['sexe']); ?></td>
  <td><?= htmlspecialchars($ens['niveau_etude']); ?></td>
  <td><?= htmlspecialchars($ens['mail_enseignant']); ?></td>
  <td><?= htmlspecialchars($ens['telephone']); ?></td>
  <td><?= htmlspecialchars($ens['mot_de_passe']); ?></td>
  <td><?= htmlspecialchars($ens['statut']); ?></td>
  <td>
    <a href="modifier_enseignant.php?id=<?= $ens['id_enseignant']; ?>">
      <button class="action-btn edit-btn"><i class="fa-solid fa-pen-to-square"></i></button>
    </a>
    <a href="enseignants.php?delete=<?= $ens['id_enseignant']; ?>" onclick="return confirm('Supprimer cet enseignant ?')">
      <button class="action-btn delete-btn"><i class="fa-solid fa-trash"></i></button>
    </a>
  </td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

<div class="pagination">
<?php if ($page > 1): ?>
  <a href="?page=<?= $page - 1; ?>">« Précédent</a>
<?php endif; ?>
<?php for ($i = 1; $i <= $totalPages; $i++): ?>
  <a href="?page=<?= $i; ?>" class="<?= $i == $page ? 'active' : ''; ?>"><?= $i; ?></a>
<?php endfor; ?>
<?php if ($page < $totalPages): ?>
  <a href="?page=<?= $page + 1; ?>">Suivant »</a>
<?php endif; ?>
</div>
</div>

<script>
document.getElementById("searchInput").addEventListener("keyup", function(){
  let filter = this.value.toUpperCase();
  let rows = document.querySelector("#enseignantTable tbody").rows;
  for (let i = 0; i < rows.length; i++) {
    let name = rows[i].cells[0].textContent.toUpperCase();
    rows[i].style.display = name.indexOf(filter) > -1 ? "" : "none";
  }
});
setTimeout(() => {let msg=document.getElementById('msg');if(msg) msg.style.display='none';}, 5000);
</script>
</body>
</html>
