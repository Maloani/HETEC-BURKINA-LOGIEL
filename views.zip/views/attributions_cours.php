<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once '../models/config.php';

// --- Pagination des enseignants ---
$limit = 10;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

// --- Total enseignants ---
$totalStmt = $pdo->query("SELECT COUNT(*) FROM enseignants");
$total = $totalStmt->fetchColumn();
$totalPages = ceil($total / $limit);

// --- Récupération des enseignants ---
$stmt = $pdo->prepare("SELECT * FROM enseignants ORDER BY nom_complet ASC LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$enseignants = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Attributions des Cours – HETEC</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    body {
      font-family: "Segoe UI", sans-serif;
      background: #f5f7fa;
      margin: 0;
      padding: 20px;
    }
    h1 {
      text-align: center;
      color: #0b3b6a;
    }
    .top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 15px;
    }
    .back-btn {
      background: #c58a00;
      color: #fff;
      border: none;
      border-radius: 5px;
      padding: 8px 14px;
      font-weight: bold;
      cursor: pointer;
      transition: 0.3s;
    }
    .back-btn:hover {
      background: #0b3b6a;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      background: #fff;
      margin-top: 10px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    th, td {
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    th {
      background: #0b3b6a;
      color: white;
    }
    tr:hover {
      background: #f1f1f1;
    }
    button {
      background: #c58a00;
      color: white;
      border: none;
      padding: 6px 12px;
      border-radius: 5px;
      cursor: pointer;
      transition: 0.3s;
    }
    button:hover {
      background: #0b3b6a;
    }
    .pagination {
      text-align: center;
      margin-top: 20px;
    }
    .pagination a {
      display: inline-block;
      margin: 0 5px;
      padding: 8px 14px;
      border: 1px solid #0b3b6a;
      border-radius: 6px;
      text-decoration: none;
      color: #0b3b6a;
      font-weight: bold;
    }
    .pagination a.active, .pagination a:hover {
      background: #0b3b6a;
      color: white;
    }

    /* === POPUP STYLE === */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0; top: 0;
      width: 100%; height: 100%;
      background: rgba(0,0,0,0.6);
      justify-content: center;
      align-items: center;
    }
    .modal-content {
      background: #fff;
      padding: 20px;
      border-radius: 10px;
      width: 80%;
      max-width: 800px;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
      position: relative;
    }
    .close-btn {
      position: absolute;
      right: 10px;
      top: 10px;
      background: crimson;
      color: white;
      border: none;
      border-radius: 5px;
      padding: 5px 10px;
      cursor: pointer;
    }
    .modal-content h2 {
      text-align: center;
      color: #c58a00;
      margin-bottom: 10px;
    }
    #total-cours {
      text-align: center;
      font-weight: bold;
      color: #0b3b6a;
      margin-bottom: 10px;
    }
    #table-cours th {
      background: #0b3b6a;
      color: white;
    }
  </style>
</head>
<body>

  <div class="top-bar">
    <h1>Attributions des Cours par Enseignant</h1>
    <button class="back-btn" onclick="window.location.href='doc_administratifs.php'">⬅️ Retour</button>
  </div>

  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Nom complet</th>
        <th>Sexe</th>
        <th>Niveau d'étude</th>
        <th>Email</th>
        <th>Téléphone</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $n = $offset + 1;
      foreach ($enseignants as $ens): ?>
        <tr>
          <td><?= $n++; ?></td>
          <td><?= htmlspecialchars($ens['nom_complet']); ?></td>
          <td><?= htmlspecialchars($ens['sexe']); ?></td>
          <td><?= htmlspecialchars($ens['niveau_etude']); ?></td>
          <td><?= htmlspecialchars($ens['mail_enseignant']); ?></td>
          <td><?= htmlspecialchars($ens['telephone']); ?></td>
          <td>
            <button onclick="voirCours(<?= $ens['id_enseignant']; ?>, '<?= addslashes($ens['nom_complet']); ?>')">
              <i class="fa-solid fa-book-open"></i> Voir ses cours
            </button>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <div class="pagination">
    <?php if ($page > 1): ?>
      <a href="?page=<?= $page - 1; ?>">⬅️ Précédent</a>
    <?php endif; ?>
    <span>Page <?= $page; ?> / <?= $totalPages; ?></span>
    <?php if ($page < $totalPages): ?>
      <a href="?page=<?= $page + 1; ?>">Suivant ➡️</a>
    <?php endif; ?>
  </div>

  <!-- === MODAL POPUP === -->
  <div class="modal" id="coursModal">
    <div class="modal-content">
      <button class="close-btn" onclick="fermerCours()">Fermer</button>
      <h2 id="titre-enseignant"></h2>
      <div id="total-cours"></div>
      <table id="table-cours" width="100%">
        <thead>
          <tr>
            <th>#</th>
            <th>Code</th>
            <th>Désignation</th>
            <th>Crédits</th>
            <th>Option</th>
            <th>Année académique</th>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
      <div id="cours-pagination" style="text-align:center;margin-top:15px;"></div>
    </div>
  </div>

  <script>
    function voirCours(idEns, nom, page = 1) {
      fetch(`fetch_cours.php?id=${idEns}&page=${page}`)
        .then(res => res.json())
        .then(data => {
          const tbody = document.querySelector('#table-cours tbody');
          tbody.innerHTML = '';
          document.getElementById('titre-enseignant').textContent = "Cours de " + nom;

          if (data.cours.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:gray;">Aucun cours attribué.</td></tr>';
            document.getElementById('total-cours').textContent = '';
          } else {
            data.cours.forEach((c, i) => {
              const tr = document.createElement('tr');
              tr.innerHTML = `
                <td>${(i + 1) + (data.page - 1) * 10}</td>
                <td>${c.code_cours}</td>
                <td>${c.designation_cours}</td>
                <td>${c.credits}</td>
                <td>${c.designation_option}</td>
                <td>${c.annee_academique}</td>
              `;
              tbody.appendChild(tr);
            });

            document.getElementById('total-cours').textContent =
              `Total : ${((data.totalPages - 1) * 10) + data.cours.length} cours attribués`;
          }

          // Pagination dynamique
          const paginationDiv = document.getElementById('cours-pagination');
          paginationDiv.innerHTML = '';
          if (data.totalPages > 1) {
            if (data.page > 1) {
              const prev = document.createElement('button');
              prev.textContent = '⬅️ Précédent';
              prev.style.marginRight = '10px';
              prev.onclick = () => voirCours(idEns, nom, data.page - 1);
              paginationDiv.appendChild(prev);
            }

            const span = document.createElement('span');
            span.textContent = `Page ${data.page} / ${data.totalPages}`;
            span.style.marginRight = '10px';
            paginationDiv.appendChild(span);

            if (data.page < data.totalPages) {
              const next = document.createElement('button');
              next.textContent = 'Suivant ➡️';
              next.onclick = () => voirCours(idEns, nom, data.page + 1);
              paginationDiv.appendChild(next);
            }
          }

          document.getElementById('coursModal').style.display = 'flex';
        })
        .catch(err => alert("Erreur : " + err));
    }

    function fermerCours() {
      document.getElementById('coursModal').style.display = 'none';
    }

    window.onclick = function(event) {
      const modal = document.getElementById('coursModal');
      if (event.target === modal) modal.style.display = "none";
    };
  </script>

</body>
</html>
