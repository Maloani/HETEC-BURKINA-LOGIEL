<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

require_once '../models/config.php';

// 🔐 Vérification de la session
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'enseignant') {
    header("Location: ../login.php");
    exit();
}

$id_enseignant = $_SESSION['user_id'];
$nom_enseignant = $_SESSION['nom'];

// 🔎 Récupération des informations de l’enseignant connecté
$sql = "SELECT * FROM enseignants WHERE id_enseignant = :id";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':id', $id_enseignant, PDO::PARAM_INT);
$stmt->execute();
$enseignant = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$enseignant) {
    die("Profil introuvable pour cet enseignant.");
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mon Profil – HETEC Burkina Faso</title>
  <link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

  <style>
    :root {
      --primary: #0B3B6A;
      --secondary: #C58A00;
      --bg1: #e0f7fa;
      --bg2: #fce4ec;
      --bg3: #f3e5f5;
      --bg4: #e8f5e9;
    }

    body {
      margin: 0;
      font-family: "Segoe UI", sans-serif;
      color: #222;
      display: flex;
      min-height: 100vh;
      background: linear-gradient(135deg, var(--bg1), var(--bg2), var(--bg3), var(--bg4));
      background-size: 400% 400%;
      animation: gradientShift 15s ease infinite;
    }

    @keyframes gradientShift {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    /* === Sidebar === */
    .sidebar {
      width: 230px;
      background: linear-gradient(180deg, var(--primary), #082f55);
      color: white;
      height: 100vh;
      position: fixed;
      left: 0;
      top: 0;
      padding-top: 20px;
      display: flex;
      flex-direction: column;
      box-shadow: 2px 0 6px rgba(0,0,0,0.2);
    }
    .sidebar .logo {
      text-align: center;
      margin-bottom: 25px;
    }
    .sidebar .logo img {
      width: 60px;
      border-radius: 50%;
    }
    .sidebar .logo h2 {
      margin: 10px 0 0;
      font-size: 1.1rem;
      color: var(--secondary);
    }
    .sidebar .menu {
      display: flex;
      flex-direction: column;
    }
    .sidebar .menu a {
      display: flex;
      align-items: center;
      color: white;
      text-decoration: none;
      padding: 12px 20px;
      gap: 12px;
      transition: 0.3s;
      border-left: 4px solid transparent;
    }
    .sidebar .menu a:hover, .sidebar .menu a.active {
      background: var(--secondary);
      border-left: 4px solid #fff;
    }

    /* === Main === */
    .main {
      margin-left: 230px;
      flex: 1;
      padding: 25px;
    }
    header {
      background: linear-gradient(90deg, var(--primary), var(--secondary));
      color: #fff;
      padding: 15px;
      border-radius: 8px;
      text-align: center;
      margin-bottom: 20px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.2);
    }

    /* === Carte du profil avec bordure lumineuse === */
    .profile-card {
      position: relative;
      background: #fff;
      border-radius: 12px;
      padding: 25px;
      max-width: 700px;
      margin: 50px auto;
      box-shadow: 0 0 20px rgba(0,0,0,0.15);
      overflow: hidden;
    }

    .profile-card::before {
      content: "";
      position: absolute;
      inset: -2px;
      background: linear-gradient(45deg, #0B3B6A, #C58A00, #00BFA5, #FFD700, #0B3B6A);
      background-size: 400%;
      border-radius: 14px;
      z-index: -1;
      animation: borderGlow 6s linear infinite;
    }

    @keyframes borderGlow {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    .profile-header {
      display: flex;
      align-items: center;
      gap: 20px;
      border-bottom: 2px solid #eee;
      padding-bottom: 15px;
      margin-bottom: 20px;
    }

    .profile-header img {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      border: 3px solid var(--secondary);
      object-fit: cover;
      background: #fff;
    }

    .profile-header h2 {
      color: var(--primary);
      margin: 0;
    }

    .profile-details table {
      width: 100%;
      border-collapse: collapse;
    }

    .profile-details th, .profile-details td {
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #eee;
    }

    .profile-details th {
      width: 35%;
      color: var(--primary);
      font-weight: 600;
    }

    .logout-btn {
      background: #fff;
      color: var(--primary);
      border: none;
      border-radius: 6px;
      padding: 8px 14px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    .logout-btn:hover {
      background: #eee;
    }

    @media (max-width: 768px) {
      .sidebar { width: 60px; }
      .sidebar .logo h2, .sidebar .logo img, .sidebar .menu a span { display: none; }
      .main { margin-left: 60px; }
    }
  </style>

  <script>
    function logout(){
      if(confirm("Voulez-vous vous déconnecter ?")){
        window.location.href = "../logout.php";
      }
    }
  </script>
</head>

<body>

  <!-- ======== SIDEBAR ======== -->
  <aside class="sidebar">
    <div class="logo">
      <img src="../img/hetec.jpg-2.webp" alt="HETEC">
      <h2>HETEC</h2>
    </div>
    <nav class="menu">
      <a href="enseignant_dashboard.html"><i class="fa-solid fa-house"></i><span>Accueil</span></a>
      <a href="mes_cours.php"><i class="fa-solid fa-book"></i><span>Mes Cours</span></a>
      <a href="cotations.php"><i class="fa-solid fa-graduation-cap"></i><span>Attribuer les notes</span></a>
      <a href="communiques_ens.php"><i class="fa-solid fa-bullhorn"></i><span>Les communiqués</span></a>
      <a href="profil_ens.php" class="active"><i class="fa-solid fa-user"></i><span>Profil</span></a>
     
    </nav>
  </aside>

  <!-- ======== MAIN CONTENT ======== -->
  <div class="main">
    <header>
      <h1><i class="fa-solid fa-user"></i> Mon Profil</h1>
    </header>

    <div class="profile-card">
      <div class="profile-header">
        <img src="../img/hetec.jpg-2.webp" alt="Logo HETEC">
        <div>
          <h2><?= htmlspecialchars($enseignant['nom_complet']) ?></h2>
          <p><strong>Statut :</strong> <?= htmlspecialchars($enseignant['statut']) ?></p>
          <p><strong>Niveau d'étude :</strong> <?= htmlspecialchars($enseignant['niveau_etude']) ?></p>
        </div>
      </div>

      <div class="profile-details">
        <table>
          <tr><th>Nom complet</th><td><?= htmlspecialchars($enseignant['nom_complet']) ?></td></tr>
          <tr><th>Sexe</th><td><?= htmlspecialchars($enseignant['sexe']) ?></td></tr>
          <tr><th>Email</th><td><?= htmlspecialchars($enseignant['mail_enseignant'] ?? '—') ?></td></tr>
          <tr><th>Téléphone</th><td><?= htmlspecialchars($enseignant['telephone']) ?></td></tr>
          <tr><th>Mot de passe</th><td><code><?= htmlspecialchars($enseignant['mot_de_passe']) ?></code></td></tr>
          <tr><th>Niveau d'étude</th><td><?= htmlspecialchars($enseignant['niveau_etude']) ?></td></tr>
          <tr><th>Statut</th><td><?= htmlspecialchars($enseignant['statut']) ?></td></tr>
          <tr><th>Date d'inscription</th><td><?= htmlspecialchars($enseignant['date_creation']) ?></td></tr>
        </table>
      </div>
    </div>
  </div>

</body>
</html>
