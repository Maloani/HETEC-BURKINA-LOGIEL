<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../models/config.php';
require_once __DIR__ . '/fpdf/fpdf.php';
require_once __DIR__ . '/phpqrcode/qrlib.php'; // Librairie QRCode (assure-toi qu’elle existe)

if (!isset($_GET['option'])) {
    die("Option non spécifiée !");
}

$option = urldecode($_GET['option']);

// === Fonction pour normaliser les apostrophes et caractères spéciaux ===
function normalize_text($text) {
    $text = str_replace(
        ["’", "‘", "‛", "‚", "´", "`", "“", "”", "„"],
        ["'", "'", "'", "'", "'", "'", '"', '"', '"'],
        $text
    );
    return utf8_decode($text);
}

// === Récupération des informations ===
$stmt = $pdo->prepare("
    SELECT i.*, o.designation_option, f.designation_filiere
    FROM inscriptions i
    LEFT JOIN options o ON i.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    WHERE o.designation_option = :opt
    ORDER BY i.nom_etudiant
");
$stmt->execute([':opt' => $option]);
$etudiants = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$etudiants) {
    die("Aucun étudiant trouvé pour cette option.");
}

$filiere = $etudiants[0]['designation_filiere'];

// === Génération du fichier QR temporaire ===
$qrText = "HETEC - Liste des étudiants en $option ($filiere)\nGénéré le : " . date('d/m/Y');
$qrFile = __DIR__ . "/../uploads/qrcode_".md5($qrText).".png";
QRcode::png($qrText, $qrFile, QR_ECLEVEL_L, 3);

// === Génération du PDF ===
class PDF extends FPDF {
    function Header() {
        $this->Image('../img/hetec.png', 85, 8, 40);
        $this->Ln(30);

        $this->SetFont('Arial','B',10);
        $this->Cell(0,6,utf8_decode("Ministère de l'Enseignement Supérieur, de la Recherche et de l'Innovation (MESRI)"),0,1,'C');
        $this->Ln(1);
        $this->SetFont('Arial','B',12);
        $this->Cell(0,7,utf8_decode("ECOLE SUPERIEURE DES HAUTES ETUDES TECHNOLOGIQUES ET COMMERCIALES (HETEC)"),0,1,'C');
        $this->SetFont('Arial','',10);
        $this->Cell(0,6,utf8_decode("Diplomes reconnus par le CAMES - Membre de l'AACSB"),0,1,'C');
        $this->Ln(8);
        $this->Line(10, 48, 200, 48);
    }

    function Footer() {
        $this->SetY(-50);
        $this->SetDrawColor(11,59,106);
        $this->Line(10, $this->GetY(), 200, $this->GetY());
        $this->Ln(3);

        $this->SetFont('Arial','',8);
        $this->Cell(0,4,utf8_decode("Siege : Ouagadougou (Burkina Faso), Secteur 24, Rue de la Jeunesse (a la ZAD)"),0,1,'C');
        $this->Cell(0,4,utf8_decode("Tel : (+226) 56 15 00 00 / 63 42 99 99 / 69 36 03 36"),0,1,'C');
        $this->Cell(0,4,utf8_decode("Adresse : 11 BP 765 cms Ouaga 11 | Facebook : HETEC OUAGA | Site web : www.groupehetec.net"),0,1,'C');
        $this->Cell(0,4,utf8_decode("E-mail : scolarite@hetecburkina.net"),0,1,'C');
    }
}

$pdf = new PDF();
$pdf->AddPage();
$pdf->Ln(10);

// === Titre principal ===
$pdf->SetFont('Arial','B',12);
$pdf->Cell(0,10,normalize_text("LISTE DES ÉTUDIANTS EN ".$option."  ".$filiere),0,1,'C');
$pdf->Ln(5);

// === En-têtes de colonnes ===
$pdf->SetFont('Arial','B',10);
$pdf->SetFillColor(11,59,106);
$pdf->SetTextColor(255);

$header = ["Matricule","Nom","Prénom","Sexe","Naissance","Lieu","Téléphone","Photo"];
$widths = [20,28,28,15,25,25,25,20];
foreach ($header as $i => $col) {
    $pdf->Cell($widths[$i],8,normalize_text($col),1,0,'C',true);
}
$pdf->Ln();

$pdf->SetFont('Arial','',9);
$pdf->SetTextColor(0);

// === Données étudiants ===
foreach ($etudiants as $et) {
    $pdf->Cell($widths[0],20,normalize_text($et['matricule_etudiant']),1);
    $pdf->Cell($widths[1],20,normalize_text($et['nom_etudiant']),1);
    $pdf->Cell($widths[2],20,normalize_text($et['prenom_etudiant']),1);
    $pdf->Cell($widths[3],20,normalize_text($et['sexe']),1);
    $pdf->Cell($widths[4],20,$et['date_naissance'],1);
    $pdf->Cell($widths[5],20,normalize_text($et['lieu_naissance']),1);
    $pdf->Cell($widths[6],20,normalize_text($et['telephone']),1);

    // === Photo ===
    $photoPath = '../uploads/'.$et['photo_etudiant'];
    if (!empty($et['photo_etudiant']) && file_exists($photoPath)) {
        $x = $pdf->GetX();
        $y = $pdf->GetY();
        $pdf->Cell($widths[7],20,'',1,0,'C');
        $pdf->Image($photoPath, $x + 3, $y + 3, 14, 14);
        $pdf->Ln();
    } else {
        $pdf->Cell($widths[7],20,'-',1,1,'C');
    }
}

// === QR code (ajouté en bas à gauche du PDF) ===
$pdf->Ln(8);
$pdf->Image($qrFile, 15, $pdf->GetY() + 5, 25, 25); // position (X,Y) et taille

// === Signature ===
$pdf->SetY($pdf->GetY() + 10);
$pdf->SetFont('Arial','',11);
$pdf->Cell(0,8,normalize_text("Fait à Ouagadougou, le " . date('d/m/Y') . "."),0,1,'R');
$pdf->Ln(4);
$pdf->SetFont('Arial','B',11);
$pdf->Cell(0,8,normalize_text("LE DIRECTEUR DÉLÉGUÉ"),0,1,'R');
$pdf->Ln(10);

// === Génération du PDF ===
$pdf->Output("I", "Liste_etudiants_".$option."_".$filiere.".pdf");

// Supprime le QR temporaire après affichage
if (file_exists($qrFile)) {
    unlink($qrFile);
}

exit;
?>
