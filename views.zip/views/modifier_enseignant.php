<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.html");
    exit();
}

require_once '../config/db.php';

// Vérifier si un ID est passé
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("<p style='color:red; text-align:center;'>❌ Identifiant enseignant invalide.</p>");
}

$id = (int)$_GET['id'];

// === Charger les infos de l'enseignant ===
$stmt = $db->prepare("SELECT * FROM enseignants WHERE id_enseignant = :id");
$stmt->execute([':id' => $id]);
$enseignant = $stmt->fetch();

if (!$enseignant) {
    die("<p style='color:red; text-align:center;'>⚠️ Enseignant introuvable.</p>");
}

// === Mise à jour ===
if (isset($_POST['update'])) {
    $nom_complet = trim($_POST['nom_complet']);
    $sexe = trim($_POST['sexe']);
    $niveau_etude = trim($_POST['niveau_etude']);
    $mail_enseignant = trim($_POST['mail_enseignant']);
    $telephone = trim($_POST['telephone']);
    $statut = trim($_POST['statut']);
    $mot_de_passe = trim($_POST['mot_de_passe']);

    try {
        // Vérifier doublons email ou téléphone
        $check = $db->prepare("SELECT COUNT(*) FROM enseignants WHERE (mail_enseignant = :email OR telephone = :tel) AND id_enseignant != :id");
        $check->execute([':email' => $mail_enseignant, ':tel' => $telephone, ':id' => $id]);

        if ($check->fetchColumn() > 0) {
            $message = "<p class='error'>⚠️ Email ou téléphone déjà utilisé par un autre enseignant.</p>";
        } else {
           if (!empty($mot_de_passe)) {
    // Mise à jour AVEC mot de passe (NON haché)
    $sql = "UPDATE enseignants 
            SET nom_complet = :nom_complet, 
                sexe = :sexe, 
                niveau_etude = :niveau_etude, 
                mail_enseignant = :mail_enseignant, 
                telephone = :telephone, 
                statut = :statut, 
                mot_de_passe = :mot_de_passe 
            WHERE id_enseignant = :id";

    $params = [
        ':nom_complet' => $nom_complet,
        ':sexe' => $sexe,
        ':niveau_etude' => $niveau_etude,
        ':mail_enseignant' => $mail_enseignant,
        ':telephone' => $telephone,
        ':statut' => $statut,
        ':mot_de_passe' => $mot_de_passe, // mot de passe en clair
        ':id' => $id
    ];
} else {
    // Mise à jour SANS changer le mot de passe
    $sql = "UPDATE enseignants 
            SET nom_complet = :nom_complet, 
                sexe = :sexe, 
                niveau_etude = :niveau_etude, 
                mail_enseignant = :mail_enseignant, 
                telephone = :telephone, 
                statut = :statut 
            WHERE id_enseignant = :id";

    $params = [
        ':nom_complet' => $nom_complet,
        ':sexe' => $sexe,
        ':niveau_etude' => $niveau_etude,
        ':mail_enseignant' => $mail_enseignant,
        ':telephone' => $telephone,
        ':statut' => $statut,
        ':id' => $id
    ];
}


            $update = $db->prepare($sql);
            $update->execute($params);
            $message = "<p class='success'>✅ Informations mises à jour avec succès !</p>";

            // Recharger les nouvelles données
            $stmt = $db->prepare("SELECT * FROM enseignants WHERE id_enseignant = :id");
            $stmt->execute([':id' => $id]);
            $enseignant = $stmt->fetch();
        }
    } catch (PDOException $e) {
        $message = "<p class='error'>Erreur : " . $e->getMessage() . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Modifier un Enseignant</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp"> <!-- Ajout de l'icône dans l'onglet -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
body{
    font-family:'Segoe UI',sans-serif;
    background:#f4f7fb;
    margin:0;
    padding:0;
}
header{
    background:linear-gradient(90deg,#0b3b6a,#c58a00);
    color:#fff;
    text-align:center;
    padding:1rem;
}
.container{
    width:90%;
    max-width:700px;
    margin:30px auto;
    background:#fff;
    padding:25px;
    border-radius:10px;
    box-shadow:0 3px 10px rgba(0,0,0,0.1);
}
h2{text-align:center;color:#0b3b6a;}
form{
    display:flex;
    flex-direction:column;
    gap:15px;
}
input,select{
    padding:10px;
    border:1px solid #ccc;
    border-radius:6px;
    font-size:1rem;
}
button{
    padding:12px;
    border:none;
    border-radius:6px;
    cursor:pointer;
    font-size:1rem;
    color:white;
}
.update-btn{background:#007bff;}
.update-btn:hover{background:#0056b3;}
.back-btn{background:#28a745;text-decoration:none;text-align:center;display:block;}
.back-btn:hover{background:#218838;}
.error,.success{
    text-align:center;
    font-weight:bold;
}
.success{color:green;}
.error{color:red;}
</style>
</head>
<body>

<header>
  <h1><i class="fa-solid fa-user-pen"></i> Modifier un Enseignant</h1>
</header>

<div class="container">
<?= $message ?? '' ?>

<h2><?= htmlspecialchars($enseignant['nom_complet']); ?></h2>

<a href="enseignants.php" class="back-btn"><i class="fa-solid fa-arrow-left"></i> Retour à la liste</a>
<form method="POST">
    <input type="text" name="nom_complet" value="<?= htmlspecialchars($enseignant['nom_complet']); ?>" placeholder="Nom complet" required>

    <select name="sexe" required>
        <option value="Homme" <?= $enseignant['sexe'] == 'Homme' ? 'selected' : ''; ?>>Homme</option>
        <option value="Femme" <?= $enseignant['sexe'] == 'Femme' ? 'selected' : ''; ?>>Femme</option>
    </select>

    <select name="niveau_etude" required>
        <option value="Licencié" <?= $enseignant['niveau_etude'] == 'Licencié' ? 'selected' : ''; ?>>Licencié</option>
        <option value="Master" <?= $enseignant['niveau_etude'] == 'Master' ? 'selected' : ''; ?>>Master</option>
        <option value="Docteur" <?= $enseignant['niveau_etude'] == 'Docteur' ? 'selected' : ''; ?>>Docteur</option>
        <option value="Professeur" <?= $enseignant['niveau_etude'] == 'Professeur' ? 'selected' : ''; ?>>Professeur</option>
    </select>

    <input type="email" name="mail_enseignant" value="<?= htmlspecialchars($enseignant['mail_enseignant']); ?>" placeholder="Email" required>
    <input type="text" name="telephone" value="<?= htmlspecialchars($enseignant['telephone']); ?>" placeholder="Téléphone" required>

    <select name="statut" required>
        <option value="Actif" <?= $enseignant['statut'] == 'Actif' ? 'selected' : ''; ?>>Actif</option>
        <option value="Inactif" <?= $enseignant['statut'] == 'Inactif' ? 'selected' : ''; ?>>Inactif</option>
    </select>

    <input type="password" name="mot_de_passe" placeholder="Nouveau mot de passe (laisser vide si inchangé)">
    
    <button type="submit" name="update" class="update-btn"><i class="fa-solid fa-save"></i> Mettre à jour</button>
</form>


</div>

</body>
</html>
