<?php
// ✅ Sécurisation : accès réservé aux administrateurs
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Tableau de bord – Administration HETEC</title>
  <link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
  <style>
    body {
      font-family: "Segoe UI", sans-serif;
      background: #f6f8fc;
      color: #222;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      height: 100vh;
    }

    .container {
      display: flex;
      flex-grow: 1;
      overflow: hidden;
    }

    .sidebar {
      background: #0b3b6a;
      color: white;
      padding: 1rem;
      width: 250px;
      height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      position: fixed;
      transition: transform 0.3s ease;
      overflow-y: auto;
    }

    .sidebar img {
      width: 60%;
      margin-bottom: 20px;
      display: block;
      margin-left: auto;
      margin-right: auto;
    }

    .sidebar a {
      color: white;
      text-decoration: none;
      margin: 10px 0;
      display: flex;
      align-items: center;
      padding: 10px;
      width: 100%;
      border-radius: 6px;
      font-size: 1.1rem;
      transition: background 0.3s ease;
    }

    .sidebar a:hover {
      background: #1a467d;
    }

    .sidebar i {
      margin-right: 10px;
    }

    .main-content {
      margin-left: 250px;
      padding: 2rem;
      background: #f6f8fc;
      flex-grow: 1;
      overflow-y: auto;
      transition: margin-left 0.3s ease;
    }

    header {
      background: linear-gradient(90deg, #0b3b6a, #c58a00);
      color: white;
      padding: 1rem 2%;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    header h1 {
      font-size: 1.3rem;
      margin: 0;
    }

    .logout-btn {
      background: white;
      color: #0b3b6a;
      border: none;
      border-radius: 6px;
      padding: 0.5rem 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.3s ease, transform 0.2s ease-in-out;
    }

    .logout-btn:hover {
      background: #f0f0f0;
      transform: scale(1.05);
    }

    .card-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1rem;
      margin-top: 2rem;
      padding-bottom: 20px;
    }

    .card {
      background: white;
      padding: 1rem;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      text-align: center;
      cursor: pointer;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      min-height: 150px;
      text-decoration: none;
    }

    .card:hover {
      transform: translateY(-10px);
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
    }

    .card h2 {
      color: #0b3b6a;
      margin-bottom: 1rem;
    }

    .card i {
      font-size: 2rem;
      margin-bottom: 10px;
      color: #c58a00;
    }

    @media (max-width: 768px) {
      .sidebar {
        display: none;
      }

      .main-content {
        margin-left: 0;
      }

      .desktop-menu {
        display: none;
      }

      .mobile-menu {
        display: block;
        font-size: 1.3rem;
      }

      .menu-icon {
        display: block;
        cursor: pointer;
        font-size: 2rem;
      }

      .sidebar.active {
        display: flex;
      }
    }
  </style>
</head>

<body>
  <div class="container">
    <!-- ✅ MENU LATÉRAL -->
    <div class="sidebar" id="sidebar">
      <img src="../img/hetec.jpg-2.webp" alt="Logo HETEC" />
      <a href="users.php"><i class="fa fa-users"></i> Gestion des utilisateurs</a>
      <a href="filieres.php"><i class="fa fa-sitemap"></i> Filières</a>
      <a href="options.php"><i class="fa fa-cogs"></i> Options</a>
      <a href="enseignants.php"><i class="fa fa-chalkboard-teacher"></i> Enseignants</a>
      <a href="doc_administratifs.php"><i class="fa fa-file-alt"></i> Documents Académiques</a>
      <a href="inscriptions.php"><i class="fa fa-clipboard-list"></i> Inscriptions</a>
      <a href="ues.php"><i class="fa fa-book-open"></i> Gérer les UE</a>
      <a href="cours.php"><i class="fa fa-book"></i> Attributions Cours</a>
      <a href="statistiques_resultats.php"><i class="fa fa-check-circle"></i> Gestion des résultats</a>
      <a href="statistiques_etudiants.php"><i class="fa fa-chart-bar"></i> Statistiques des Étudiants</a>
      <a href="#"><i class="fa fa-chart-pie"></i> Rapports Financiers</a>
      <a href="notifications.php"><i class="fa fa-bell"></i> Notifications</a>
      <a href="parametres.php"><i class="fa fa-lock"></i> Sécurité & Paramètres</a>
    </div>

    <!-- ✅ CONTENU PRINCIPAL -->
    <div class="main-content">
     <header>
          <i class="fa-solid fa-bars menu-icon" onclick="toggleSidebar()"></i>
          <h1 class="desktop-menu"><i class="fa-solid fa-shield-halved"></i> Tableau de bord – Admin</h1>
          <h1 class="mobile-menu"><i class="fa-solid fa-shield-halved"></i> Menu</h1>
          <button class="logout-btn" onclick="window.location.href='../login.php'">
            <i class="fa-solid fa-right-from-bracket"></i> Déconnexion
          </button>
        </header>

      <main>
        <div class="card">
          <h2>Bienvenue, <span id="nomUtilisateur"><?= htmlspecialchars($_SESSION['nom'] ?? 'Administrateur') ?></span></h2>
          <p>Rôle : <strong>Administrateur</strong></p>
          <p>Vous êtes connecté à l’espace de gestion HETEC Burkina Faso.</p>
        </div>

        <div class="card-container">
          <div class="card" onclick="window.location.href='filieres.php'">
            <i class="fa fa-sitemap"></i>
            <h2>Filières</h2>
            <p>Gérez les différentes filières proposées dans l'établissement.</p>
          </div>

          <div class="card" onclick="window.location.href='users.php'">
            <i class="fa fa-users"></i>
            <h2>Utilisateurs</h2>
            <p>Ajoutez, modifiez ou supprimez des utilisateurs.</p>
          </div>

          <div class="card" onclick="window.location.href='options.php'">
            <i class="fa fa-cogs"></i>
            <h2>Options</h2>
            <p>Gérez les options disponibles pour les étudiants.</p>
          </div>

          <div class="card" onclick="window.location.href='enseignants.php'">
            <i class="fa fa-chalkboard-teacher"></i>
            <h2>Enseignants</h2>
            <p>Ajoutez, modifiez ou supprimez des enseignants.</p>
          </div>

          <div class="card" onclick="window.location.href='doc_administratifs.php'">
            <i class="fa fa-file-alt"></i>
            <h2>Documents Académiques</h2>
            <p>Gérez relevés de notes, attestations et autres documents.</p>
          </div>

          <div class="card" onclick="window.location.href='inscriptions.php'">
            <i class="fa fa-clipboard-list"></i>
            <h2>Inscriptions</h2>
            <p>Suivez et gérez les inscriptions des étudiants.</p>
          </div>

          <div class="card" onclick="window.location.href='ues.php'">
            <i class="fa fa-book-open"></i>
            <h2>Unités d’enseignement (UE)</h2>
            <p>Gérez les UE et attribuez-les aux enseignants.</p>
          </div>

          <div class="card" onclick="window.location.href='cours.php'">
            <i class="fa fa-book"></i>
            <h2>Attributions Cours</h2>
            <p>Assignez les cours aux enseignants et suivez leurs emplois du temps.</p>
          </div>

          <div class="card" onclick="window.location.href='statistiques_resultats.php'">
            <i class="fa fa-check-circle"></i>
            <h2>Résultats</h2>
            <p>Gérez les notes et classements des étudiants.</p>
          </div>

          <div class="card" onclick="window.location.href='statistiques_etudiants.php'">
            <i class="fa fa-chart-bar"></i>
            <h2>Statistiques</h2>
            <p>Visualisez les statistiques des étudiants avec des graphiques.</p>
          </div>

          <div class="card">
            <i class="fa fa-chart-pie"></i>
            <h2>Rapports Financiers</h2>
            <p>Consultez les rapports financiers du système.</p>
          </div>

          <div class="card" onclick="window.location.href='notifications.php'">
            <i class="fa fa-bell"></i>
            <h2>Notifications</h2>
            <p>Envoyez des messages aux étudiants et enseignants.</p>
          </div>

          <div class="card" onclick="window.location.href='parametres.php'">
            <i class="fa fa-lock"></i>
            <h2>Sécurité & Paramètres</h2>
            <p>Configurez la sécurité et les préférences du système.</p>
          </div>
        </div>
      </main>
    </div>
  </div>

  <script>
    // ✅ Menu mobile
    function toggleSidebar() {
      document.querySelector('.sidebar').classList.toggle('active');
    }

    // ✅ Fonction pour afficher/masquer des éléments sur mobile
    const toggleElements = document.querySelectorAll('.card');

    toggleElements.forEach(element => {
      element.addEventListener('click', () => {
        const next = element.nextElementSibling;
        if (next && next.style.display === 'none') {
          next.style.display = 'block';
        } else if (next) {
          next.style.display = 'none';
        }
      });
    });
  </script>
</body>
</html>
