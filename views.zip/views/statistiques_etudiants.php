<?php 
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit();
}

require_once '../config/db.php';

// === Statistiques globales ===
$total = $db->query("SELECT COUNT(*) FROM inscriptions")->fetchColumn();
$confirmes = $db->query("SELECT COUNT(*) FROM inscriptions WHERE statut_inscription = 'confirmée'")->fetchColumn();
$terminees = $db->query("SELECT COUNT(*) FROM inscriptions WHERE statut_inscription = 'terminée'")->fetchColumn();
$attente = $db->query("SELECT COUNT(*) FROM inscriptions WHERE statut_inscription = 'en_attente'")->fetchColumn();

// === Répartition par sexe ===
$sexeData = $db->query("
    SELECT sexe, COUNT(*) AS total 
    FROM inscriptions 
    GROUP BY sexe
")->fetchAll(PDO::FETCH_ASSOC);

// === Répartition par filière ===
$filiereData = $db->query("
    SELECT f.designation_filiere AS filiere, COUNT(i.id_inscription) AS total
    FROM inscriptions i
    LEFT JOIN options o ON i.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    GROUP BY f.designation_filiere
")->fetchAll(PDO::FETCH_ASSOC);

// === Répartition par niveau ===
$niveauData = $db->query("
    SELECT niveau, COUNT(*) AS total
    FROM inscriptions
    GROUP BY niveau
")->fetchAll(PDO::FETCH_ASSOC);

// === Pagination pour les détails ===
$limit = 5;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;
$totalRows = $db->query("SELECT COUNT(DISTINCT o.id_option) FROM options o")->fetchColumn();
$totalPages = ceil($totalRows / $limit);

// === Détails paginés ===
$stmt = $db->prepare("
    SELECT 
        o.id_option,
        o.designation_option AS option_nom,
        f.designation_filiere AS filiere,
        COUNT(i.id_inscription) AS total_etudiants,
        SUM(CASE WHEN i.sexe = 'Homme' THEN 1 ELSE 0 END) AS hommes,
        SUM(CASE WHEN i.sexe = 'Femme' THEN 1 ELSE 0 END) AS femmes
    FROM inscriptions i
    LEFT JOIN options o ON i.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    GROUP BY o.id_option, o.designation_option, f.designation_filiere
    ORDER BY f.designation_filiere, o.designation_option
    LIMIT :limit OFFSET :offset
");
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$detailsOptions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Statistiques des Étudiants</title>
<link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
body{font-family:"Segoe UI",sans-serif;background:#f5f7fb;margin:0;padding:0;}
header{background:linear-gradient(90deg,#0b3b6a,#c58a00);color:#fff;text-align:center;padding:1rem;}
.container{width:90%;max-width:1200px;margin:30px auto;background:#fff;padding:25px;border-radius:10px;box-shadow:0 4px 10px rgba(0,0,0,0.1);}
h2{color:#0b3b6a;text-align:center;margin-top:20px;}
.stats-summary{display:flex;justify-content:space-around;flex-wrap:wrap;margin-bottom:30px;}
.stat-card{background:#f1f1f1;border-radius:10px;padding:15px 25px;width:220px;text-align:center;margin:10px;box-shadow:0 3px 5px rgba(0,0,0,0.1);}
.stat-card h3{margin:10px 0 5px;font-size:1.5rem;color:#0b3b6a;}
table{width:100%;border-collapse:collapse;margin-top:25px;}
th,td{border-bottom:1px solid #ddd;padding:10px;text-align:left;}
th{background:#0b3b6a;color:white;}
tr:hover{background:#f9f9f9;}
.actions a{padding:5px 8px;border-radius:5px;margin:0 3px;color:#fff;text-decoration:none;font-size:0.85rem;}
.export-pdf{background:#dc3545;}
.pagination{text-align:center;margin-top:15px;}
.pagination a{display:inline-block;margin:0 5px;padding:6px 12px;background:#0b3b6a;color:white;border-radius:5px;text-decoration:none;}
.pagination a:hover{background:#062d55;}
.btn{display:inline-block;background:#0b3b6a;color:white;padding:8px 15px;text-decoration:none;border-radius:6px;margin-bottom:15px;}
.btn:hover{background:#062d55;}
.chart-container{width:100%;margin:30px auto;}
canvas{width:100%!important;max-height:400px;}
</style>
</head>
<body>

<header><h1><i class="fa fa-chart-bar"></i> Statistiques des Étudiants</h1></header>
<div class="container">

<a href="admin_dashboard.php" class="btn"><i class="fa fa-home"></i> Accueil</a>

<a href="export_pdf_all.php" target="_blank" class="btn export-pdf" style="float:right;margin-top:-10px;">
  <i class="fa fa-file-pdf"></i> Télécharger la liste complète (PDF)
</a>

<div class="stats-summary">
    <div class="stat-card"><h3><?= $total ?></h3><p>Total inscrits</p></div>
    <div class="stat-card"><h3 style="color:#198754;"><?= $confirmes ?></h3><p>Confirmés</p></div>
    <div class="stat-card"><h3 style="color:#c58a00;"><?= $terminees ?></h3><p>Terminées</p></div>
    <div class="stat-card"><h3 style="color:#ffc107;"><?= $attente ?></h3><p>En attente</p></div>
</div>

<h2><i class="fa fa-chart-column"></i> Détails par Option / Filière</h2>
<table>
<tr>
    <th>Filière</th>
    <th>Option</th>
    <th>Total Étudiants</th>
    <th>Hommes</th>
    <th>Femmes</th>
    <th>Actions</th>
</tr>
<?php foreach($detailsOptions as $d): ?>
<tr>
    <td><?= htmlspecialchars($d['filiere'] ?? '—') ?></td>
    <td><?= htmlspecialchars($d['option_nom']) ?></td>
    <td><strong><?= $d['total_etudiants'] ?></strong></td>
    <td style="color:#0b3b6a;"><i class="fa fa-mars"></i> <?= $d['hommes'] ?></td>
    <td style="color:#c58a00;"><i class="fa fa-venus"></i> <?= $d['femmes'] ?></td>
    <td class="actions">
        <a href="export_pdf.php?option=<?= urlencode($d['option_nom']) ?>" class="export-pdf">
            <i class="fa fa-file-pdf"></i> PDF
        </a>
    </td>
</tr>
<?php endforeach; ?>
</table>

<div class="pagination">
    <?php if($page > 1): ?>
        <a href="?page=<?= $page-1 ?>"><i class="fa fa-arrow-left"></i> Précédent</a>
    <?php endif; ?>
    <?php if($page < $totalPages): ?>
        <a href="?page=<?= $page+1 ?>">Suivant <i class="fa fa-arrow-right"></i></a>
    <?php endif; ?>
</div>

<h2>Répartition par Sexe</h2>
<div class="chart-container"><canvas id="chartSexe"></canvas></div>

<h2>Répartition par Filière</h2>
<div class="chart-container"><canvas id="chartFiliere"></canvas></div>

<h2>Répartition par Niveau</h2>
<div class="chart-container"><canvas id="chartNiveau"></canvas></div>

<h2>Répartition Globale (Confirmés, Terminées, En attente)</h2>
<div class="chart-container"><canvas id="chartGlobal"></canvas></div>

</div>

<script>
const sexeLabels = <?= json_encode(array_column($sexeData,'sexe')) ?>;
const sexeValues = <?= json_encode(array_column($sexeData,'total')) ?>;
const filiereLabels = <?= json_encode(array_column($filiereData,'filiere')) ?>;
const filiereValues = <?= json_encode(array_column($filiereData,'total')) ?>;
const niveauLabels = <?= json_encode(array_column($niveauData,'niveau')) ?>;
const niveauValues = <?= json_encode(array_column($niveauData,'total')) ?>;
const globalLabels = ['Confirmés','Terminées','En attente'];
const globalValues = [<?= $confirmes ?>,<?= $terminees ?>,<?= $attente ?>];

new Chart(document.getElementById('chartSexe'), {
  type:'doughnut',
  data:{labels:sexeLabels,datasets:[{data:sexeValues,backgroundColor:['#0b3b6a','#c58a00']}]},
  options:{responsive:true}
});

new Chart(document.getElementById('chartFiliere'), {
  type:'bar',
  data:{labels:filiereLabels,datasets:[{label:'Étudiants par filière',data:filiereValues,backgroundColor:'#0b3b6a'}]},
  options:{responsive:true,scales:{y:{beginAtZero:true}}}
});

new Chart(document.getElementById('chartNiveau'), {
  type:'bar',
  data:{labels:niveauLabels,datasets:[{label:'Répartition par niveau',data:niveauValues,backgroundColor:'#c58a00'}]},
  options:{responsive:true,scales:{y:{beginAtZero:true}}}
});

new Chart(document.getElementById('chartGlobal'), {
  type:'pie',
  data:{labels:globalLabels,datasets:[{data:globalValues,backgroundColor:['#198754','#c58a00','#ffc107']}]},
  options:{responsive:true}
});
</script>

</body>
</html>
