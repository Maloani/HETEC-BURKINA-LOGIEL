<?php
session_start();

if (!isset($_SESSION['id_etudiant'])) {
    header("Location: ../portail.php");
    exit();
}

require_once '../models/config.php';

// 🔹 Récupération des correspondances pour les étudiants
$stmt = $pdo->prepare("
    SELECT id_corresp, type_doc, objet, date_envoi, concerne, statut, fichier
    FROM correspondances
    WHERE concerne IN ('Étudiant', 'Toutes')
    ORDER BY date_envoi DESC
");
$stmt->execute();
$correspondances = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes Correspondances – HETEC Burkina Faso</title>
    <link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0-alpha1/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: "Segoe UI", sans-serif; background: #f4f7fb; margin: 0; color: #222; }
        header { background: linear-gradient(90deg, #0b3b6a, #c58a00); color: #fff; padding: 20px 25px; display: flex; align-items: center; justify-content: space-between; }
        header h1 { margin: 0; font-size: 1.4rem; display: flex; align-items: center; gap: 10px; }
        header a { color: #fff; text-decoration: none; background: rgba(255,255,255,0.2); padding: 8px 14px; border-radius: 6px; font-weight: 600; transition: 0.3s; }
        header a:hover { background: rgba(255,255,255,0.35); }

        .container { max-width: 1000px; margin: 40px auto; background: #fff; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); padding: 30px; }
        h2 { color: #0b3b6a; border-left: 4px solid #c58a00; padding-left: 10px; margin-bottom: 20px; }

        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #0b3b6a; color: #fff; text-transform: uppercase; }
        tr:hover { background-color: #f8f9fa; }

        .statut { font-weight: bold; }
        .statut.Envoyé { color: green; }
        .statut.En\ attente { color: orange; }

        .download-link { color: #0b3b6a; text-decoration: none; font-weight: 600; }
        .download-link:hover { text-decoration: underline; }

        footer { text-align: center; padding: 20px; font-size: 0.9rem; color: #666; margin-top: 30px; }
        footer a { color: #0b3b6a; text-decoration: none; }
        footer a:hover { text-decoration: underline; }

        @media (max-width: 768px) {
            table { font-size: 0.8rem; }
            th, td { padding: 8px; }
        }
    </style>
</head>
<body>

<header>
    <h1><i class="fa-solid fa-envelope"></i> Mes Correspondances</h1>
    <a href="etudiant_dashboard.php"><i class="fa-solid fa-arrow-left"></i> Retour</a>
</header>

<div class="container">
    <h2><i class="fa-solid fa-list"></i> Liste des Correspondances</h2>

    <?php if (count($correspondances) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Type de document</th>
                    <th>Objet</th>
                    <th>Date d’envoi</th>
                    <th>Statut</th>
                    <th>Fichier</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($correspondances as $c): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($c['type_doc']) ?></strong></td>
                    <td><?= htmlspecialchars($c['objet']) ?></td>
                    <td><?= date('d/m/Y', strtotime($c['date_envoi'])) ?></td>
                    <td class="statut <?= htmlspecialchars($c['statut']) ?>"><?= htmlspecialchars($c['statut']) ?></td>
                    <td>
                        <?php if (!empty($c['fichier'])): ?>
                            <a class="download-link" href="../uploads/<?= htmlspecialchars($c['fichier']) ?>" target="_blank">
                                <i class="fa-solid fa-download"></i> Télécharger
                            </a>
                        <?php else: ?>
                            <span class="text-muted">Aucun fichier</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-muted">Aucune correspondance disponible pour le moment.</p>
    <?php endif; ?>
</div>

<footer>
    &copy; <?= date('Y') ?> HETEC Burkina Faso — Plateforme Académique Numérique |
    Développé par <a href="https://www.ms-solutionslab.com" target="_blank"><strong>MS Solutions Lab</strong></a>
</footer>

</body>
</html>
