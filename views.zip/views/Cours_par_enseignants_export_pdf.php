<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../models/config.php';
require_once __DIR__ . '/fpdf/fpdf.php';
require_once __DIR__ . '/phpqrcode/qrlib.php';

// === Fonction de normalisation (accents et apostrophes) ===
function normalize_text($text) {
    if ($text === null) return '';
    $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = str_replace(
        ["’", "‘", "‛", "‚", "´", "`", "“", "”", "„", "œ", "–", "—"],
        ["'", "'", "'", "'", "'", "'", '"', '"', '"', "oe", "-", "-"],
        $text
    );
    return utf8_decode($text);
}

// === Vérification de la session ===
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'enseignant') {
    die("Accès refusé. Veuillez vous reconnecter.");
}

$id_enseignant = $_SESSION['user_id'];

// === Récupération des infos enseignant ===
$stmt = $pdo->prepare("SELECT nom_complet, telephone FROM enseignants WHERE id_enseignant = ?");
$stmt->execute([$id_enseignant]);
$enseignant = $stmt->fetch(PDO::FETCH_ASSOC);

// === Récupération des cours attribués ===
$query = $pdo->prepare("
    SELECT 
        c.designation_cours, c.code_cours, c.credits, c.CM, c.P, c.TPE,
        u.code_ue, u.intitule_ue, u.qualite,
        o.designation_option, f.designation_filiere, c.annee_academique
    FROM cours c
    LEFT JOIN ues u ON c.id_ue = u.id_ue
    LEFT JOIN options o ON c.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    WHERE c.id_enseignant = ?
    ORDER BY c.annee_academique DESC, u.code_ue ASC
");
$query->execute([$id_enseignant]);
$courses = $query->fetchAll(PDO::FETCH_ASSOC);

// === Génération du QR Code ===
$qrContent = "Enseignant : {$enseignant['nom_complet']} | Téléphone : {$enseignant['telephone']} | Date : " . date("d/m/Y H:i");
$qrPath = __DIR__ . '/temp_qr.png';
QRcode::png($qrContent, $qrPath, QR_ECLEVEL_L, 3);

// === Classe PDF personnalisée ===
class PDF_HETEC extends FPDF {
    function Header() {
        if (file_exists('../img/hetec.png')) {
            $this->Image('../img/hetec.png', 130, 8, 30);
        }
        $this->Ln(25);
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(0, 6, utf8_decode("MINISTÈRE DE L'ENSEIGNEMENT SUPÉRIEUR, DE LA RECHERCHE ET DE L'INNOVATION (MESRI)"), 0, 1, 'C');
        $this->SetFont('Arial', 'B', 11);
        $this->Cell(0, 6, utf8_decode("ÉCOLE SUPÉRIEURE DES HAUTES ÉTUDES TECHNOLOGIQUES ET COMMERCIALES (HETEC)"), 0, 1, 'C');
        $this->SetFont('Arial', '', 9.5);
        $this->Cell(0, 6, utf8_decode("Diplômes reconnus par le CAMES Membre de AACSB"), 0, 1, 'C');
        $this->Ln(5);
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 8, utf8_decode("LISTE DES COURS ATTRIBUÉS À L'ENSEIGNANT"), 0, 1, 'C');
        $this->Ln(7);
    }

  
}

// === Création du PDF paysage ===
$pdf = new PDF_HETEC('L', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetFont('Arial', '', 11);

// === Informations de l’enseignant + QR à droite ===
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(0, 8, utf8_decode("Informations :"), 0, 1, 'L');
$pdf->SetFont('Arial', '', 11);

$startY = $pdf->GetY();
$pdf->Cell(130, 8, normalize_text("Nom : " . $enseignant['nom_complet']), 0, 1);
$pdf->Cell(130, 8, normalize_text("Téléphone : " . ($enseignant['telephone'] ?? "—")), 0, 1);

// Position du QR code à droite
if (file_exists($qrPath)) {
    $pdf->Image($qrPath, 220, $startY - 3, 25);
}
$pdf->Ln(10);

// === Tableau des cours ===
$pdf->SetFont('Arial', 'B', 9.5);
$pdf->SetFillColor(11, 59, 106);
$pdf->SetTextColor(255);

$headers = ["UE (Code & Intitulé)", "Cours (ECUE)", "Cd", "CM", "P", "TPE", "Option", "Filière", "Année"];
$widths = [55, 65, 10, 10, 10, 10, 25, 30, 30];

foreach ($headers as $i => $h) {
    $pdf->Cell($widths[$i], 9, utf8_decode($h), 1, 0, 'C', true);
}
$pdf->Ln();

$pdf->SetFont('Arial', '', 9.5);
$pdf->SetTextColor(0);

if (empty($courses)) {
    $pdf->Cell(array_sum($widths), 9, utf8_decode("Aucun cours attribué."), 1, 1, 'C');
} else {
    foreach ($courses as $c) {
        $yStart = $pdf->GetY();
        $xStart = $pdf->GetX();

        // Colonne UE
        $ueText = ($c['code_ue'] ?? '—') . " – " . ($c['intitule_ue'] ?? '');
        $pdf->MultiCell($widths[0], 8, normalize_text($ueText), 1, 'L');
        $yEnd = $pdf->GetY();
        $rowHeight = $yEnd - $yStart;

        // Repositionnement
        $pdf->SetXY($xStart + $widths[0], $yStart);
        $pdf->MultiCell($widths[1], 8, normalize_text($c['designation_cours']), 1, 'L');
        $h2 = $pdf->GetY() - $yStart;
        $rowHeight = max($rowHeight, $h2);

        // Colonnes suivantes
        $pdf->SetXY($xStart + $widths[0] + $widths[1], $yStart);
        $pdf->Cell($widths[2], $rowHeight, normalize_text($c['credits']), 1, 0, 'C');
        $pdf->Cell($widths[3], $rowHeight, normalize_text($c['CM']), 1, 0, 'C');
        $pdf->Cell($widths[4], $rowHeight, normalize_text($c['P']), 1, 0, 'C');
        $pdf->Cell($widths[5], $rowHeight, normalize_text($c['TPE']), 1, 0, 'C');
        $pdf->Cell($widths[6], $rowHeight, normalize_text($c['designation_option']), 1, 0, 'C');
        $pdf->Cell($widths[7], $rowHeight, normalize_text($c['designation_filiere']), 1, 0, 'C');
        $pdf->Cell($widths[8], $rowHeight, normalize_text($c['annee_academique']), 1, 1, 'C');
    }
}


// === Sortie du PDF ===
$pdf->Output('I', 'Mes_Cours_Attribues_HETEC.pdf');

// Nettoyage du QR code temporaire
if (file_exists($qrPath)) unlink($qrPath);
exit;
?>
