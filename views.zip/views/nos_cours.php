<?php
session_start();

if (!isset($_SESSION['id_etudiant'])) {
    header("Location: ../portail.php");
    exit();
}

require_once '../models/config.php';

// 🔹 Récupération des informations de l’étudiant connecté
$id = $_SESSION['id_etudiant'];
$stmt = $pdo->prepare("
    SELECT i.*, o.designation_option, f.designation_filiere
    FROM inscriptions i
    LEFT JOIN options o ON i.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    WHERE i.id_inscription = :id
");
$stmt->execute(['id' => $id]);
$etudiant = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$etudiant) {
    header("Location: ../etudiant_login.php");
    exit();
}

// 🔹 Récupérer les cours selon l’option
$coursesStmt = $pdo->prepare("
    SELECT 
        u.qualite,
        u.code_ue,
        u.intitule_ue,
        u.nc_ue,
        c.code_cours,
        c.designation_cours,
        c.credits,
        c.CM,
        c.P,
        c.TPE,
        e.nom_complet AS enseignant
    FROM cours c
    LEFT JOIN ues u ON c.id_ue = u.id_ue
    LEFT JOIN enseignants e ON c.id_enseignant = e.id_enseignant
    WHERE c.id_option = :id_option
    ORDER BY u.code_ue ASC
");
$coursesStmt->execute(['id_option' => $etudiant['id_option']]);
$courses = $coursesStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Nos Cours – HETEC Burkina Faso</title>
  <link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0-alpha1/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { font-family: "Segoe UI", sans-serif; background: #fff; margin: 0; color: #222; }
    header { background: linear-gradient(90deg, #0b3b6a, #c58a00); color: #fff; padding: 20px 25px; display: flex; align-items: center; justify-content: space-between; }
    header h1 { margin: 0; font-size: 1.3rem; display: flex; align-items: center; gap: 10px; }
    header a { color: #fff; text-decoration: none; background: rgba(255,255,255,0.2); padding: 6px 12px; border-radius: 6px; font-weight: 600; transition: 0.3s; }
    header a:hover { background: rgba(255,255,255,0.35); }

    .container { max-width: 1200px; margin: 40px auto; background: #fff; border-radius: 8px; padding: 30px; border: 1px solid #ccc; }

    .entete { text-align: center; margin-bottom: 25px; }
    .entete h2 { text-transform: uppercase; font-size: 1rem; margin: 12px 0; color: #000; font-weight: bold; border-top: 1px solid #000; border-bottom: 1px solid #000; display: inline-block; padding: 6px 25px; }
    .entete p { margin: 4px 0; font-size: 0.9rem; line-height: 1.5; text-align: left; max-width: 600px; margin-left: auto; margin-right: auto; }
    .entete .nom-etudiant { margin-top: 10px; font-weight: bold; color: #0b3b6a; }

    table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size: 0.9rem; }
    th, td { border: 1px solid #333; padding: 8px 10px; text-align: center; }
    th { background-color: #0b3b6a; color: #fff; font-size: 0.85rem; text-transform: uppercase; }
    td { vertical-align: middle; }
    tr:hover { background-color: #f4f6f9; }

    footer { text-align: center; padding: 20px; font-size: 0.85rem; color: #666; margin-top: 30px; }
    footer a { color: #0b3b6a; text-decoration: none; }
    footer a:hover { text-decoration: underline; }
  </style>
</head>
<body>

<header>
  <h1><i class="fa-solid fa-book"></i> Nos Cours</h1>
  <a href="etudiant_dashboard.php"><i class="fa-solid fa-arrow-left"></i> Retour</a>
</header>

<div class="container">
  <div class="entete">
    <!-- ✅ En-tête académique -->
    <h2><?= strtoupper(htmlspecialchars($etudiant['grade'])) ?> EN <?= strtoupper(htmlspecialchars($etudiant['designation_filiere'])) ?></h2>
    <p><strong>Domaine :</strong> <?= htmlspecialchars($etudiant['domaine']) ?></p>
    <p><strong>Mention :</strong> <?= htmlspecialchars($etudiant['mention']) ?></p>
    <p><strong>Spécialité :</strong> <?= htmlspecialchars($etudiant['designation_filiere']) ?></p>
    <p><strong><?= htmlspecialchars($etudiant['niveau']) ?>, <?= htmlspecialchars($etudiant['semestre']) ?></strong></p>
    <p class="nom-etudiant">Étudiant : <?= strtoupper(htmlspecialchars($etudiant['nom_etudiant'] . ' ' . $etudiant['prenom_etudiant'])) ?></p>
  </div>

  <?php if (count($courses) > 0): ?>
    <table>
      <thead>
        <tr>
          <th>Qualité UE</th>
          <th>Code UE</th>
          <th>Intitulé UE</th>
          <th>NC/UE</th>
          <th>Code ECUE</th>
          <th>Intitulé de l’ECUE</th>
          <th>Cd ECUE</th>
          <th>CM</th>
          <th>TD</th>
          <th>TP</th>
          <th>P</th>
          <th>TPE</th>
          <th>Examen</th>
          <th>Enseignant</th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $totalCredits = 0; 
        $totalCM = $totalTD = $totalTP = $totalP = $totalTPE = $totalExam = 0;
        foreach ($courses as $c): 
          $td = 10; 
          $tp = 10; 
          $exam = 20; 
          $totalCredits += $c['credits'];
          $totalCM += $c['CM']; 
          $totalTD += $td; 
          $totalTP += $tp;
          $totalP += $c['P']; 
          $totalTPE += $c['TPE']; 
          $totalExam += $exam;
        ?>
        <tr>
          <td><?= htmlspecialchars($c['qualite']) ?></td>
          <td><?= htmlspecialchars($c['code_ue']) ?></td>
          <td><?= htmlspecialchars($c['intitule_ue']) ?></td>
          <td><?= htmlspecialchars($c['nc_ue']) ?></td>
          <td><?= htmlspecialchars($c['code_cours']) ?></td>
          <td><?= htmlspecialchars($c['designation_cours']) ?></td>
          <td><?= htmlspecialchars($c['credits']) ?></td>
          <td><?= htmlspecialchars($c['CM']) ?></td>
          <td><?= $td ?></td>
          <td><?= $tp ?></td>
          <td><?= htmlspecialchars($c['P']) ?></td>
          <td><?= htmlspecialchars($c['TPE']) ?></td>
          <td><?= $exam ?></td>
          <td><?= htmlspecialchars($c['enseignant'] ?? 'Non attribué') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
        <tr style="font-weight:bold; background:#eaeaea;">
          <td colspan="6">TOTAL</td>
          <td><?= $totalCredits ?></td>
          <td><?= $totalCM ?></td>
          <td><?= $totalTD ?></td>
          <td><?= $totalTP ?></td>
          <td><?= $totalP ?></td>
          <td><?= $totalTPE ?></td>
          <td><?= $totalExam ?></td>
          <td>-</td>
        </tr>
      </tfoot>
    </table>
  <?php else: ?>
    <p class="text-muted">Aucun cours disponible pour votre option actuellement.</p>
  <?php endif; ?>
</div>

<footer>
    &copy; <?= date('Y') ?> HETEC Burkina Faso — Plateforme Académique Numérique |
    Développé par <a href="https://www.ms-solutionslab.com" target="_blank"><strong>MS Solutions Lab</strong></a>
</footer>


</body>
</html>
