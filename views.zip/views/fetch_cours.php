<?php
require_once '../models/config.php';

// --- En-tête JSON UTF-8 ---
header('Content-Type: application/json; charset=utf-8');

// --- Vérification du paramètre ID ---
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo json_encode(['status' => 'error', 'message' => 'ID enseignant manquant ou invalide']);
    exit;
}

$id = (int)$_GET['id'];
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

try {
    // === 1️⃣ Compter le total de cours attribués à cet enseignant ===
    $countSql = "SELECT COUNT(*) FROM cours WHERE id_enseignant = :id";
    $countStmt = $pdo->prepare($countSql);
    $countStmt->execute([':id' => $id]);
    $total = $countStmt->fetchColumn();
    $totalPages = ceil($total / $limit);

    // === 2️⃣ Récupération détaillée des cours ===
    $sql = "
        SELECT 
            c.id_cours,
            c.designation_cours,
            c.code_cours,
            c.credits,
            c.CM,
            c.P,
            c.TPE,
            c.annee_academique,
            u.id_ue,
            u.qualite,
            u.code_ue,
            u.intitule_ue,
            u.nc_ue,
            o.designation_option,
            f.designation_filiere
        FROM cours c
        LEFT JOIN ues u ON c.id_ue = u.id_ue
        LEFT JOIN options o ON c.id_option = o.id_option
        LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
        WHERE c.id_enseignant = :id
        ORDER BY u.intitule_ue ASC, c.designation_cours ASC
        LIMIT :limit OFFSET :offset
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $cours = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // === 3️⃣ Vérification du résultat ===
    if (!$cours) {
        echo json_encode([
            'status' => 'success',
            'message' => 'Aucun cours trouvé pour cet enseignant.',
            'cours' => [],
            'page' => $page,
            'totalPages' => $totalPages
        ]);
        exit;
    }

    // === 4️⃣ Réponse JSON finale ===
    echo json_encode([
        'status' => 'success',
        'cours' => $cours,
        'page' => $page,
        'totalPages' => $totalPages
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

} catch (PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Erreur SQL : ' . $e->getMessage()
    ]);
    exit;
}
?>
