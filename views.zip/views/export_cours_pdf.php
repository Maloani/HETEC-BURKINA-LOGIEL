<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../models/config.php';
require_once __DIR__ . '/fpdf/fpdf.php';


if (!isset($_POST['id_enseignant'])) {
    die("Aucun enseignant spécifié.");
}

$id_enseignant = (int)$_POST['id_enseignant'];

// Requête pour récupérer les cours
$sql = "
SELECT 
    c.designation_cours,
    c.code_cours,
    c.credits,
    c.annee_academique,
    o.designation_option,
    f.designation_filiere,
    e.nom_complet
FROM cours c
LEFT JOIN options o ON c.id_option = o.id_option
LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
LEFT JOIN enseignants e ON c.id_enseignant = e.id_enseignant
WHERE c.id_enseignant = :id
";
$stmt = $pdo->prepare($sql);
$stmt->execute([':id' => $id_enseignant]);
$cours = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 14);

// En-tête
$pdf->Cell(190, 10, utf8_decode("HETEC BURKINA FASO"), 0, 1, 'C');
$pdf->SetFont('Arial', '', 11);
$pdf->Cell(190, 8, utf8_decode("Liste des cours attribués à l’enseignant"), 0, 1, 'C');
$pdf->Ln(5);

// Informations enseignant
if (!empty($cours)) {
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(190, 8, utf8_decode("Enseignant : " . $cours[0]['nom_complet']), 0, 1, 'L');
    $pdf->Ln(4);
}

// En-tête du tableau
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor(11, 59, 106);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(60, 8, utf8_decode("Cours"), 1, 0, 'C', true);
$pdf->Cell(25, 8, "Code", 1, 0, 'C', true);
$pdf->Cell(15, 8, "Crédits", 1, 0, 'C', true);
$pdf->Cell(30, 8, utf8_decode("Option"), 1, 0, 'C', true);
$pdf->Cell(30, 8, utf8_decode("Filière"), 1, 0, 'C', true);
$pdf->Cell(30, 8, "Année", 1, 1, 'C', true);

$pdf->SetFont('Arial', '', 10);
$pdf->SetTextColor(0, 0, 0);

// Lignes du tableau
foreach ($cours as $c) {
    $pdf->Cell(60, 8, utf8_decode($c['designation_cours']), 1);
    $pdf->Cell(25, 8, utf8_decode($c['code_cours']), 1);
    $pdf->Cell(15, 8, utf8_decode($c['credits']), 1);
    $pdf->Cell(30, 8, utf8_decode($c['designation_option']), 1);
    $pdf->Cell(30, 8, utf8_decode($c['designation_filiere']), 1);
    $pdf->Cell(30, 8, utf8_decode($c['annee_academique']), 1, 1);
}

$pdf->Output("I", "Mes_Cours_HETEC.pdf");
