<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../models/config.php';
require_once __DIR__ . '/fpdf/fpdf.php';
require_once __DIR__ . '/phpqrcode/qrlib.php';

// === Fonction de normalisation ===
function normalize_text($text) {
    $text = str_replace(
        ["’", "‘", "‛", "‚", "´", "`", "“", "”", "„"],
        ["'", "'", "'", "'", "'", "'", '"', '"', '"'],
        $text
    );
    return utf8_decode($text);
}

if (!isset($_GET['id'])) die('Aucun ID fourni.');
$id = (int)$_GET['id'];

// === Récupération des données étudiant (grade dans inscriptions) ===
$stmt = $pdo->prepare("
    SELECT i.*, o.designation_option, f.designation_filiere
    FROM inscriptions i
    LEFT JOIN options o ON i.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    WHERE i.id_inscription = :id
");
$stmt->execute([':id' => $id]);
$etudiant = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$etudiant) die('Étudiant introuvable.');

// === Lien de vérification ===
$verificationUrl = "https://osseboa.com/hetec_administration/views/attestation_admissibilite_pdf.php?id=" . $etudiant['id_inscription'];

// === Contenu du QR Code ===
$qrText =
    "🔹 UNIVERSITÉ : HETEC Burkina Faso\n" .
    "🔸 Nom complet : " . strtoupper($etudiant['nom_etudiant']) . " " . ucfirst($etudiant['prenom_etudiant']) . "\n" .
    "🔸 Matricule : " . strtoupper($etudiant['matricule_etudiant']) . "\n" .
    "🔸 Sexe : " . strtoupper($etudiant['sexe']) . "\n" .
    "🔸 Grade : " . strtoupper($etudiant['grade']) . "\n" .
    "🔸 Filière : " . strtoupper($etudiant['designation_filiere']) . "\n" .
    "🔸 Option : " . strtoupper($etudiant['designation_option']) . "\n\n" .
    "🔗 Vérifier le certificat : " . $verificationUrl;

// === Génération du QR Code ===
$qrDir = __DIR__ . "/qrcodes/";
if (!is_dir($qrDir)) mkdir($qrDir);
$qrFile = $qrDir . "qr_" . $etudiant['id_inscription'] . ".png";
QRcode::png($qrText, $qrFile, QR_ECLEVEL_Q, 5);

// === Classe PDF ===
class PDF extends FPDF {
    function Header() {
        // === Bordure triple ===
        $this->SetLineWidth(2);
        $this->SetDrawColor(180, 180, 180);
        $this->Rect(5, 5, 200, 287);
        $this->SetDrawColor(197, 138, 0);
        $this->Rect(7, 7, 196, 283);
        $this->SetDrawColor(128, 0, 32);
        $this->Rect(9, 9, 192, 279);

        // === Logo ===
        $this->Image('../img/hetec.png', 90, 12, 30);
        $this->Ln(26);

        // === En-tête ===
        $this->SetFont('Arial', 'B', 13);
        $this->Cell(0, 6, normalize_text("GROUPE ÉCOLES D’INGÉNIEURS"), 0, 1, 'C');
        $this->SetFont('Arial', 'B', 11);
        $this->Cell(0, 6, normalize_text("ÉCOLE SUPÉRIEURE DES HAUTES ÉTUDES TECHNOLOGIQUES ET COMMERCIALES (HETEC)"), 0, 1, 'C');
        $this->SetFont('Arial', '', 10);
        $this->Cell(0, 6, normalize_text("Ministère de l’Enseignement Supérieur, de la Recherche et de l’Innovation (MESRI)"), 0, 1, 'C');
        $this->Cell(0, 6, normalize_text("Diplômes reconnus par le CAMES - Membre de l’AACSB"), 0, 1, 'C');
        $this->Ln(12);
    }
}

$pdf = new PDF('P', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetMargins(20, 20, 20);
$pdf->SetAutoPageBreak(false);

// === Titre principal ===
$pdf->SetFillColor(128, 0, 32);
$pdf->SetTextColor(255, 255, 255);
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 12, normalize_text("ATTESTATION D’ADMISSIBILITÉ"), 1, 1, 'C', true);
$pdf->Ln(10);

// === Corps du texte ===
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('Times', '', 13);
$pdf->MultiCell(0, 6, normalize_text("POUR SERVIR ET VALOIR CE QUE DE DROIT,"));
$pdf->Ln(3);
$pdf->MultiCell(0, 8, normalize_text("Nous, Direction Générale du Groupe HETEC (École Supérieure des Hautes Études Technologiques et Commerciales),"));
$pdf->MultiCell(0, 8, normalize_text("Vu le protocole d’accord de partenariat du 17 octobre 2023 entre HETEC ABIDJAN et HETEC OUAGADOUGOU,"));
$pdf->MultiCell(0, 8, normalize_text("Vu le rapport du jury interne d’évaluation des étudiants de fin de cycle,"));
$pdf->MultiCell(0, 8, normalize_text("Attestons que :"));
$pdf->Ln(6);

// === Bloc nom étudiant ===
$pdf->SetFont('Times', 'B', 14);
$pdf->SetFillColor(235, 235, 235);
$pdf->Cell(0, 10, normalize_text(strtoupper($etudiant['nom_etudiant']) . " " . ucfirst($etudiant['prenom_etudiant'])), 1, 1, 'C', true);
$pdf->Ln(6);

// === Date formatée ===
$date_naissance = "";
if (!empty($etudiant['date_naissance']) && $etudiant['date_naissance'] != "0000-00-00") {
    $date_naissance = date("d/m/Y", strtotime($etudiant['date_naissance']));
}

// === Informations ===
$pdf->SetFont('Times', '', 13);
$pdf->MultiCell(0, 8, normalize_text("Né(e) le " . $date_naissance . " à " . strtoupper($etudiant['lieu_naissance']) . "."));
$pdf->MultiCell(0, 8, normalize_text("a subi avec succès les épreuves écrites de " . strtoupper($etudiant['grade']) . " en " . strtoupper($etudiant['designation_filiere']) . ","));
$pdf->MultiCell(0, 8, normalize_text("Option : " . strtoupper($etudiant['designation_option']) . ", sous le matricule " . strtoupper($etudiant['matricule_etudiant']) . "."));
$pdf->Ln(5);

$pdf->SetFont('Times', 'B', 13);
$pdf->MultiCell(0, 8, normalize_text("Au titre de l’année académique " . $etudiant['annee_academique'] . "."));
$pdf->Ln(8);

// === Position bas de page ===
$yBase = 230;

// === Phrase d’avertissement ===
$pdf->SetXY(20, $yBase - 14);
$pdf->SetFont('Times', '', 12);
$pdf->MultiCell(0, 6, normalize_text("L’admission définitive ne sera effective que si l’intéressé(e) présente avec succès la soutenance de son mémoire de fin de cycle."), 0, 'L');
$pdf->Ln(5);

// === Date ===
$pdf->SetXY(120, $yBase - 2);
$pdf->SetFont('Times', 'I', 12);
$pdf->Cell(70, 8, normalize_text("Fait à Ouagadougou, le " . date("d/m/Y")), 0, 2, 'C');

// === Titre du Directeur ===
$pdf->SetXY(120, $yBase + 8);
$pdf->SetFont('Arial', 'B', 13);
$pdf->Cell(70, 8, normalize_text("DIRECTEUR DÉLÉGUÉ"), 0, 2, 'C');

// === Cachet + Signature ===
$pdf->Image('../img/cachet.JPG', 135, $yBase + 18, 32);
$pdf->Image('../img/signature.JPG', 165, $yBase + 18, 32);

// === QR Code à gauche ===
$pdf->Image($qrFile, 25, $yBase + 8, 35, 35);

// === Ligne dorée + phrases ===
$pdf->SetY(273);
$pdf->SetDrawColor(197, 138, 0);
$pdf->SetLineWidth(0.5);

// Phrase "En foi de quoi..." au-dessus de la ligne
$pdf->SetFont('Times', 'I', 11);
$pdf->Cell(0, 6, normalize_text("En foi de quoi, nous lui délivrons la présente attestation."), 0, 1, 'C');

$pdf->Line(20, 277, 190, 277);

// Phrase NB lisible en dessous
$pdf->SetY(278);
$pdf->SetFont('Arial', 'I', 9);
$pdf->SetTextColor(0, 0, 0);
$pdf->MultiCell(0, 6, normalize_text("NB : La présente attestation d’admissibilité ne vaut pas admission définitive. Le parchemin définitif sera délivré après soutenance du mémoire."), 0, 'C');

// === Sortie PDF ===
$filename = "Attestation_Admissibilite_" . strtoupper($etudiant['nom_etudiant']) . "_" . ucfirst($etudiant['prenom_etudiant']) . ".pdf";
$pdf->Output('I', $filename);
?>
