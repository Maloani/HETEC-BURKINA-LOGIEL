<?php
// Connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "osg_osseboa_db";

// Créer la connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ajouter une filière
if (isset($_POST['action']) && $_POST['action'] == 'add') {
    $designation_filiere = $conn->real_escape_string($_POST['designation_filiere']);

    $query = "INSERT INTO filieres (designation_filiere) VALUES ('$designation_filiere')";
    if ($conn->query($query) === TRUE) {
        echo "Nouvelle filière ajoutée avec succès";
    } else {
        echo "Erreur : " . $conn->error;
    }
    exit;
}

// Modifier une filière
if (isset($_POST['action']) && $_POST['action'] == 'edit') {
    $id_filiere = $_POST['id_filiere'];
    $designation_filiere = $conn->real_escape_string($_POST['designation_filiere']);

    $query = "UPDATE filieres SET designation_filiere = '$designation_filiere' WHERE id_filiere = $id_filiere";
    if ($conn->query($query) === TRUE) {
        echo "Filière mise à jour avec succès";
    } else {
        echo "Erreur : " . $conn->error;
    }
    exit;
}

// Supprimer une filière
if (isset($_POST['action']) && $_POST['action'] == 'delete') {
    $id_filiere = $_POST['id_filiere'];

    $query = "DELETE FROM filieres WHERE id_filiere = $id_filiere";
    if ($conn->query($query) === TRUE) {
        echo "Filière supprimée avec succès";
    } else {
        echo "Erreur : " . $conn->error;
    }
    exit;
}

// Récupérer toutes les filières
$query = "SELECT * FROM filieres";
$result = $conn->query($query);
$filieres = [];
while ($row = $result->fetch_assoc()) {
    $filieres[] = $row;
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Gestion des Filières – HETEC</title>
    <link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp"> <!-- Ajout de l'icône dans l'onglet -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        /* Styles de base */
        body {
            font-family: "Segoe UI", sans-serif;
            background: #f6f8fc;
            color: #222;
            margin: 0;
            padding: 0;
        }

        .container {
            margin: 20px;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 8px 12px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        button {
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            margin-top: 10px;
        }

        button:hover {
            background-color: #45a049;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group input {
            padding: 10px;
            width: 300px;
            margin-right: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Gestion des Filières HETEC</h1>

        <!-- Formulaire pour ajouter/modifier une filière -->
        <div id="form-container">
            <h2>Ajouter ou Modifier une Filière</h2>
            <form id="filiere-form" method="post">
                <input type="hidden" id="filiere-id" name="id_filiere">
                <div class="form-group">
                    <label for="designation_filiere">Désignation de la Filière :</label>
                    <input type="text" id="designation_filiere" name="designation_filiere" required>
                </div>
                <button type="submit" id="submit-btn">Ajouter</button>
            </form>
        </div>

        <!-- Liste des filières -->
        <h2>Liste des Filières</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Désignation Filière</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="filiere-list">
                <?php foreach ($filieres as $filiere) { ?>
                    <tr>
                        <td><?php echo $filiere['id_filiere']; ?></td>
                        <td><?php echo $filiere['designation_filiere']; ?></td>
                        <td>
                            <button class="edit-btn" data-id="<?php echo $filiere['id_filiere']; ?>" data-designation="<?php echo $filiere['designation_filiere']; ?>">Modifier</button>
                            <button class="delete-btn" data-id="<?php echo $filiere['id_filiere']; ?>">Supprimer</button>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function () {
            // Ajouter une filière
            $("#filiere-form").on("submit", function (e) {
                e.preventDefault();
                var action = $("#filiere-id").val() ? "edit" : "add"; // Si l'id est présent, c'est une modification
                var data = {
                    action: action,
                    id_filiere: $("#filiere-id").val(),
                    designation_filiere: $("#designation_filiere").val()
                };

                $.post("index.php", data, function (response) {
                    alert(response);
                    location.reload(); // Recharger la page pour afficher les changements
                });
            });

            // Modifier une filière
            $(".edit-btn").on("click", function () {
                var id = $(this).data("id");
                var designation = $(this).data("designation");
                $("#filiere-id").val(id);
                $("#designation_filiere").val(designation);
                $("#submit-btn").text("Mettre à jour");
            });

            // Supprimer une filière
            $(".delete-btn").on("click", function () {
                if (confirm("Êtes-vous sûr de vouloir supprimer cette filière ?")) {
                    var id = $(this).data("id");
                    var data = {
                        action: "delete",
                        id_filiere: id
                    };

                    $.post("index.php", data, function (response) {
                        alert(response);
                        location.reload(); // Recharger la page après suppression
                    });
                }
            });
        });
    </script>
</body>

</html>
