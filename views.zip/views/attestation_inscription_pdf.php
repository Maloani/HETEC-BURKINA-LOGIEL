<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../models/config.php';
require_once __DIR__ . '/fpdf/fpdf.php';
require_once __DIR__ . '/phpqrcode/qrlib.php';

// === Fonction de normalisation ===
function normalize_text($text) {
    $text = str_replace(
        ["’", "‘", "‛", "‚", "´", "`", "“", "”", "„"],
        ["'", "'", "'", "'", "'", "'", '"', '"', '"'],
        $text
    );
    return utf8_decode($text);
}

if (!isset($_GET['id'])) die('Aucun ID fourni.');
$id = (int)$_GET['id'];

// === Récupération des données étudiant ===
$stmt = $pdo->prepare("
    SELECT i.*, o.designation_option, f.designation_filiere
    FROM inscriptions i
    LEFT JOIN options o ON i.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    WHERE i.id_inscription = :id
");
$stmt->execute([':id' => $id]);
$etudiant = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$etudiant) die('Étudiant introuvable.');

// === Génération du QR Code enrichi ===
$verificationUrl = "https://osseboa.com/hetec_administration/views/attestation_inscription_pdf.php?id=" . $etudiant['id_inscription'];

$qrText = 
    "Université : HETEC Burkina Faso\n" .
    "Nom complet : " . strtoupper($etudiant['nom_etudiant']) . " " . ucfirst($etudiant['prenom_etudiant']) . "\n" .
    "Sexe : " . $etudiant['sexe'] . "\n" .
    "Filière : " . strtoupper($etudiant['designation_filiere']) . "\n" .
    "Option : " . strtoupper($etudiant['designation_option']) . "\n\n" .
    "🔗 Vérifier l’authenticité : " . $verificationUrl;

$qrDir = __DIR__ . "/qrcodes/";
if (!is_dir($qrDir)) mkdir($qrDir);
$qrFile = $qrDir . "qr_" . $etudiant['id_inscription'] . ".png";
QRcode::png($qrText, $qrFile, QR_ECLEVEL_Q, 4);

// === Classe PDF ===
class PDF extends FPDF {
    function Header() {
        // === Bordure multicolore ===
        $this->SetLineWidth(2);
        $this->SetDrawColor(11, 59, 106); // Bleu foncé
        $this->Rect(5, 5, 200, 287); // bordure extérieure
        $this->SetDrawColor(197, 138, 0); // Doré
        $this->Rect(8, 8, 194, 281); // bordure intérieure

        // Logo
        $this->Image('../img/hetec.png', 90, 10, 30);
        $this->Ln(22);

        // En-tête
        $this->SetFont('Arial', 'B', 13);
        $this->Cell(0, 6, normalize_text("GROUPE ÉCOLES D’INGÉNIEURS"), 0, 1, 'C');
        $this->SetFont('Arial', 'B', 11);
        $this->Cell(0, 6, normalize_text("ÉCOLE SUPÉRIEURE DES HAUTES ÉTUDES TECHNOLOGIQUES ET COMMERCIALES (HETEC)"), 0, 1, 'C');
        $this->SetFont('Arial', '', 10);
        $this->Cell(0, 6, normalize_text("Ministère de l’Enseignement Supérieur, de la Recherche et de l’Innovation (MESRI)"), 0, 1, 'C');
        $this->Cell(0, 6, normalize_text("Diplômes reconnus par le CAMES  Membre de l’AACSB"), 0, 1, 'C');
        $this->Ln(12);
    }
}

$pdf = new PDF('P', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetMargins(20, 20, 20);
$pdf->SetAutoPageBreak(false);

// === Titre avec fond bleu et texte blanc ===
$pdf->SetFillColor(11, 59, 106); // bleu HETEC
$pdf->SetTextColor(255, 255, 255); // blanc
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 12, normalize_text("ATTESTATION D’INSCRIPTION"), 1, 1, 'C', true);
$pdf->Ln(10);

// === Corps du texte ===
$pdf->SetTextColor(0, 0, 0); // retour noir
$pdf->SetFont('Times', '', 13);
$pdf->MultiCell(0, 8, normalize_text("Nous soussignés HETEC, École Supérieure des Hautes Études Technologiques et Commerciales, attestons par la présente que :"));
$pdf->Ln(4);

// === Données de l’étudiant (en gras) ===
$pdf->SetFont('Times', 'B', 13);
$pdf->Write(8, normalize_text(strtoupper($etudiant['nom_etudiant']) . " " . ucfirst($etudiant['prenom_etudiant'])));
$pdf->Ln(8);

// --- Formatage de la date au format jj/mm/aaaa ---
$date_naissance = "";
if (!empty($etudiant['date_naissance']) && $etudiant['date_naissance'] != "0000-00-00") {
    $date_naissance = date("d/m/Y", strtotime($etudiant['date_naissance']));
}

$pdf->SetFont('Times', '', 13);
$pdf->Write(8, normalize_text("Né(e) le "));
$pdf->SetFont('Times', 'B', 13);
$pdf->Write(8, normalize_text($date_naissance));
$pdf->SetFont('Times', '', 13);
$pdf->Write(8, normalize_text(" à "));
$pdf->SetFont('Times', 'B', 13);
$pdf->Write(8, normalize_text(strtoupper($etudiant['lieu_naissance'])));
$pdf->Ln(8);

$pdf->SetFont('Times', '', 13);
$pdf->Write(8, normalize_text("est inscrit(e) dans notre établissement en option "));
$pdf->SetFont('Times', 'B', 13);
$pdf->Write(8, normalize_text(strtoupper($etudiant['designation_option'])));
$pdf->SetFont('Times', '', 13);
$pdf->Write(8, normalize_text(" (filière "));
$pdf->SetFont('Times', 'B', 13);
$pdf->Write(8, normalize_text(strtoupper($etudiant['designation_filiere'])));
$pdf->SetFont('Times', '', 13);
$pdf->Write(8, normalize_text("), au titre de l'année académique "));
$pdf->SetFont('Times', 'B', 13);
$pdf->Write(8, normalize_text($etudiant['annee_academique']));
$pdf->SetFont('Times', '', 13);
$pdf->Write(8, normalize_text(", sous le matricule "));
$pdf->SetFont('Times', 'B', 13);
$pdf->Write(8, normalize_text(strtoupper($etudiant['matricule_etudiant']) . "."));
$pdf->Ln(12);

// === Deuxième paragraphe ===
$pdf->SetFont('Times', '', 13);
$pdf->MultiCell(0, 8, normalize_text("En foi de quoi, la présente attestation lui est délivrée pour servir et valoir ce que de droit."));
$pdf->Ln(10);

// === Date ===
$pdf->SetFont('Times', 'I', 13);
$pdf->Cell(0, 8, normalize_text("Fait à Ouagadougou, le " . date("d/m/Y")), 0, 1, 'R');
$pdf->Ln(8);

// === Bas de page ===
$yBase = 215;

// QR Code (avec lien de vérification inclus)
$pdf->Image($qrFile, 30, $yBase, 35, 35);

// Cachet et signature
$pdf->Image('../img/cachet.JPG', 140, $yBase, 32);
$pdf->Image('../img/signature.JPG', 165, $yBase, 32);

// Directeur
$pdf->SetXY(120, $yBase - 10);
$pdf->SetFont('Arial', 'B', 13);
$pdf->Cell(70, 8, normalize_text("LE DIRECTEUR DÉLÉGUÉ"), 0, 2, 'C');

$pdf->SetXY(120, $yBase + 37);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(70, 8, normalize_text("M. OCHOU A. HERMANN"), 0, 0, 'C');

// === Mention vérifiable ===
$pdf->SetY(280);
$pdf->SetFont('Arial', 'I', 9);
$pdf->SetTextColor(80, 80, 80);
$pdf->Cell(0, 8, normalize_text("Vérifiable par QR Code - Système Académique Numérique HETEC Burkina Faso"), 0, 1, 'C');

// === Sortie PDF ===
$filename = "Attestation_Inscription_" . strtoupper($etudiant['nom_etudiant']) . "_" . ucfirst($etudiant['prenom_etudiant']) . ".pdf";
$pdf->Output('I', $filename);
?>
