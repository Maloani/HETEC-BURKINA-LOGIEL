<?php
session_start();

if (!isset($_SESSION['id_etudiant'])) {
    header("Location: ../etudiant_login.php");
    exit();
}

require_once '../models/config.php';

// 🔹 Récupérer les informations de l’étudiant connecté
$id = $_SESSION['id_etudiant'];
$stmt = $pdo->prepare("
    SELECT i.*, o.designation_option, f.designation_filiere
    FROM inscriptions i
    LEFT JOIN options o ON i.id_option = o.id_option
    LEFT JOIN filieres f ON o.id_filiere = f.id_filiere
    WHERE i.id_inscription = :id
");
$stmt->execute(['id' => $id]);
$etudiant = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$etudiant) {
    header("Location: ../etudiant_login.php");
    exit();
}

$id_inscription = htmlspecialchars($etudiant['id_inscription']);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Documents Académiques – HETEC Burkina Faso</title>
  <link rel="icon" href="../img/hetec.jpg-2.webp" type="image/webp">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0-alpha1/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    body { font-family: "Segoe UI", sans-serif; background: #f4f7fb; margin: 0; color: #222; }
    header { background: linear-gradient(90deg, #0b3b6a, #c58a00); color: #fff; padding: 20px 25px; display: flex; align-items: center; justify-content: space-between; }
    header h1 { margin: 0; font-size: 1.3rem; display: flex; align-items: center; gap: 10px; }
    header a { color: #fff; text-decoration: none; background: rgba(255,255,255,0.2); padding: 6px 12px; border-radius: 6px; font-weight: 600; transition: 0.3s; }
    header a:hover { background: rgba(255,255,255,0.35); }

    .container { max-width: 1100px; margin: 40px auto; }
    h2 { color: #0b3b6a; border-left: 4px solid #c58a00; padding-left: 10px; margin-bottom: 25px; }

    .cards-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 25px;
    }

    .doc-card {
      background: #fff; border-radius: 14px; box-shadow: 0 4px 12px rgba(0,0,0,0.05);
      padding: 30px 20px; text-align: center; transition: all 0.3s ease-in-out;
    }
    .doc-card:hover { transform: translateY(-4px); box-shadow: 0 6px 16px rgba(0,0,0,0.08); }

    .doc-card i {
      color: #c58a00; font-size: 2.2rem; margin-bottom: 12px;
    }
    .doc-card h3 {
      color: #0b3b6a; font-size: 1.2rem; margin-bottom: 8px; font-weight: 700;
    }
    .doc-card p {
      font-size: 0.95rem; color: #555; margin-bottom: 15px;
    }
    .doc-card a {
      text-decoration: none; background: linear-gradient(90deg, #0b3b6a, #c58a00);
      color: #fff; padding: 7px 14px; border-radius: 6px; font-weight: 600; display: inline-block;
    }
    .doc-card a:hover { opacity: 0.9; }

    footer {
      text-align: center; padding: 20px; font-size: 0.9rem;
      color: #666; margin-top: 40px;
    }
    footer a { color: #0b3b6a; text-decoration: none; font-weight: bold; }
    footer a:hover { text-decoration: underline; }
  </style>
</head>
<body>

<header>
  <h1><i class="fa-solid fa-folder-open"></i> Documents Académiques</h1>
  <a href="etudiant_dashboard.php"><i class="fa-solid fa-arrow-left"></i> Retour</a>
</header>

<div class="container">
  <h2>Documents de <?= htmlspecialchars($etudiant['nom_etudiant'].' '.$etudiant['prenom_etudiant']) ?></h2>

  <div class="cards-grid">
    <!-- Carte d'étudiant -->
    <div class="doc-card">
      <i class="fa-solid fa-id-card"></i>
      <h3>Carte d’étudiant</h3>
      <p>Imprimez votre carte d’étudiant officielle.</p>
      <a href="https://osseboa.com/hetec_administration/views/imprimer_carte.php?id=<?= $id_inscription ?>" target="_blank">
        📄 Imprimer la carte
      </a>
    </div>

    <!-- Attestation d’inscription -->
    <div class="doc-card">
      <i class="fa-solid fa-file-signature"></i>
      <h3>Attestation d’inscription</h3>
      <p>Téléchargez votre attestation d’inscription en PDF.</p>
      <a href="https://osseboa.com/hetec_administration/views/attestation_inscription_pdf.php?id=<?= $id_inscription ?>" target="_blank">
        📄 Imprimer attestation
      </a>
    </div>

    <!-- Attestation d’admission -->
    <div class="doc-card">
      <i class="fa-solid fa-certificate"></i>
      <h3>Attestation d’admission</h3>
      <p>Délivrée après votre admission à HETEC.</p>
      <a href="https://osseboa.com/hetec_administration/views/attestation_admission_pdf.php?id=<?= $id_inscription ?>" target="_blank">
        📄 Imprimer attestation
      </a>
    </div>

    <!-- Attestation d’admissibilité -->
    <div class="doc-card">
      <i class="fa-solid fa-award"></i>
      <h3>Attestation d’admissibilité</h3>
      <p>Obtenez votre attestation d’admissibilité officielle.</p>
      <a href="https://osseboa.com/hetec_administration/views/attestation_admissibilite_pdf.php?id=<?= $id_inscription ?>" target="_blank">
        📄 Imprimer attestation
      </a>
    </div>

    <!-- Relevé de notes -->
    <div class="doc-card">
      <i class="fa-solid fa-file-lines"></i>
      <h3>Relevé de notes</h3>
      <p>Consultez et imprimez vos relevés de notes officiels.</p>
      <a href="https://osseboa.com/hetec_administration/views/releves_notes_pdf.php?id=<?= $id_inscription ?>" target="_blank">
        📄 Imprimer relevé
      </a>
    </div>
  </div>
</div>

<footer>
  &copy; <?= date('Y') ?> HETEC Burkina Faso — Plateforme Académique Numérique |
  Développé par <a href="https://www.ms-solutionslab.com" target="_blank">MS Solutions Lab</a>
</footer>

</body>
</html>
